import pprint.pprint

## local imports
import Task


class MPEG2SliceTask(Task):
    def __init__(self): 