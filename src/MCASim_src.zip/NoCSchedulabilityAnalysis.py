import pprint
import sys, os
import numpy as np
import time
import networkx as nx
import simpy
import matplotlib.pyplot as plt
from datetime import timedelta, datetime

## local imports
from SimParams import SimParams
from Debug import Debug, DebugCat


class NoCSchedulabilityAnalysis:
    
    def __init__(self, env, runtime_app_info):
        self.env = env
        self.label = "NoCSchedulabilityAnalysis"
        self.runtime_app_info = runtime_app_info
        
        self.unschedulable_tasks = []
        self.unschedulable_flows = []
        self.unschedulable_streams = []
        
        self.track_admission_tests = []
        
    
    ## we can use this data later to save, display or analyse
    def recordSchedulabilityTest(self, stream_specs, test_time_taken):
        
       
        test_stats = {
                      
                      "new_stream_stats" : stream_specs,
                      
                      # task specific stats
                      "current_alltasks_wcet_min" : min([x.get_analytical_wcet() for x in self.runtime_app_info.getTasks() if x.get_analytical_wcet() is not None]),
                      "current_alltasks_wcet_max" : max([x.get_analytical_wcet() for x in self.runtime_app_info.getTasks() if x.get_analytical_wcet() is not None]),
                      "current_alltasks_wcet_avg" : np.mean([x.get_analytical_wcet() for x in self.runtime_app_info.getTasks() if x.get_analytical_wcet() is not None]),
                      
                      # flow specific stats
                      "current_allflows_wcet_min" : min([x.get_analytical_wcet() for x in self.runtime_app_info.getFlows() if x.get_analytical_wcet() is not None]),
                      "current_allflows_wcet_max" : max([x.get_analytical_wcet() for x in self.runtime_app_info.getFlows() if x.get_analytical_wcet() is not None]),
                      "current_allflows_wcet_avg" : np.mean([x.get_analytical_wcet() for x in self.runtime_app_info.getFlows() if x.get_analytical_wcet() is not None]),
                      
                      # stream specific stats
                      "current_stream_cp_wcet" : [(x.get_key(), x.get_criticalPathWCET()) for x in self.runtime_app_info.getStreams()],                      
                      
                      # time taken to perform schedulability test
                      "test_time_taken" : test_time_taken
                                            
                      }
        
        self.track_admission_tests.append(test_stats)
    
    
    
    # check if system is schedulable
    def checkSchedulability(self, stream_specs):        
        
        result = False
        
        test_start_time = time.clock()
        
        # find the wcet for tasks and flows
        if(self.performAnalysis_ShiAndBurns() == True):
            # if the tasks and flows independently are schedulable, then check the critical paths 
            if(self.performAnalysis_criticalPath() == True):
                result = True
            else:
                result = False
        else:
            result = False
        
        test_time_taken = time.clock() - test_start_time        
        self.recordSchedulabilityTest(stream_specs, test_time_taken)
        
        return result
        
    
    def checkSchedulability_onlyDIPrecheck(self, stream_specs):        
        
        result = False
        
        test_start_time = time.clock()
        
        ### first check using only DI flows ###
        # -------------------------------------
        # find the wcet for tasks and flows
        if(self.performAnalysis_ShiAndBurns_onlyDI() == True):
            # if the tasks and flows independently are schedulable, then check the critical paths 
            if(self.performAnalysis_criticalPath() == True):
                
                ### now check with both DI and II flows ###
                # -----------------------------------------
                # find the wcet for tasks and flows
                if(self.performAnalysis_ShiAndBurns() == True):
                    # if the tasks and flows independently are schedulable, then check the critical paths 
                    if(self.performAnalysis_criticalPath() == True):                        
                        result = True
                    else:
                        Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'outputReport::, : critical-path unschedulable', DebugCat.DEBUG_CAT_SCHEDANALYSIS)
                        result = False
                else:
                    Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'outputReport::, : tasks or flows unschedulable', DebugCat.DEBUG_CAT_SCHEDANALYSIS)
                    result = False
                # -----------------------------------------
                    
            else:
                Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'outputReport::, : *onlyDI* : critical-path unschedulable', DebugCat.DEBUG_CAT_SCHEDANALYSIS)                
                result = False
        else:            
            Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'outputReport::, : *onlyDI* : tasks or flows unschedulable', DebugCat.DEBUG_CAT_SCHEDANALYSIS)
            result = False
        
        test_time_taken = time.clock() - test_start_time        
        self.recordSchedulabilityTest(stream_specs, test_time_taken)
        
        return result
    
    
    # Shi and Burns basic tests for tasks and flows, treating everything independently     
    # only considering direct interference flows, not indirect interference  
    def performAnalysis_ShiAndBurns_onlyDI(self):
        
        # before performing analysis, reset lists
        self.unschedulable_flows = []
        self.unschedulable_tasks = []
        
        application_tasks = self.runtime_app_info.getTasks()
        application_flows = self.runtime_app_info.getFlows()
        
        # check tasks
        for t_ix, t in enumerate(application_tasks):                 
            t_wcet = t.getResponseTime(t.getInterferenceSet_withPrCnst(application_tasks))            
            self.runtime_app_info.setTask_analytical_wcet(t.get_id(), t_wcet)   # stored for later use
            
            percentage_of_t_wcet = float(t_wcet*(float(SimParams.WCRT_SCHEDULABILITY_TEST_PERCENTAGE)/100.0))            
            if percentage_of_t_wcet > t.get_end_to_end_deadline():
                self.unschedulable_tasks.append(t)                
                return False    # return immediately, to save time                
                
        # check flows
        for f_ix, f in enumerate(application_flows):
            
            # set release jitter again
            f_source_t = f.get_respectiveSrcTask()
            
            #rj = f_source_t.getResponseTime(f_source_t.getInterferenceSet_withPrCnst(self.runtime_app_info.getTasks()))
            
            rj = self.runtime_app_info.getTask_analytical_wcet(f_source_t.get_id())
            
            f.set_releaseJitter(rj)            
            f_wcet = f.getDirectInterferenceWorstCaseLatency(application_flows)            
            f_key = str(f.get_respectiveSrcTaskId()) + "_" + str(f.get_respectiveDstTaskId())
            self.runtime_app_info.setFlow_analytical_wcet(f_key, f_wcet)    # stored for later use                     
            
            percentage_of_f_wcet = float(f_wcet*(float(SimParams.WCRT_SCHEDULABILITY_TEST_PERCENTAGE)/100.0)) 
            if percentage_of_f_wcet > f.get_period():                  
                self.unschedulable_flows.append(f)
                
#                print "f_wcet=" + str(f_wcet)
#                print "percentage_of_f_wcet=" + str(percentage_of_f_wcet)
                
                return False    # return immediately, to save time
            
#            print "f_wcet=" + str(f_wcet)
#            print "percentage_of_f_wcet=" + str(percentage_of_f_wcet)
        
        return True
    
               
    
    # Shi and Burns basic tests for tasks and flows, treating everything independently       
    def performAnalysis_ShiAndBurns(self):
        
        # before performing analysis, reset lists
        self.unschedulable_flows = []
        self.unschedulable_tasks = []
        
        application_tasks = self.runtime_app_info.getTasks()
        application_flows = self.runtime_app_info.getFlows()
        
        # check tasks
        for t_ix, t in enumerate(application_tasks):                 
            t_wcet = t.getResponseTime(t.getInterferenceSet_withPrCnst(application_tasks))            
            self.runtime_app_info.setTask_analytical_wcet(t.get_id(), t_wcet)   # stored for later use            
            
            percentage_of_t_wcet = float(t_wcet*(float(SimParams.WCRT_SCHEDULABILITY_TEST_PERCENTAGE)/100.0))            
            if percentage_of_t_wcet > t.get_end_to_end_deadline():
                self.unschedulable_tasks.append(t)
                
#                print "t_wcet=" + str(t_wcet)
#                print "percentage_of_t_wcet=" + str(percentage_of_t_wcet)
                                
                return False    # return immediately, to save time
                
                
        # check flows
        for f_ix, f in enumerate(application_flows):
            
            # set release jitter again
            f_source_t = f.get_respectiveSrcTask()
            
            #rj = f_source_t.getResponseTime(f_source_t.getInterferenceSet_withPrCnst(self.runtime_app_info.getTasks()))            
            rj = self.runtime_app_info.getTask_analytical_wcet(f_source_t.get_id())
            
            f.set_releaseJitter(rj)
            timeout = datetime.utcnow() + timedelta(seconds = SimParams.WCRT_FLOW_CALC_TIMEOUT/float(len(application_flows)))            
            f_wcet = f.getWorstCaseLatency(application_flows, timeout)            
            f_key = str(f.get_respectiveSrcTaskId()) + "_" + str(f.get_respectiveDstTaskId())
            self.runtime_app_info.setFlow_analytical_wcet(f_key, f_wcet)    # stored for later use                     
            
            percentage_of_f_wcet = float(f_wcet*(float(SimParams.WCRT_SCHEDULABILITY_TEST_PERCENTAGE)/100.0))
            if percentage_of_f_wcet > f.get_period():
                self.unschedulable_flows.append(f)     
#                print "f_wcet=" + str(f_wcet)
#                print "percentage_of_f_wcet=" + str(percentage_of_f_wcet)           
                return False    # return immediately, to save time
            
#            print "f_wcet=" + str(f_wcet)
#            print "percentage_of_f_wcet=" + str(percentage_of_f_wcet)        
        
        return True
               
        # check results
#        if (len(self.unschedulable_tasks) > 0) or (len(self.unschedulable_flows) > 0):
#            return False
#        else:
#            return True
    
    
    # is critical path cost less than the end-to-end deadline
    # NB: need to obtain the wcet results of tasks and flows before calling this  
    def performAnalysis_criticalPath(self, peform_wcet_analysis=True):
        
        if(peform_wcet_analysis == False):
            self.performAnalysis_ShiAndBurns()        
        
        unschedulable_critical_paths = []
        
        # find the streams currently active
        for each_stream in self.runtime_app_info.getStreams():
            
            # get critical paths for this stream
            paths = self.runtime_app_info.getTask(0, each_stream.get_wfid(), each_stream.get_stream_id()).getCriticalPaths()            
            p_results = {}
            
            for p_ix, each_p in enumerate(paths):  # list of tasks
                total_path_cost = 0.0
                for ix, t_ix in enumerate(each_p):   # frame index in gop
                    
                    if(ix < len(each_p)-1):    # task has an outward flow
                        T_src = self.runtime_app_info.getTask(each_p[ix], each_stream.get_wfid(), each_stream.get_stream_id())
                        T_dst = self.runtime_app_info.getTask(each_p[ix+1], each_stream.get_wfid(), each_stream.get_stream_id())                    
                        T_src_wcet = T_src.get_analytical_wcet()                        
                        f = self._getFlow_t2t(T_src.get_id(), each_p[ix+1], self.runtime_app_info.getFlows())
                        if(f!=None):                            
                            total_path_cost = total_path_cost + T_src_wcet + f.get_analytical_wcet()
                        else:
                            total_path_cost = total_path_cost + T_src_wcet
                            
                    else:   # task does not have an outward flow
                        T_src = self.runtime_app_info.getTask(each_p[ix], each_stream.get_wfid(), each_stream.get_stream_id())
                        T_src_wcet = T_src.get_analytical_wcet()
                        total_path_cost = total_path_cost + T_src_wcet
                        
                p_results[p_ix] = {
                                   'path' : each_p,
                                   'total_path_cost' :  total_path_cost
                                   }           
                    
            # find longest path
            cp = max(data['total_path_cost'] for data in p_results.values())
            cp_key = [k for k in p_results if p_results[k]['total_path_cost'] == cp]
            cp_key = cp_key[0]
            
            # save result
            stream_key = str(each_stream.get_wfid()) + "_" + str(each_stream.get_stream_id())  # hash
            self.runtime_app_info.setStream_critical_path_wcet(stream_key, cp)
            
            # if longest path is larger than end-2-end deadline, then job is not schedulable
            percentage_of_cp_wcc = float(cp*(float(SimParams.WCRT_SCHEDULABILITY_TEST_PERCENTAGE)/100.0))
            
#            print "cp=" + str(cp)
#            print "percentage_of_cp_wcc=" + str(percentage_of_cp_wcc)
            
            if(percentage_of_cp_wcc > each_stream.get_end2end_deadline()):
                unschedulable_critical_paths.append([each_stream, each_p, cp])                 
                return False           
        
#        if(len(unschedulable_critical_paths) > 0):
#            return False
#        else:
#            return True
                
        return True
                
            
            
        
    @staticmethod
    def cleanOutputReports(dirPath):            
        fileList = os.listdir(dirPath)
        for fileName in fileList:
            os.remove(dirPath+"/"+fileName)
    
    
    
    ###################################
    # For debug/reporting purposes
    ###################################
   
    # output schedulability test to log file
    def outputReport_ShiAndBurns(self, fname):    
        
        Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'outputReport::, : Enter', DebugCat.DEBUG_CAT_SCHEDANALYSIS)
        
        # output the flows and tasks properties
        application_streams = self.runtime_app_info.getStreams()
        application_tasks = self.runtime_app_info.getTasks()
        application_flows = self.runtime_app_info.getFlows()
                
        file = open(fname, "w")        
        file.write("<SchedulabilityReport>")  
        
        ##############################
        ## basic STREAM info
        ##############################
        file.write("<AppStreams>")
        for s_ix, s in enumerate(application_streams):
            
            sched_report_entry = "<Stream"
            sched_report_entry += s.getSchedulability_toString()            
            sched_report_entry += " />"            
            file.write(sched_report_entry)
            
        file.write("</AppStreams>")    
        
        ##############################
        ## TASK schedulability results
        ##############################
        file.write("<AppTasks>")
        
        Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'outputReport::, : Task analysis', DebugCat.DEBUG_CAT_SCHEDANALYSIS)
                
        for t_ix, t in enumerate(application_tasks):
            t_prop = t.getSchedulability_toString()            
            t_wcet = t.getResponseTime(t.getInterferenceSet_withPrCnst(application_tasks))
            
            self.runtime_app_info.setTask_analytical_wcet(t.get_id(), t_wcet)
            
            if t_wcet > t.get_end_to_end_deadline():  sched_result = False
            else:  sched_result = True
            
            sched_report_entry = "<Task"
            sched_report_entry += t_prop
            sched_report_entry += " wcet='" + str(t_wcet) + "' sch_r='" + str(sched_result)+ "'"
            sched_report_entry += " />"            
            file.write(sched_report_entry)
        
        file.write("</AppTasks>")        
            
        ##############################
        ## FLOWS schedulability results
        ##############################   
        file.write("<AppFlows>")
        
        Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'outputReport::, : Flow analysis', DebugCat.DEBUG_CAT_SCHEDANALYSIS)
                
        for f_ix, f in enumerate(application_flows):            
            
            # set release jitter 
            f_prop = f.getSchedulability_toString()            
            f_BL = f.getBasicLatency()
            f_nDISet = len(f.getDirectInterferenceSet(application_flows))
            f_nIISet = len(f.getIndirectInterferenceSet(application_flows))
            f_nDISet_wPC = len(f.getDirectInterferenceSet_withPrCnst(application_flows))
            f_nIISet_wPC = len(f.getIndirectInterferenceSet_withPrCnst(application_flows))
            f_wcet = f.getWorstCaseLatency(application_flows, None)
            
            f_key = str(f.get_respectiveSrcTaskId()) + "_" + str(f.get_respectiveDstTaskId())
            self.runtime_app_info.setFlow_analytical_wcet(f_key, f_wcet)                         
            
            if f_wcet > f.get_period():  sched_result = False
            else:  sched_result = True
            
            sched_report_entry = "<Flow"
            sched_report_entry += f_prop
            sched_report_entry += " bl='" + str(f_BL) + "' nDI='" + str(f_nDISet) + "' nII='" + str(f_nIISet) + "' nDI_wPC='" + str(f_nDISet_wPC) + "' nII_wPC='" + str(f_nIISet_wPC) + "' wcet='" + str(f_wcet)+ "'"
            sched_report_entry += " sch_r='" + str(sched_result)+ "'"
            sched_report_entry += " />"            
            file.write(sched_report_entry)
        
        file.write("</AppFlows>")
        
        ##############################
        ## critical path analysis
        ##############################         
        sched_report_entry = self.outputReport_criticalPathAnalysis()
        file.write(sched_report_entry)        
        
        file.write("</SchedulabilityReport>")
        
        
        
    def outputReport_criticalPathAnalysis(self):
        
        sched_report_entry = "<CriticalPathAnalysis>"
        
        # find the streams currently active
        for each_stream in self.runtime_app_info.getStreams():
            
            # get critical paths for this stream
            paths = self.runtime_app_info.getTask(0, each_stream.get_wfid(), each_stream.get_stream_id()).getCriticalPaths()
            
            p_results = {}
            
            for p_ix, each_p in enumerate(paths):  # list of tasks                
                #pprint.pprint(each_p)
                total_path_cost = 0.0
                for ix, t_ix in enumerate(each_p):   # frame index in gop
                    
                    if(ix < len(each_p)-1):    # task has an outward flow
                        T_src = self.runtime_app_info.getTask(each_p[ix], each_stream.get_wfid(), each_stream.get_stream_id())
                        T_dst = self.runtime_app_info.getTask(each_p[ix+1], each_stream.get_wfid(), each_stream.get_stream_id())                    
                        T_src_wcet = T_src.get_analytical_wcet()                        
                        f = self._getFlow_t2t(T_src.get_id(), each_p[ix+1], self.runtime_app_info.getFlows())
                        if(f!=None): 
                            total_path_cost = total_path_cost + T_src_wcet + f.get_analytical_wcet()
                        else:
                            total_path_cost = total_path_cost + T_src_wcet
                            
                    else:   # task does not have an outward flow
                        T_src = self.runtime_app_info.getTask(each_p[ix], each_stream.get_wfid(), each_stream.get_stream_id())
                        T_src_wcet = T_src.get_analytical_wcet()
                        total_path_cost = total_path_cost + T_src_wcet
                        
                p_results[p_ix] = {
                                   'path' : each_p,
                                   'total_path_cost' :  total_path_cost
                                   }            
                    
            # find longest path
            cp = max(data['total_path_cost'] for data in p_results.values())
            cp_key = [k for k in p_results if p_results[k]['total_path_cost'] == cp]
            cp_key = cp_key[0]
            
            sched_report_entry += "<CP wfid='" + str(each_stream.get_wfid()) + "' stid='" + str(each_stream.get_stream_id()) + "' cp='" + str(p_results[cp_key]['path']) + "' cp_cost='" + str(cp) + "' />"
        
        sched_report_entry += "</CriticalPathAnalysis>"
        
        return sched_report_entry
    
    def _getFlow_t2t(self, src_task_id, dst_task_ix, all_flows ):
        
        for each_f in all_flows:
            if (each_f.get_respectiveSrcTaskId() == src_task_id) and (dst_task_ix in each_f.get_respectiveDstTaskId()):
                return each_f
        
        return None
                 
            
                    
                    
                    
                    
            
        
        
        
        
        
    ## getters/setters    
    
    
