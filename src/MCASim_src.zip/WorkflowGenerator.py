import pprint
import sys
import math, random
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import scipy.stats
from matplotlib.colors import ListedColormap, NoNorm
from matplotlib import mlab
from itertools import cycle # for automatic markers

import matplotlib.cm as cm
from matplotlib.font_manager import FontProperties

## local imports
import Task
import Buffer
from SimParams import SimParams
from TaskSet import TaskSet


class WorkflowGenerator():
    def __init__(self, env, max_wf, min_videos_per_wf, max_videos_per_wf, min_gops_per_video, max_gops_per_video, max_inter_video_gap, min_inter_video_gap, min_interarrival, max_interarrival):
         
        self.env = env
        self.max_wf = max_wf  
        self.min_videos = min_videos_per_wf    
        self.max_videos = max_videos_per_wf
        self.min_gops_per_video = min_gops_per_video
        self.max_gops_per_video = max_gops_per_video
        self.max_inter_video_gap = max_inter_video_gap
        self.min_inter_video_gap = min_inter_video_gap
        self.min_interarrival = min_interarrival
        self.max_interarrival = max_interarrival
        self.workflows = {}
      
        # for later use
        self.max_task_priority = None
        self.used_pri_values = []
        
        
        self.workflows_summary = {}
    
    ##################
    # getters/setters
    ##################
    def get_max_task_priority(self):
        return self.max_task_priority
    def get_used_pri_values(self):
        return self.used_pri_values
    
    
        
    def generate_workflows(self):
                
        task_start_id = 0        
        unique_job_start_id = 0        
        
        priority_offset = 0
        
        for each_wf_id in xrange(self.max_wf):
                   
            
            num_vids = random.randint(self.min_videos, self.max_videos)     # determine number of videos for this workflow       
            
            initial_gap = random.uniform(SimParams.TASKDISPATCHER_RESET_DELAY, self.max_inter_video_gap*2) # initially we want a gap, we don't want all streams to start at once
            
            jobs_start_time = initial_gap   
            
            self.workflows[each_wf_id] = []            
            self.workflows_summary[each_wf_id] = {}
            for each_vid in xrange(num_vids):
                job_start_id = 0
                
                resolution = random.choice(SimParams.DVB_RESOLUTIONS)
                (jobs_list, job_endtime, num_jobs, avg_dt, min_dt) = self._generate_jobs(job_start_id, unique_job_start_id,
                                    task_start_id,
                                    self.min_gops_per_video,                                
                                    self.max_gops_per_video,
                                    each_vid, each_wf_id,
                                    SimParams.GOP_STRUCTURE,
                                    jobs_start_time,
                                    resolution[1],
                                    resolution[0],
                                    SimParams.FRAME_RATE                                                                    
                                    )
                
                temp_frames = {}
                temp_gops = []
                for each_task in jobs_list:
                    if(each_task.get_unique_gop_id() not in temp_frames):
                        temp_frames[each_task.get_unique_gop_id()] = [each_task.get_id()]
                        temp_gops.append(each_task.get_unique_gop_id())
                    else:
                        temp_frames[each_task.get_unique_gop_id()].append(each_task.get_id())
                
                self.workflows_summary[each_wf_id][each_vid] = {}
                self.workflows_summary[each_wf_id][each_vid]={
                                                              'starttime' : jobs_start_time,                                                              
                                                              'endtime' : job_endtime,
                                                              'framerate' : SimParams.FRAME_RATE,
                                                              'avg_dispatch_rate' : avg_dt,
                                                              'min_dispatch_rate' : min_dt,
                                                              'gop_len' : SimParams.GOP_LENGTH,
                                                              'numgops' : num_jobs,
                                                              'resolution' : resolution,
                                                              'frames' : temp_frames,
                                                              'gops' :  temp_gops                                                           
                                                              }                
                # reset times and ids
                gap = random.uniform(self.min_inter_video_gap, self.max_inter_video_gap)
                jobs_start_time =  job_endtime + gap
                
                #job_start_id += 1
                unique_job_start_id = jobs_list[len(jobs_list)-1].get_unique_gop_id() + 1                
                task_start_id += len(jobs_list)                           
                
                self.workflows[each_wf_id].extend(jobs_list)
                
                # save workflow summary
                workflow_logfile=open('workflow_summary.js', 'w')
                pprint.pprint(self.workflows_summary, workflow_logfile, width=128)
                
            print '%f'%self.env.now + "," + "WorkflowGenerator::, finished generating wf_id = " + str(each_wf_id)
    
    
    def getLastScheduledTask(self):
        tmptasks = []
        for each_wf_key, each_wf_val in self.workflows.iteritems():
            tmptasks.append(each_wf_val[len(each_wf_val)-1])
            
        sorted_tmptasks = sorted(tmptasks, key=lambda x: x.get_scheduledDispatchTime(), reverse=True)
        
        return sorted_tmptasks[0]
    
    
    
    
    def setTaskPriorities_AllUnique(self):
        # how many tasks have been created in total ?
        task_count = 0
        for each_wf in self.workflows.itervalues():
            task_count += len(each_wf)
            
        # generate unique random numbers, enough for every task generated
        random_unique_pri_list = random.sample(range(1,task_count+1), task_count)
        
        # apply unique priorities for each task in the workflow
        i=0
        for each_wf in self.workflows.itervalues():
            for each_task in each_wf:
                each_task.set_priority(random_unique_pri_list[i])
                i+=1 
                
        # whats the max priority set ?
        self.max_task_priority = max(random_unique_pri_list)       
        
        
    def setTaskPriorities_GroupedByJobs(self):
        i=1
    
    def setTaskPriorities_GroupedByVids(self):
        i=1
           
    # generate all the gops for a video stream        
    def _generate_jobs(self, job_start_id, unique_job_start_id,  
                       task_start_id, min_jobs, max_jobs, video_stream_id, wf_id,
                       gop_struct, jobs_dispatchtime_start, frame_h, frame_w, fps):
                
        num_gops =  random.randint(min_jobs, max_jobs)
        
        # therefore the end-time ?
        job_end_time = jobs_dispatchtime_start + ((float(num_gops) * float(len(gop_struct))) / (float(fps) * 60.0))
                
        taskset = TaskSet(self.env) 
        
        # generate new priorities, excluding the ones already in the pool
        pri_range = self._genRandomNumList(SimParams.GOP_LENGTH,self.used_pri_values)
        if (len(pri_range) < SimParams.GOP_LENGTH):
            sys.exit('error generating priorities')
        else:
            self.used_pri_values.extend(pri_range)
        
        
        # generate multiple gops
        final_dispatch_time, avg_dt, min_dt = taskset.generateMPEG2FrameTaskSet(num_gops, task_start_id , job_start_id, unique_job_start_id,
                                          taskset_dispatch_start_time = jobs_dispatchtime_start,
                                          video_stream_id = video_stream_id,
                                          wf_id = wf_id,
                                          frame_w=frame_w,
                                          frame_h=frame_h,
                                          priority_range = pri_range)
        
        # set the worst-case exuction time for all tasks in the task_pool
        taskset.set_worstCaseComputationTime_alltasks()
        
        if(final_dispatch_time > job_end_time):
            job_end_time = final_dispatch_time        
        
        return  (taskset.taskList, job_end_time, num_gops, avg_dt, min_dt)
        
    
    def _remove_dups(self,seq):
        seen = set()
        seen_add = seen.add
        return [ x for x in seq if x not in seen and not seen_add(x)]
        
    
    
    
    
    
    
    def dumpWorkflowsToFile(self, fname="workflows.xml"):
       
        file = open(fname, "w")
        
        file.write("<Workflows>")
        
        for each_wf_key, each_wf_values in self.workflows.iteritems():   
            file.write("<workflow id='%d'>" % each_wf_key)
            for each_task in each_wf_values :
                #pprint.pprint(each_task)
                file.write( each_task._debugLongXML() )
                file.write("\n")
            
            file.write("</workflow>")           
        
        file.write("</Workflows>")            
        file.close()
        
    def showTaskTimeLine(self, num_wfs, simon_wf_results_summary = None, fname = 'showTaskTimeLine.png'):
        
        print "showTaskTimeLine: Enter"
        num_workflows = len(self.workflows.items())
        print "num_workflows=" + str(num_workflows)
        
        fig = plt.figure(dpi=100, figsize=(20.0, float(num_workflows)*1.5))
        
        annot_text = {
                          "wf_vid_id": [],
                          "x": [],
                          "y" : [],
                          "text" : [],
                          "colour" : []
                          }
        for each_wf_key, each_wf_values in self.workflows.iteritems():                           
            #ax = plt.subplot(1,num_workflows,each_wf_key)
            
            dispatch_times = []
            vid_count = 0
            
            for each_task in each_wf_values :                
                sdt = each_task.get_scheduledDispatchTime()
                dispatch_times.append(round(sdt,2))
                
                if(each_task.get_parentGopId() == 0 and each_task.get_frameIXinGOP() == 0):
                    annot_text["wf_vid_id"].append((each_wf_key, vid_count))
                    annot_text["x"].append(round(sdt,2))
                    annot_text["y"].append(each_wf_key+0.16)                    
                    text = str(each_task.get_frame_w()) + "x" + str(each_task.get_frame_h()) + "\n" + \
                                str(round(self.workflows_summary[each_wf_key][vid_count]['avg_dispatch_rate'],3)) + "\n" + \
                                str(each_task.get_scheduledDispatchTime()) #str(round(self.workflows_summary[each_wf_key][vid_count]['min_dispatch_rate'],3))
                                
                                                
                    annot_text["text"].append(text)
                    
                    if(simon_wf_results_summary != None):
                     
                        try:                        
                            if(simon_wf_results_summary[each_wf_key][vid_count]['result'] == True):
                                annot_text["colour"].append('green')
                            else:
                                if(len(simon_wf_results_summary[each_wf_key][vid_count]['gops_in_outbuff']) > 0):
                                    annot_text["colour"].append('#FF00AA')
                                else:
                                    annot_text["colour"].append('#ff0000')
                        except:
                            annot_text["colour"].append("black")
                    
                    vid_count = vid_count + 1
                               
            x = np.round(np.arange(0.0, max(dispatch_times), 0.01), 2)          
            
            i = 0
            y = [-1] * len(x) 
            for each_x in x:                
                if(each_x in dispatch_times):
                    y[i] = each_wf_key
                i = i+1
        
            plt.scatter(x,y, s=2)
            plt.hold(True)         
        
        plt.minorticks_on()
        plt.grid(True, which='major', color='b', linestyle='-', alpha=0.2)
        plt.grid(True, which='minor', color='b', linestyle='--', alpha=0.2)
        
        #pprint.pprint(annot_text)
        
        if(simon_wf_results_summary != None):
            for i, x in enumerate(annot_text["x"]):            
                plt.annotate(annot_text["text"][i], (annot_text["x"][i],annot_text["y"][i]), color=annot_text["colour"][i], fontsize=6)
        else:
            for i, x in enumerate(annot_text["x"]):            
                plt.annotate(annot_text["text"][i], (annot_text["x"][i],annot_text["y"][i]), fontsize=6)
        
        print "showTaskTimeLine: saving image : " + fname
        plt.savefig(fname, bbox_inches='tight', dpi=100)
        
        plt.close(fig)
        
        
        
            
    @staticmethod
    def plot_show():
        plt.show()
                
            
            
    ######################
    ## helper functions ##
    ######################
    
    def _genRandomNumList(self, list_len, exclusion_list):
        
        count = 0
        result = []
        
        max_int = (SimParams.NUM_WORKFLOWS * SimParams.WFGEN_MAX_VIDS_PER_WF * SimParams.GOP_LENGTH) + \
                (SimParams.NUM_WORKFLOWS * SimParams.WFGEN_MAX_VIDS_PER_WF)
        
        while (count < list_len):
            random_num = random.randint(1,max_int)
            
            if(random_num not in exclusion_list):
                result.append(random_num)
                count += 1
            
        return result
            
            
                
                
                
            
        
                
            
                    