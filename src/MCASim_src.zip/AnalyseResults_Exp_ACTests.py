import sys, os, csv, pprint, math

import numpy as np
import random
import shutil
import math
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import scipy.stats
from matplotlib.colors import ListedColormap, NoNorm
from matplotlib import mlab
from itertools import cycle # for automatic markers
import json

import matplotlib.cm as cm
from matplotlib.font_manager import FontProperties

from AdmissionControllerOptions import AdmissionControllerOptions
from SimParams import SimParams


import Multicore_MPEG_Model as MMMSim


NUM_WORKFLOWS = range(8, 15, 2)
#NUM_WORKFLOWS = [9]
#NUM_NODES = [2,4,8,16,32]
NUM_NODES = 9
NOC_XY = [(2,1), (2,2), (2,4), (2,8), (2,16)]


# Admission control tests :
# - heu based
# - sched based
# - hybrid
def plot_ACTest_Results_VidStats():
    
    ##############################
    ####### gather results 
    ##############################
    exp_data = []    
    for each_wf_num in NUM_WORKFLOWS:
        
        
        #exp_data[each_wf_num] = {}
        
        #### ac_test : heuristics only        
        FNAME_PREFIX = "ACTest_heu_"
        vs_bs_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(each_wf_num)+'_cores'+str(SimParams.NUM_NODES) + ".js"
        json_data=open(vs_bs_fname)
        file_data = json.load(json_data)        
        heu_entry = _getEntry(file_data)          
        
        #### ac_test : schedulability test only        
        FNAME_PREFIX = "ACTest_sched_"
        vs_bs_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(each_wf_num)+'_cores'+str(SimParams.NUM_NODES) + ".js"
        json_data=open(vs_bs_fname)
        file_data = json.load(json_data)        
        sched_entry = _getEntry(file_data)       
        
        #### ac_test : combines heuristics + sched test        
        FNAME_PREFIX = "ACTest_hybv1_"
        vs_bs_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(each_wf_num)+'_cores'+str(SimParams.NUM_NODES) + ".js"
        json_data=open(vs_bs_fname)
        file_data = json.load(json_data)        
        hybv1_entry = _getEntry(file_data)
        
        #### ac_test : combines heuristics + sched test        
#        FNAME_PREFIX = "ACTest_hybv2_"
#        vs_bs_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(each_wf_num)+'_cores'+str(SimParams.NUM_NODES) + ".js"
#        json_data=open(vs_bs_fname)
#        file_data = json.load(json_data)        
#        hybv2_entry = _getEntry(file_data)
        
        temp = {
                "heu" : heu_entry,
                "sched" : sched_entry,
                "hybv1" : hybv1_entry,
#                "hybv2" : hybv1_entry
                }  
        exp_data.append(temp)
        
    
    ##############################
    ####### plot results
    ##############################
    # labels are wf nums
    labels = [str(x) for x in NUM_WORKFLOWS] 
    
    results_category = [
                         "num_vids_accepted_success", 
                         "num_dropped_tasks", 
                         "num_vids_accepted_late", 
                         "num_vids_rejected"
                        ]
    
    
    for ix, each_rc in enumerate(results_category):
    
        # ----------------------------------
        #### plot - num_vids_accepted_success
        fig = plt.figure(ix)
        fig.canvas.set_window_title(each_rc)
        ax = plt.subplot(111)
            
        # avg-lateness
        success_heu = [x["heu"][each_rc] for x in exp_data]
        success_sched = [x["sched"][each_rc] for x in exp_data]
        success_hybv1 = [x["hybv1"][each_rc] for x in exp_data]
#        success_hybv2 = [x["hybv2"][each_rc] for x in exp_data]
        
        ind = np.arange(len(success_heu))
        width = 0.20
        
        rects1 = ax.bar(ind, success_heu, width, color='r')
        rects2 = ax.bar(ind+width, success_sched, width, color='g')
        rects3 = ax.bar(ind+(2.0*width), success_hybv1, width, color='b')
#        rects4 = ax.bar(ind+(3.0*width), success_hybv2, width, color='y')
        
        ax.set_ylabel(each_rc,fontsize=18)
        ax.set_xlabel('Workflows',fontsize=18)
        #ax.set_title('Maximum lateness',fontsize=18)
        plt.tick_params(axis='both', which='major', labelsize=16)    
        ax.set_xticks(ind+width)
        ax.set_xticklabels( labels )
    
        leg = ax.legend( (rects1[0], rects2[0], rects3[0]), ('Heuristics', 'Sched', 'Hybr-v1', 'Hybr-v2') )    
        leg.draggable()
    
   
def plot_InstUtilisation():
        
        
    ##############################
    ####### gather results 
    ##############################   
        
    folder = 'experiment_data/vs_ac_test/'
    
    actest_heu_all_data = []
    actest_sched_all_data = []
    actest_hybv1_all_data = []
    
    for each_wf_num in NUM_WORKFLOWS:
        
        ## heuristics ##
        # get data        
        fname =  folder + "ACTest_heu_" +'wf'+str(each_wf_num)+'_cores'+str(SimParams.NUM_NODES) + "__utilisation.js"
        json_data=open(fname)
        actest_heu_all_data.append(json.load(json_data))        
        
        
        ## sched-test ##
        # get data
        data = []
        fname =  folder + "ACTest_sched_" +'wf'+str(each_wf_num)+'_cores'+str(SimParams.NUM_NODES) + "__utilisation.js"      
        json_data=open(fname)            
        actest_sched_all_data.append(json.load(json_data))   
        
        ## hybrid_v1 ##
        data = []
        fname =  folder + "ACTest_hybv1_" +'wf'+str(each_wf_num)+'_cores'+str(SimParams.NUM_NODES) + "__utilisation.js"
        json_data=open(fname)            
        actest_hybv1_all_data.append(json.load(json_data))
        
        
    ##############################
    ####### format data
    ##############################
    
    
    ## for heuristic based ##
    allwfs_node_usage_heu = []
    for wf_id in xrange(len(NUM_WORKFLOWS)):
        node_usage_heu = [[] for i in range(NUM_NODES)] # init
        
        for each_data_point in actest_heu_all_data[wf_id]:
            for each_node_id in xrange(NUM_NODES):
                node_usage_heu[each_node_id].append(each_data_point['csp_tc'][each_node_id])
        
        allwfs_node_usage_heu.append(node_usage_heu)
                    
    
    ## for shed based ##
    allwfs_node_usage_sched = []
    for wf_id in xrange(len(NUM_WORKFLOWS)):
        node_usage_sched = [[] for i in range(NUM_NODES)] # init
        
        for each_data_point in actest_sched_all_data[wf_id]:
            for each_node_id in xrange(NUM_NODES):
                node_usage_sched[each_node_id].append(each_data_point['csp_tc'][each_node_id])
    
        allwfs_node_usage_sched.append(node_usage_sched)
    
    
    ## for hybv1 based ##
    allwfs_node_usage_hybv1 = []
    for wf_id in xrange(len(NUM_WORKFLOWS)):
        node_usage_hybv1 = [[] for i in range(NUM_NODES)] # init
        
        for each_data_point in actest_hybv1_all_data[wf_id]:
            for each_node_id in xrange(NUM_NODES):
                node_usage_hybv1[each_node_id].append(each_data_point['csp_tc'][each_node_id])
    
        allwfs_node_usage_hybv1.append(node_usage_hybv1)
    
    
    ##############################
    ####### plot histogram 
    ##############################
    for wf_id in xrange(len(NUM_WORKFLOWS)):

        fig = plt.figure()
        fig.canvas.set_window_title("NumWorkflows = " + str(NUM_WORKFLOWS[wf_id]))
        ax = plt.subplot(111)
        
        boxpos_nu_hue=range(1,len(allwfs_node_usage_heu[wf_id])*3,3)
        boxpos_nu_sched=range(2,(len(allwfs_node_usage_sched[wf_id])*3)+2,3)
        boxpos_nu_hybv1=range(3,(len(allwfs_node_usage_hybv1[wf_id])*3)+3,3)
        
        labels = [str(x) for x in range(NUM_NODES)]    
        
        # plot box plots
        bp=plt.boxplot(allwfs_node_usage_heu[wf_id],0,'', whis=1, positions=boxpos_nu_hue)
        plt.setp(bp['boxes'], color='blue', linewidth=1)
        plt.setp(bp['caps'], color='blue')
        plt.setp(bp['whiskers'], color='blue')
        plt.setp(bp['fliers'], color='blue')
        plt.setp(bp['medians'], color='blue')
        
        bp=plt.boxplot(allwfs_node_usage_sched[wf_id],0,'', whis=1, positions=boxpos_nu_sched)
        plt.setp(bp['boxes'], color='red', linewidth=1)
        plt.setp(bp['caps'], color='red')
        plt.setp(bp['whiskers'], color='red')
        plt.setp(bp['fliers'], color='red')
        plt.setp(bp['medians'], color='red')
        
        bp=plt.boxplot(allwfs_node_usage_hybv1[wf_id],0,'', whis=1, positions=boxpos_nu_hybv1)
        plt.setp(bp['boxes'], color='green', linewidth=1)
        plt.setp(bp['caps'], color='green')
        plt.setp(bp['whiskers'], color='green')
        plt.setp(bp['fliers'], color='green')
        plt.setp(bp['medians'], color='green')
        
        ## figure specs
        plt.xlabel('Nodes',fontsize=18)
        plt.ylabel('Tasks completed',fontsize=18)
        #plt.setxticks(range(1,len(dyn_results['labels'])+1), dyn_results['labels'])
        ax.set_xticklabels(labels)
        
        xticks = range(1,(len(labels)*3),3)
        xticks = [x+0.5 for x in xticks]
        
        ax.set_xticks(xticks)
        plt.xlim(0,(len(labels)*3)+1)
        #plt.ylim(-0.35,-0.25)
        ax.yaxis.grid(True)
        ax.xaxis.grid(True)
        plt.tick_params(axis='both', which='major', labelsize=16)
        
        hB, = plt.plot([1,1],'b-')
        hR, = plt.plot([1,1],'r-')
        hG, = plt.plot([1,1],'g-')
        leg = plt.legend((hB, hR, hG),('Heu', 'Sched', 'hybv1'))
        leg.draggable()
        hB.set_visible(False)
        hR.set_visible(False)
        hG.set_visible(False)
        
        # plot means
        plt.hold(True)
        means_heu = [np.mean(x) for x in allwfs_node_usage_heu[wf_id]]
        plt.plot(boxpos_nu_hue, means_heu, marker='*', linestyle='-', color='b', linewidth=3)
        plt.hold(True)
        means_sched = [np.mean(x) for x in allwfs_node_usage_sched[wf_id]]
        plt.plot(boxpos_nu_sched, means_sched, marker='*', linestyle='-', color='r', linewidth=3)
        plt.hold(True)
        means_hybv1 = [np.mean(x) for x in allwfs_node_usage_hybv1[wf_id]]
        plt.plot(boxpos_nu_hybv1, means_hybv1, marker='*', linestyle='-', color='g', linewidth=3)
        
        

def plot_GOPLateness():
        
        
    ##############################
    ####### gather results 
    ##############################   
        
    folder = 'experiment_data/vs_ac_test/'
    
    actest_heu_all_data = []
    actest_sched_all_data = []
    actest_hybv1_all_data = []
    
    for each_wf_num in NUM_WORKFLOWS:
        
        ## heuristics ##
        # get data        
        fname =  folder + "ACTest_heu_" +'wf'+str(each_wf_num)+'_cores'+str(SimParams.NUM_NODES) + "_gopsopbuffsumm.js"
        json_data=open(fname)
        actest_heu_all_data.append(json.load(json_data))        
        
        
        ## sched-test ##
        # get data
        data = []
        fname =  folder + "ACTest_sched_" +'wf'+str(each_wf_num)+'_cores'+str(SimParams.NUM_NODES) + "_gopsopbuffsumm.js"      
        json_data=open(fname)            
        actest_sched_all_data.append(json.load(json_data))   
        
        ## hybrid_v1 ##
        data = []
        fname =  folder + "ACTest_hybv1_" +'wf'+str(each_wf_num)+'_cores'+str(SimParams.NUM_NODES) + "_gopsopbuffsumm.js"
        json_data=open(fname)            
        actest_hybv1_all_data.append(json.load(json_data))
        
        
    ##############################
    ####### format data
    ##############################
    
    
    ## for heuristic based ##
    allwfs_goplateness_heu = []
    for wf_id in xrange(len(NUM_WORKFLOWS)):
        gop_lateness_heu = [[] for i in range(NUM_NODES)] # init        
        for each_ugid_key, each_ugid_val in actest_heu_all_data[wf_id].iteritems():            
                gop_lateness_heu.append(each_ugid_val['gop_execution_lateness'])
        
        allwfs_goplateness_heu.append(gop_lateness_heu)
    
    
    ## for hybv1 based ##
    allwfs_goplateness_hybv1 = []
    for wf_id in xrange(len(NUM_WORKFLOWS)):
        gop_lateness_hybv1 = [[] for i in range(NUM_NODES)] # init        
        for each_ugid_key, each_ugid_val in actest_hybv1_all_data[wf_id].iteritems():            
                gop_lateness_hybv1.append(each_ugid_val['gop_execution_lateness'])
        
        allwfs_goplateness_hybv1.append(gop_lateness_hybv1)
    
    
    
    ##############################
    ####### plot histogram 
    ##############################    

    fig = plt.figure()
    fig.canvas.set_window_title("Gop Lateness per wf")
    ax = plt.subplot(111)
    
    boxpos_gl_hue=range(1,len(allwfs_goplateness_heu)*2,2)
    boxpos_gl_hybv1=range(2,(len(allwfs_goplateness_hybv1)*2)+2,2)
    
    labels = [str(x) for x in NUM_WORKFLOWS]    
    
    # plot box plots
    bp=plt.boxplot(allwfs_goplateness_heu,0,'', whis=1, positions=boxpos_gl_hue)
    plt.setp(bp['boxes'], color='blue', linewidth=1)
    plt.setp(bp['caps'], color='blue')
    plt.setp(bp['whiskers'], color='blue')
    plt.setp(bp['fliers'], color='blue')
    plt.setp(bp['medians'], color='blue')
    
    bp=plt.boxplot(allwfs_goplateness_hybv1,0,'', whis=1, positions=boxpos_gl_hybv1)
    plt.setp(bp['boxes'], color='green', linewidth=1)
    plt.setp(bp['caps'], color='green')
    plt.setp(bp['whiskers'], color='green')
    plt.setp(bp['fliers'], color='green')
    plt.setp(bp['medians'], color='green')
    
    ## figure specs
    plt.xlabel('workflows',fontsize=18)
    plt.ylabel('gop lateness',fontsize=18)
    #plt.setxticks(range(1,len(dyn_results['labels'])+1), dyn_results['labels'])
    ax.set_xticklabels(labels)
    
    xticks = range(1,(len(labels)*2),2)
    xticks = [x+0.5 for x in xticks]
    
    ax.set_xticks(xticks)
    plt.xlim(0,(len(labels)*2)+1)
    #plt.ylim(-0.35,-0.25)
    ax.yaxis.grid(True)
    ax.xaxis.grid(True)
    plt.tick_params(axis='both', which='major', labelsize=16)
    
    hB, = plt.plot([1,1],'b-')    
    hG, = plt.plot([1,1],'g-')
    leg = plt.legend((hB, hG),('Heu', 'hybv1'))
    leg.draggable()
    hB.set_visible(False)    
    hG.set_visible(False)
    
    # plot means
#    plt.hold(True)
#    means_heu = [np.mean(x) for x in allwfs_goplateness_heu]
#    plt.plot(boxpos_gl_hue, means_heu, marker='*', linestyle='-', color='b', linewidth=3)
#    plt.hold(True)    
#    means_hybv1 = [np.mean(x) for x in allwfs_goplateness_hybv1]
#    plt.plot(boxpos_gl_hybv1, means_hybv1, marker='*', linestyle='-', color='g', linewidth=3)


   
def plot_SchedulabilityPercentage_vs_DeadlineMiss():
    
    ##############################
    ####### gather results 
    ##############################
    
    percentage_list = range(0, 110, 10)
    
    NUM_WORKFLOWS = 10
    NUM_NODES = 9
    
    exp_data = []    
    for each_sched_percentage in percentage_list:
        
        FNAME_PREFIX = "ACTest_sched_p" + str(each_sched_percentage) + "_"
        EXP_OUTPUT_FOLDER = "sched_percentage_compare/"         
             
        #### ac_test : schedulability test only 
        vs_bs_fname = 'experiment_data/' + EXP_OUTPUT_FOLDER + FNAME_PREFIX + 'wf'+str(NUM_WORKFLOWS)+'_cores'+str(NUM_NODES) + ".js"
        json_data=open(vs_bs_fname)
        file_data = json.load(json_data)        
        
        exp_data.append(file_data)
        
    
    ##############################
    ####### plot results 
    ##############################
    num_vids_accepted_late = []
    
    for each_record in exp_data:
    
        num_vids_accepted_late.append(int(each_record['num_vids_accepted_late']))
        
    plt.plot(num_vids_accepted_late)
        
        
    
    
    
    
    
    
    
    
    
        
    
    
        
def _getEntry(file_data):
    
    entry =  {
            "num_vids_accepted_success": file_data['num_vids_accepted_success'], 
            "num_dropped_tasks": file_data['num_dropped_tasks'], 
            "num_vids_accepted_late": file_data['num_vids_accepted_late'], 
            "num_vids_rejected": file_data['num_vids_rejected']
        }
    
    return entry

def _getUtilData(fname):
    file = open(fname, 'r')        
    data = file.readlines()
    data = [(float(x.strip())) for x in data]        
    
    return data
    



#plot_ACTest_Results_VidStats()
#plot_InstUtilisation()
#plot_GOPLateness()
plot_SchedulabilityPercentage_vs_DeadlineMiss()
print "finished"

plt.show()

