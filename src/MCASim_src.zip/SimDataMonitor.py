from pprint import pprint
import simpy
import csv
import sys
import math
import os
import json

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import scipy.stats
from matplotlib.colors import ListedColormap, NoNorm
from matplotlib import mlab
from itertools import cycle # for automatic markers

import matplotlib.cm as cm
from matplotlib.font_manager import FontProperties

# local imports
from SimParams import SimParams
from Node import NodeStatus



class SimDataMonitor:
    def __init__(self, env, node_network, input_buffers, output_buffer, task_dispatcher, workflows, resource_manager):
        self.env = env
        self.node_network = node_network
        self.input_buffers = input_buffers
        self.output_buffer = output_buffer
        self.task_dispatcher = task_dispatcher
        self.workflows = workflows
        self.resource_manager = resource_manager
        self.label = "SimDataMonitor"
        self.fig_counter = 0
        
        self.ObjInputBuffTasks = []
        # objects to keep track of sim actors
        for each_ibuff_id in xrange(SimParams.NUM_INPUTBUFFERS):
            self.ObjInputBuffTasks.append([])
            
        self.ObjOutputBuffTasks = []
        self.ObjNodesTasks = []
        self.TaskDispatcherBlocked = [] # boolean at every tick
        self.SystemInstantaneousUtilisation = []
        
        # Start the run process everytime an instance is created.        
        self.process_instance = self.env.process(self.run())
        
        
    def run(self):        
        
        # temp counter storage
        prev_completed_tasks = [0 for x in range(SimParams.NUM_NODES)]
        
        #print(self.label + ' : run starting at %d' % self.env.now)        
        while True:
        
            #############################
            ## tracking INPUT BUFFER
            #############################
            
            if(SimParams.TRACK_INPUTBUFF == True):
                for each_ibuff_id in xrange(SimParams.NUM_INPUTBUFFERS):
                    
                    item = {
                            'time_now' : self.env.now,
                            'record' : self.input_buffers[each_ibuff_id].status_getCurrentItems()[0],
                            'record_2' : self.input_buffers[each_ibuff_id].status_getCurrentItems()[1]
                            }                
                    self.ObjInputBuffTasks[each_ibuff_id].append(item)
            
            #############################
            ## tracking OUTPUT BUFFER
            #############################
            if(SimParams.TRACK_OUTPUTBUFF == True):
                item = {
                        'time_now' : self.env.now,
                        'record' : self.output_buffer.status_getCurrentItems()
                        }            
                self.ObjOutputBuffTasks.append(item)
            
            #############################
            ## tracking NODE TASK QUEUS
            #############################
            if(SimParams.TRACK_NODESTASKQ == True):
                nodes = []
                for each_node in self.node_network.get_Nodes():
                    node = {
                            'id'            : each_node.get_id(),
                            'type'          : each_node.get_type(),                        
                            'tasks_in_q'   : each_node.get_NumTasksInQ()
                            }
                    nodes.append(node)
                
                item = {
                        'time_now' : self.env.now,
                        'record' : nodes
                        }
                self.ObjNodesTasks.append(item)
            
            ##########################################
            ## tracking INSTANTANEOUS_SYS_UTILIZATION
            ##########################################
            if(SimParams.TRACK_INSTUTIL == True):
                num_idle_cores = []
                num_busy_cores = []
                core_specific_tc = []
                tq = 0
                tc = 0
                for ix,each_node in enumerate(self.node_network.get_Nodes()):
                    
                    prev = prev_completed_tasks[ix]
                    now = len(self.node_network.nodeArray[ix].completedTasks)                    
                    delta = now-prev     # difference               
                    prev_completed_tasks[ix] = now  # update
                    core_specific_tc.append(delta)
                    
                    tc += delta
                    
                    #if(each_node.get_status() in [NodeStatus.NODE_IDLE, NodeStatus.NODE_BUSY_DATAIO, NodeStatus.NODE_JUSTWOKEUP]):
                    #if(self.node_network.nodeArray[ix].get_status() != NodeStatus.NODE_IDLE):
                        #num_idle_cores.append(each_node)
                        #num_busy_cores.append(each_node)
                    #tq += len(self.node_network.nodeArray[ix].completedTasks)
                    
                #inst_sys_util = 1.0 - (float(len(num_idle_cores))/float(SimParams.NUM_NODES))
                #inst_sys_util = float((float(SimParams.NUM_NODES) -  float(len(num_idle_cores)))/float(SimParams.NUM_NODES))
                
                #inst_sys_util = float(tc)/float(SimParams.NUM_NODES)
                
                #print tq
                
                #self.SystemInstantaneousUtilisation.append(tq)
                
                entry = {
                         "csp_tc" : core_specific_tc,
                         "sum_tc" :   tc
                         }
                
                self.SystemInstantaneousUtilisation.append(entry)
            
        
            # go to sleep according to sample rate
            yield self.env.timeout(SimParams.SIM_MONITOR_SAMPLE_RATE)
            
            
##########################################
## Plotting functions 
##########################################           
    def plot_InputBuffer(self):
        
        time = []
        data = []
        data_2 = []
        
        #pprint(self.ObjInputBuffTasks)
        lines = ["-*","-x","-o","-+"]
        linecycler = cycle(lines)
        
        self.fig_counter += 1
        fig = plt.figure(self.fig_counter)
        fig.canvas.set_window_title('InputBuffers')
        
        ibuff_id = 0
        for each_ibuff in self.ObjInputBuffTasks:
            time = []
            data = []
            data_2 = []
            
            for each_item in each_ibuff:
            
                time.append(each_item['time_now'])
                data.append(each_item['record'])
                data_2.append(each_item['record_2'])
                
            lbl = "IBuff-"+str(ibuff_id)
            
            plt.plot(time, data, next(linecycler), label =lbl, linewidth=2.0 )
            plt.hold(True)
            ibuff_id +=1
                
        plt.grid(True)
        leg = plt.legend()
        leg.draggable()
        
        
    def plot_OutputBuffer(self):
        
        time = []
        data = []
        
        for each_item in self.ObjOutputBuffTasks:
            time.append(each_item['time_now'])
            data.append(each_item['record'])
       
        self.fig_counter += 1
        fig = plt.figure(self.fig_counter)
        fig.canvas.set_window_title('OutputBuffer')
        plt.plot(time, data)
        plt.grid(True)    
        
    def plot_TasksMissedDeadline_perCore(self):
        
        labels = []
        core_specific_misseddeadlines = []
        percentage = 0.0
        
        print "plot_TasksMissedDeadline_perCore"
        print "---------------------------------"
        
        for each_node in self.node_network.get_Nodes():
            if((len(each_node.completedTasks) >0)):
                percentage = float(float(len(each_node.tasks_that_missed_deadline)/float(len(each_node.completedTasks))) * 100.00)
                core_specific_misseddeadlines.append(percentage)
                labels.append(each_node.label)
                
                # print out value
                print each_node.label + " = " + str(percentage) + "(" + str(len(each_node.tasks_that_missed_deadline)) + "/" + str(len(each_node.completedTasks)) + ")"
            else:
                print "Error ! - no completed tasks !!"
                return   
            
        if(len(core_specific_misseddeadlines) > 0):        
            self.fig_counter += 1
            fig = plt.figure(self.fig_counter)
            fig.canvas.set_window_title('TasksMissedDeadline_perCore')
            
            xlocations = np.array(range(len(core_specific_misseddeadlines)))+0.5
            width = 0.5
            plt.bar(xlocations, core_specific_misseddeadlines, width=width)       
            plt.xticks(xlocations+ width/2, labels)
            plt.xlim(0, xlocations[-1]+width*2)
            plt.grid(True)
        
            
    ## analyse the tasks in the output buff 
    ## in terms of their missed deadlines
    def plot_TasksMissedDeadline_perTask(self):
        
        labels = []
        task_specific_misseddeadline = []
        
        for each_task in self.output_buffer.get_BuffContents():
            if(each_task.get_missedDeadlineFlag() == True):
                missed_alpha = each_task.get_taskCompleteTime() - (each_task.get_releaseTime() + each_task.get_deadline())                
                task_specific_misseddeadline.append(missed_alpha)                
                labels.append(str(each_task.get_id()))
        
        print " "
        print "plot_TasksMissedDeadline_perTask"
        print "---------------------------------"
        if(len(task_specific_misseddeadline) > 0):
            
            print "Worst-case GOP deadline miss delay : " + str(max(task_specific_misseddeadline))
            print "Average GOP deadline miss delay : " + str(sum(task_specific_misseddeadline)/float(len(task_specific_misseddeadline)))
            
                
            if(len(task_specific_misseddeadline) > 0):        
                self.fig_counter += 1
                fig = plt.figure(self.fig_counter)
                fig.canvas.set_window_title('TasksMissedDeadline_perTask')
                
                xlocations = np.array(range(len(task_specific_misseddeadline)))+0.5
                width = 0.5
                plt.bar(xlocations, task_specific_misseddeadline, width=width)       
                plt.xticks(xlocations+ width/2, labels)
                plt.tick_params(axis='x', which='major', labelsize=10)
                plt.xlim(0, xlocations[-1]+width*2)
                
                # plot mean (horizontal-line)
                plt.hold(True)
                plt.axhline(y=sum(task_specific_misseddeadline)/float(len(task_specific_misseddeadline)), color='r')       
                
                plt.grid(True)
        else:
            print "None of the tasks missed their deadline"
    
    
    def plot_NodeTaskQs(self):
        
        time = []
        data = []
        lines = ["-","--","-.",":"]
        linecycler = cycle(lines)
    
        self.fig_counter += 1
        fig = plt.figure(self.fig_counter)
        fig.canvas.set_window_title('NodeTaskQueues')
        
        for each_node_id in xrange(SimParams.NUM_NODES):        
            
            time = []
            data = []
            for each_item in self.ObjNodesTasks:
                time.append(each_item['time_now'])
                data.append(each_item['record'][each_node_id]['tasks_in_q'])                
                lbl = each_item['record'][each_node_id]['type']+"-"+str(each_item['record'][each_node_id]['id'])
            
           
            plt.plot(time, data, next(linecycler), label =lbl, linewidth=2.5 )
            plt.hold(True)
            
        plt.grid(True)
        leg = plt.legend()
        leg.draggable()
        
    def show_CPU_utilisation(self):
        ## numeric stats ##        
        # completed tasks (total)
        print " "
        print "CPU Utilisation"
        print "---------------"
        total_system_utilisation = 0.0
        for each_node in self.node_network.get_Nodes():
            print each_node.label + " : " +  str(each_node.get_TotalCompletedTasks()) + \
                    ", total_cc = " + str(each_node.get_TotalTaskExecutionTime()) + \
                    ", total_sim_runtime = " + str(SimParams.SIM_RUNTIME) + \
                    ", utilisation (based on total_cc) = " + str((each_node.get_TotalTaskExecutionTime() / SimParams.SIM_RUNTIME) * 100) + "%"
        
            total_system_utilisation = total_system_utilisation + ((each_node.get_TotalTaskExecutionTime() / SimParams.SIM_RUNTIME) * 100)
        
        print " "
        print "Total System Utilisation = %f" % (total_system_utilisation/float(SimParams.NUM_NODES))
        
                    
    def report_InstUtilisation(self, dump_to_file= None):
                
        
        #self.fig_counter += 1
        #fig = plt.figure(self.fig_counter)
        #fig.canvas.set_window_title('Instantaneous Utilisation')
        
        #x = np.linspace(0,len(self.SystemInstantaneousUtilisation)-1)
        
        #ind = np.arange(np.size(self.SystemInstantaneousUtilisation))
        
        #plt.stem(ind, self.SystemInstantaneousUtilisation, 'b')
        
        ############################
        ### dump data to file(s) ###
        ############################        
        if(dump_to_file != None):
            
            print "SimDataMonitor :: dumping sysutil"
            # write entire gop_lateness values per gop     
            fname = dump_to_file+"__utilisation.js"
#            with open(fname, 'w') as f:
#                for util in self.SystemInstantaneousUtilisation:
#                    f.write(("%f"%util) + '\n')
            
            self._write_formatted_file(fname, self.SystemInstantaneousUtilisation, "json")
        
        
    def plot_showall(self):
        plt.show()
        
                        
                    
##########################################
## Report output
##########################################                   
     
    def report_CompletedTaskAnalysis(self):   
        print " "
        print "Completed task analysis"
        print "======================="
        for each_node in self.node_network.get_Nodes():
            print each_node.label            
            print "--------------"
            for each_completed_task in each_node.completedTasks:
                print "Ti="+ str(each_completed_task.get_id()) + \
                    ", (=" + str(each_completed_task.get_type())+")" + \
                    ", stT=" + str(each_completed_task.get_taskStartTime()) + \
                    ", cmpT=" + str(each_completed_task.get_taskCompleteTime()) + \
                    ", relT=" + str(each_completed_task.get_releaseTime()) + \
                    ", cc=" + str(each_completed_task.get_computationCost()) + \
                    ", deadln=" + str(each_completed_task.get_deadline()) + \
                    ", missedDeadlineFlag=" + str(each_completed_task.get_missedDeadlineFlag())
            
            print " "
        
        
    def report_RM_FlowTable(self):        
        
        # output rm-dropped tasks table
        logfile=open('rm_tbl_flowtable.js', 'w')
        pprint(self.resource_manager.flow_table.flowEntries, logfile, width=128)
    
    
    def report_VideoStream_BasicStats(self, wf_results_summary, fname):
        
        # original workflow data (at task generation)
        original_workflow = self.workflows.workflows_summary
        
        # track completeness/lateness
        vids_rejected = []
        vids_accepted_success = []
        vids_accepted_late = []        
        
        for each_wf_key, each_wf_val in wf_results_summary.iteritems():
            
                       
            for each_vid_key, each_vid_val in enumerate(each_wf_val): 
                
                if(wf_results_summary[each_wf_key][each_vid_val]['result'] == True):
                    vids_accepted_success.append(each_vid_val)
                else:
                    if(len(wf_results_summary[each_wf_key][each_vid_val]['gops_in_outbuff']) > 0):
                        vids_accepted_late.append(each_vid_val)
                    else:
                        vids_rejected.append(each_vid_val)
        
        
        # construct report
        video_stream_highlevel_stats = {
                                        "num_vids_rejected" : len(vids_rejected),
                                        "num_vids_accepted_success" : len(vids_accepted_success),
                                        "num_vids_accepted_late" : len(vids_accepted_late),
                                        "num_dropped_tasks" : self.resource_manager.totalDroppedTasks()
                                        }
        
        
        logfile=open(fname, 'w')
        json_data = json.dumps(video_stream_highlevel_stats, indent=4)
        logfile.write(json_data)
          
               
        
        
        
    
    def report_DecodedWorkflows_Summary(self, timeline_fname = 'showTaskTimeLine.png', 
                                        wf_res_summary_fname = 'workflow_results_summary.js', 
                                        gops_opbuff_summary_fname = 'gops_in_outputbuff_summary.js',
                                        rmtbl_dt_summary_fname = 'rm_tbl_droppedtasks.js',
                                        output_format="pretty"):
        print " "
        print "show_DecodedWorkflows_Summary"
        print "================================"
        
        # construct GOP range
        frame_groups = {}
        for each_task in self.output_buffer.get_BuffContents():
            if each_task.get_unique_gop_id() not in frame_groups:                
                frame_groups[each_task.get_unique_gop_id()] = [each_task]            
            else:
                frame_groups[each_task.get_unique_gop_id()].append(each_task)
                
        
        ## print out results of each GOP ##
        gops_successfully_completed = []    # i.e : not late, and all frames decoded
        gops_late_but_fully_complete = []
        gops_ids_late_but_fully_complete = []
        gops_incomplete = 0
        total_gop_lateness = []
        
        gops_in_outputbuff_summary = {}
        
        for each_gop_id in frame_groups:
            
            gops_in_outputbuff_summary[frame_groups[each_gop_id][0].get_unique_gop_id()] = {}            
            
            gop_startend_dict = {
                             'gop_unique_id' : frame_groups[each_gop_id][0].get_unique_gop_id(),
                             'total_frames_in_gop' : 0,
                             'start_time' : frame_groups[each_gop_id][0].get_releaseTime(),
                             'start_task_id' : 0,
                             'start_task_gopix' : 0,
                             'end_time' : frame_groups[each_gop_id][0].get_taskCompleteTime(),
                             'end_task_id' : 0,
                             'end_task_gopix' : 0,
                             'dispatch_time' : frame_groups[each_gop_id][0].get_dispatchTime(),
                             'total_time_wrt_dispatchtime' : 0,
                             'total_time_wrt_reltime' : 0,
                             'gop_endtoend_deadline' : 0,
                             'gop_execution_lateness' : 0                                                          
                             }
            
            for each_task in frame_groups[each_gop_id]:
                # set start-time
                if(each_task.get_releaseTime() <  gop_startend_dict['start_time']):
                    gop_startend_dict['start_time'] = each_task.get_releaseTime()
                    gop_startend_dict['start_task_id'] = each_task.get_id()                    
                    gop_startend_dict['start_task_gopix'] = each_task.get_frameIXinGOP()
                # set end-time
                if(each_task.get_taskCompleteTime() >=  gop_startend_dict['end_time']):
                    gop_startend_dict['end_time'] = each_task.get_taskCompleteTime()
                    gop_startend_dict['end_task_id'] = each_task.get_id()
                    gop_startend_dict['end_task_gopix'] = each_task.get_frameIXinGOP()
                    
                
                gop_startend_dict['total_frames_in_gop'] += 1
                gop_startend_dict['gop_endtoend_deadline'] = float(SimParams.GOP_LENGTH)/float(each_task.frame_rate)                
                    
            ##---------------------------------------------------------------------------------------
            ## perform sanity check on frame_ids : is last_frame_id = 11, is start_frame_id = 0 ##
            if(gop_startend_dict['total_frames_in_gop'] > SimParams.GOP_LENGTH):
                pprint(gop_startend_dict)
                sys.exit("Error - too many frames in gop")
            elif(gop_startend_dict['total_frames_in_gop'] == SimParams.GOP_LENGTH):
                if((gop_startend_dict['end_task_gopix'] not in [2,3,5,6,8,9,10,11]) or 
                   (gop_startend_dict['start_task_gopix'] != 0)):
                    pprint(gop_startend_dict)
                    sys.exit("Incorrect gop start/end")
            ##---------------------------------------------------------------------------------------
            
            full_gop_decode_duration = float(gop_startend_dict['end_time'] - gop_startend_dict['dispatch_time'])            
            
            gop_startend_dict['total_time_wrt_dispatchtime'] = full_gop_decode_duration
            gop_startend_dict['total_time_wrt_reltime'] = gop_startend_dict['end_time'] - gop_startend_dict['start_time']
            gop_startend_dict['gop_execution_lateness'] = gop_startend_dict['end_time'] - (each_task.get_dispatchTime() + gop_startend_dict['gop_endtoend_deadline'])          
        
            if((gop_startend_dict['gop_execution_lateness'] <= 0) and
               (full_gop_decode_duration <= gop_startend_dict['gop_endtoend_deadline'])):
                gops_successfully_completed.append(gop_startend_dict['gop_unique_id'])
            
            total_gop_lateness.append(gop_startend_dict['gop_execution_lateness'])
                                
            if(len(frame_groups[each_gop_id]) == SimParams.GOP_LENGTH) and (gop_startend_dict['gop_execution_lateness'] > 0):            
                gops_late_but_fully_complete.append(gop_startend_dict['gop_execution_lateness'])
                gops_ids_late_but_fully_complete.append(gop_startend_dict['gop_unique_id'])        
                
            gops_in_outputbuff_summary[frame_groups[each_gop_id][0].get_unique_gop_id()] = gop_startend_dict  
        
        gops_incomplete = len(frame_groups) - len(gops_successfully_completed)
        
        wf_results_summary = {}
        #wf_results_summary['gops_successfully_completed'] = gops_successfully_completed
        for each_wf_key, each_wf_val in self.workflows.workflows_summary.iteritems():
            wf_results_summary[each_wf_key] = {}            
            
            for each_vid_key, each_vid_val in each_wf_val.iteritems():  
                
                # check if all gops in video have been fully completed, withion the deadline
                orig_gop_set = set(each_vid_val['gops'])
                results_gop_set = set(gops_successfully_completed)
               
                if(orig_gop_set.issubset(results_gop_set) == True):
                    wf_results_summary[each_wf_key][each_vid_key] = {                                                                     
                                                                     'result': True                                                                     
                                                                     }
                else:
                    # find which gops of the unsuccessful vids were partially/delayed completed
                    g = []
                    late_gops =[]
                    for each_gop in each_vid_val['gops']:
                        if(each_gop in frame_groups):
                            g.append(each_gop)
                        if(each_gop in gops_ids_late_but_fully_complete):
                            late_gops.append(each_gop)
                    
                    wf_results_summary[each_wf_key][each_vid_key] = {                                                                     
                                                                     'result': False,
                                                                     'gops_in_outbuff': g,
                                                                     'gops_late_but_fully_complete' : late_gops
                                                                     }
                    
        # save results summary
        self._write_formatted_file(wf_res_summary_fname, wf_results_summary, output_format)        
        
        # save full gop specific results summary
        self._write_formatted_file(gops_opbuff_summary_fname, gops_in_outputbuff_summary, output_format)
        
        # output video stream timeline
        self.workflows.showTaskTimeLine(len(self.workflows.workflows_summary), simon_wf_results_summary=wf_results_summary, fname=timeline_fname)
        
        # output rm-dropped tasks table        
        #self._write_formatted_file(rmtbl_dt_summary_fname, self.resource_manager.video_streams, output_format)
        
        # return all the gathered results back 
        return (wf_results_summary, gops_in_outputbuff_summary)
    
    
    def _write_formatted_file(self, fname, data, format):
        
        if(format == "pretty"):
            logfile=open(fname, 'w')
            pprint(data, logfile, width=128)
            
        elif(format == "json"):
            logfile=open(fname, 'w')
            json_data = json.dumps(data, indent=1)
            logfile.write(json_data)
            
        else:
            logfile=open(fname, 'w')
            pprint(data, logfile, width=128)
            
            
        
        
    
    def report_OutputBuffer_Contents_ByGOP(self, verbose=0, dump_to_file=None):
        print " "
        print "show_OutputBuffer_Contents_ByGOP"
        print "================================"        
        
        # construct GOP range
        frame_groups = {}
        for each_task in self.output_buffer.get_BuffContents():
            if each_task.get_unique_gop_id() not in frame_groups:                
                frame_groups[each_task.get_unique_gop_id()] = []        
        for each_task in self.output_buffer.get_BuffContents():
            frame_groups[each_task.get_unique_gop_id()].append(each_task)
        
        gop_end_to_end_deadline = (float(SimParams.GOP_LENGTH)/float(SimParams.FRAME_RATE))
        
        ## print out results of each GOP ##
        gops_successfully_completed = []    # i.e : not late, and all frames decoded
        gops_late_but_fully_complete = []
        total_gop_lateness = []
        for each_gop_id in frame_groups:
            
            gop_startend_dict = {
                             'total_frames_in_gop' : 0,
                             'start_time' : frame_groups[each_gop_id][0].get_releaseTime(),
                             'start_task_id' : 0,
                             'start_task_gopix' : 0,
                             'end_time' : frame_groups[each_gop_id][0].get_taskCompleteTime(),
                             'end_task_id' : 0,
                             'end_task_gopix' : 0,
                             'dispatch_time' : frame_groups[each_gop_id][0].get_dispatchTime()                             
                             }            
            
            print " "
            print "GOP_ID = " +  str(each_gop_id)
            print "-------------"
            
            for each_task in frame_groups[each_gop_id]:
                
                if(verbose == 1):
                    print "Ti="+ str(each_task.get_id()) + \
                        ", (=" + str(each_task.get_type())+")" + \
                        ", relT=" + str(each_task.get_releaseTime()) + \
                        ", stT=" + str(each_task.get_taskStartTime()) + \
                        ", cmpT=" + str(each_task.get_taskCompleteTime()) + \
                        ", cc=" + str(each_task.get_computationCost()) + \
                        ", wccc=" + str(each_task.get_worstCaseComputationCost())
                    
                if(each_task.get_releaseTime() <  gop_startend_dict['start_time']):
                    gop_startend_dict['start_time'] = each_task.get_releaseTime()
                    gop_startend_dict['start_task_id'] = each_task.get_id()                    
                    gop_startend_dict['start_task_gopix'] = each_task.get_frameIXinGOP()
            
                if(each_task.get_taskCompleteTime() >=  gop_startend_dict['end_time']):
                    gop_startend_dict['end_time'] = each_task.get_taskCompleteTime()
                    gop_startend_dict['end_task_id'] = each_task.get_id()
                    gop_startend_dict['end_task_gopix'] = each_task.get_frameIXinGOP()
                
                gop_startend_dict['total_frames_in_gop'] += 1
                    
            ##---------------------------------------------------------------------------------------
            ## perform sanity check on frame_ids : is last_frame_id = 11, is start_frame_id = 0 ##
            if(gop_startend_dict['total_frames_in_gop'] > SimParams.GOP_LENGTH):
                pprint(gop_startend_dict)
                sys.exit("Error - too many frames in gop")
            elif(gop_startend_dict['total_frames_in_gop'] == SimParams.GOP_LENGTH):
                if((gop_startend_dict['end_task_gopix'] not in [8,9,10,11]) or 
                   (gop_startend_dict['start_task_gopix'] != 0)):
                    pprint(gop_startend_dict)
                    sys.exit("Incorrect gop start/end")
            ##---------------------------------------------------------------------------------------
            
            if(verbose != 0):            
                pprint(gop_startend_dict)
            
            
            print "Total frames processed = " + str(len(frame_groups[each_gop_id]))
            
            full_gop_decode_duration = float(gop_startend_dict['end_time'] - gop_startend_dict['dispatch_time'])
            
            print "Total_time (completed_time - dispatched_time)= " + str(full_gop_decode_duration)
            print "Total_time (completed_time - release_time)= " + str(gop_startend_dict['end_time'] - gop_startend_dict['start_time'])
            
            print "GOP_End-to-End deadline = %f" % (gop_end_to_end_deadline)
            gop_execution_lateness = gop_startend_dict['end_time'] - (each_task.get_dispatchTime() + float(SimParams.GOP_LENGTH)/float(SimParams.FRAME_RATE))
            print "Lateness = %f" % (gop_execution_lateness)
        
            if((gop_execution_lateness < 0) and
               (full_gop_decode_duration < gop_end_to_end_deadline)):
                gops_successfully_completed.append(each_gop_id)
            
            total_gop_lateness.append(gop_execution_lateness)
                                
            if(len(frame_groups[each_gop_id]) == SimParams.GOP_LENGTH) and (gop_execution_lateness > 0):            
                gops_late_but_fully_complete.append(gop_execution_lateness)
                
        print " "
        print "Number of GOPs successfully decoded = " + str(len(gops_successfully_completed)) 
        print "Number of incomplete GOPs = " + str(len(frame_groups) - len(gops_successfully_completed))
        print "Number of gops (late but fully complete) = " + str(len(gops_late_but_fully_complete))
        avg_gop_lateness = float(sum(total_gop_lateness))/float(len(total_gop_lateness))
        max_gop_lateness = float(max(total_gop_lateness))
        min_gop_lateness = float(min(total_gop_lateness))
        sum_gop_lateness = float(sum(total_gop_lateness))
        
        print "Average_GOP_lateness (avg)= " + str(avg_gop_lateness)
        print "Maximum GOP lateness (max)= " + str(max_gop_lateness)
        print "Minimum GOP lateness (min)= " + str(min_gop_lateness)
        print "Total GOP lateness (sum) = " + str(sum_gop_lateness)
        print "Total Blocks Dispatched = " + str(self.task_dispatcher.total_blocks_dispatched)        
        
        print str(self.task_dispatcher.total_blocks_dispatched) + "," + \
                str(len(gops_successfully_completed)) + "," + \
                str(len(gops_late_but_fully_complete))
        
        ############################
        ### dump data to file(s) ###
        ############################        
        if(dump_to_file != None):
            lateness_stats =   str(self.task_dispatcher.total_blocks_dispatched) + "," + \
                str(len(gops_successfully_completed)) + "," + \
                str(len(gops_late_but_fully_complete)) + "," + \
                ("%f" % avg_gop_lateness) + "," + \
                ("%f" % max_gop_lateness) + "," + \
                ("%f" % min_gop_lateness) + "," + \
                ("%f" % sum_gop_lateness)                            
            
            # write entire gop_lateness values per gop     
            fname = dump_to_file+"__data.txt"
            with open(fname, 'w') as f:
                for lateness in total_gop_lateness:
                    f.write(("%f"%lateness) + '\n')
            
            # write summary to file 
            fname = dump_to_file+"__summary.txt"
            with open(fname, 'w') as f:               
                    f.write(lateness_stats)
            
                
            
            
    