import pprint
import sys
import networkx as nx
import simpy
import matplotlib.pyplot as plt

## local imports
from SimParams import SimParams


class RuntimeApplicationInfo:
    
    def __init__(self, env, RMinstance):
        self.env = env
        self.RMinstance = RMinstance
        self.stream_info = {}
        self.tasks = {} # list of tasks the system is dealing with
        self.flows = {} # list of flows the system is dealing with          
        
    
    ## getters/setters
    
    def setTask_analytical_wcet(self, task_key, awcet):
        self.tasks[task_key].set_analytical_wcet(awcet)
    def setFlow_analytical_wcet(self, flow_key, awcet):
        self.flows[flow_key].set_analytical_wcet(awcet)    
    def setStream_critical_path_wcet(self, strm_key, awcet):
        self.stream_info[strm_key].set_criticalPathWCET(awcet)
    
    
    def getTasks(self):
        return self.tasks.values()            
    def getFlows(self):
        return self.flows.values()
    def getStreams(self):
        return self.stream_info.values()
    
    def getTask(self, gop_ix, wf_id, strm_id):
        for each_t in self.tasks.values():
            if (each_t.get_wfid()== wf_id) and (each_t.get_video_stream_id() == strm_id):
                if(each_t.get_frameIXinGOP() == gop_ix):
                    return each_t
        
        return None
    
    
    
    def getTask_analytical_wcet(self, task_key):
        return self.tasks[task_key].get_analytical_wcet()
    def getFlow_analytical_wcet(self, flow_key):
        return self.flows[flow_key].get_analytical_wcet()
    def getStream_critical_path_wcet(self, strm_key):
        return self.stream_info[strm_key].get_criticalPathWCET()
        
    
    ## task management
    def addTask(self, task):
        if task.get_id() not in self.tasks:
            self.tasks[task.get_id()] = task
                        
    def removeTask(self, task):
        if task.get_id() in self.tasks:
            del self.tasks[task.get_id()]
            
    ## flow management
    def addFlow(self, flow):
        
        key = str(flow.get_respectiveSrcTaskId()) + "_" + str(flow.get_respectiveDstTaskId())
                
        if key not in self.flows:
            self.flows[key] = flow
                        
    def removeFlow(self, flow):
        
        key = str(flow.get_respectiveSrcTaskId()) + "_" + str(flow.get_respectiveDstTaskId())
                
        if key in self.flows:
            del self.flows[key]
    
    ## stream management
    def addStream(self, strm_key, entry):        
        if strm_key not in self.stream_info:
            self.stream_info[strm_key] = entry
    
    def removeStream(self, strm_key):
        if strm_key in self.stream_info:
            del self.stream_info[strm_key] 
        

class VideoStreamInfo():
    
    def __init__(self,  id,
                        wf_id,
                        gop_structure, 
                        resolution,
                        arrival_rate_ub,
                        frame_rate,
                        start_time):
        
        self.id = id
        self.wf_id = wf_id
        self.gop_structure = gop_structure 
        self.resolution = resolution
        self.arrival_rate_ub = arrival_rate_ub
        self.frame_rate = frame_rate
        self.start_time = start_time
        self.taskids = [] # periodic tasks within the stream
        self.critical_path_wcet = None
        
    
    # minimal version of to-string (for schedulability debug)
    def getSchedulability_toString(self):
        debug = ""
        debug += " wfid='" + str(self.wf_id)+ "'"
        debug += " vid='" + str(self.id) + "'"
        debug += " res='" + str(self.resolution)+ "'"
        debug += " ar_ub='" + str(self.arrival_rate_ub)+ "'"
        debug += " st='" + str(self.start_time)+ "'"        
        
        return debug
        
    
    def get_key(self):
        return str(self.wf_id) + "_" + str(self.id)
       
    def get_wfid(self):
        return self.wf_id
    def get_stream_id(self):
        return self.id
    def get_gopStructure(self):
        return self.gop_structure    
    def get_resolution(self):
        return self.resolution
    def get_arrivalRateUB(self):
        return self.arrival_rate_ub
    def get_frame_rate(self):
        return self.frame_rate
    def get_startTime(self):
        return self.start_time
    def get_end2end_deadline(self):
        e2ed = (float(len(self.gop_structure))/float(self.frame_rate))
        return e2ed
    def get_criticalPathWCET(self):
        return self.critical_path_wcet
    
    def set_streamTasks(self, taskids):
        self.taskids = taskids
    def set_criticalPathWCET(self, cpc):
        self.critical_path_wcet = cpc
    
    