
## local imports
from LocalScheduler import LocalRRScheduler,    \
                        LocalEDFScheduler, \
                        LocalMPEG2FrameEDFScheduler, \
                        LocalMPEG2FrameListScheduler, \
                        LocalMPEG2FramePriorityScheduler

from Task import TaskModel
from AdmissionControllerOptions import AdmissionControllerOptions


class SimParams(object):    
   
    ##################
    ## sim specific ##
    ##################
    SIM_RUNTIME = 100    
    
    ########################
    ## workflows specific ##
    ########################
    NUM_WORKFLOWS = 4
    WFGEN_MIN_VIDS_PER_WF = 6
    WFGEN_MAX_VIDS_PER_WF = 7   # how many videos per streambuffer ?
    WFGEN_MIN_GOPS_PER_VID = 7 
    WFGEN_MAX_GOPS_PER_VID = 8 # how long is a video going to be ?
    WFGEN_MAX_INTER_VIDEO_GAP = 1.5 # what is the max gap between videos ?
    WFGEN_MIN_INTER_VIDEO_GAP = 1.0 # what is the min gap between videos ?    
    
    #####################
    ## buffer specific ##
    #####################
    NUM_INPUTBUFFERS = NUM_WORKFLOWS
    INPUT_BUFF_SIZE = (12*2)    # input buffer size per workflow
    OUTPUT_BUFF_SIZE = 100000
    
    #####################
    ## task dispatcher ##
    #####################
    TASKDISPATCH_RATE = float(float(12.0/25.0) * 1.0)
    TASKDISPATCH_RATE_MAX = float(float(12.0/25.0) * 1.5) # max gap between consecutive gops    (multiples of e2e deadline)
    TASKDISPATCH_RATE_MIN = float(float(12.0/25.0) * 1.0) # min gap between consecutive gops   (multiples of e2e deadline)
    
    TASKDISPATCHER_RESET_DELAY  = 0.000001    # need to start after the nodes
    TASKDISPATCHER_BLOCK_SIZE = 12  # gop size
    # what is the task model ? gop/frame/slice ? etc..
    TASK_MODEL = TaskModel.TASK_MODEL_MHEG2_FRAME_ET_LEVEL
    
    ###################
    ## mpeg specific ##
    ###################    
    GOP_LENGTH = 12
    GOP_STRUCTURE = "IPBBPBBPBBBB"
    GOP_CRITICAL_PATH = "IPPPB"
    
    DEFAULT_END2END_DEADLINE = float(float(12.0/25.0) * 1.0)
    
    FRAME_RATE = 25
    MOVIE_LEN = 0.2   # mins
    FRAME_DEFAULT_W = 720
    FRAME_DEFAULT_H = 480
    NUM_GOPS = int(((MOVIE_LEN*60) * FRAME_RATE) / GOP_LENGTH)  # number of gops (task pool size), e.g. 60 min movie   
    
    #DVB_RESOLUTIONS = [(1920,1080),(1280,720),(720,576),(704,576),(544,576),(528,576),(480,576),(320,240)]
    #DVB_RESOLUTIONS = [(1280,720),(720,576),(704,576),(544,576),(528,576),(480,576),(426,240),(320,240)]
    
    #DVB_RESOLUTIONS = [(854,480),(720,576),(704,576),(544,576),(528,576),(480,576),(426,240),(320,240)]    # no problems for crossbar
    
    #DVB_RESOLUTIONS = [(480,576),(426,240),(320,240)]     # low-res
    #DVB_RESOLUTIONS = [(426,240),(320,240),(240,180),(230,180),(230,173),(176,132)]     # ultra-low-res
    #DVB_RESOLUTIONS = [(528,576),(480,576),(426,240),(320,240),(240,180),(230,180)]     # super-low-res
    DVB_RESOLUTIONS = [(528,576),(480,576),(426,240),(320,240)]     # super-low-res
    #DVB_RESOLUTIONS = [(320,240)]     # single-res
    
    ###############################
    ## resource manager specific ##
    ###############################
    RESOURCEMANAGER_POLL_RATE = 1.0/10000.0
    RESOURCEMANAGER_ALLOC_NUM_TASKS = GOP_LENGTH  # how many tasks would the resource manager try to map - at a given instance 
    #RESOURCEMANAGER_MAPPING_POLICY = ? 
    SLACK_FEEDBACK_ENABLED = False    
    SYNCH_TIME_OFFSET = 0.0000001
    #SYNCH_TIME_OFFSET = 0.0
    
    ###################################
    ## schedulability tests specific ##
    ###################################
    
    OUTPUT_SCHED_TEST_LOG = True       
    WCRT_SCHEDULABILITY_TEST_PERCENTAGE = 100   # percentage of the schedulability test we look for
    WCRT_FLOW_CALC_TIMEOUT = 60.0*5.0   # this is the max time allowed to calculate the WCET of all the flows in the runtime app     
    
    
    ###################################
    ## Admission controller          ##
    ###################################
    
    AC_TEST_OPTION = AdmissionControllerOptions.AC_OPTION_HEURISTIC_ONLY
    
    ###################
    ## node specific ##
    ###################
    NUM_NODES = 9
    CPUNODE_TASKQ_SIZE = 5
    CPUNODE_DEPENDANCY_BUFF_SIZE = 50
    CPUNODE_DEPENDANCY_BUFF_SAFE_LEVEL = 20
    CPU_IDLE_SLEEP_TIME = 0.5
    MEMWRITE_FLUSH_WINDOW = 10
    
    ##################
    ## NoC specific ##
    ##################
    NOC_W = 3
    NOC_H = 3
    NOC_PERIOD              = 0.000001 # 1 MHz
    NOC_FLIT_BYTES          =  128/8            # 128 bits
    NOC_ARBITRATION_COST    =  NOC_PERIOD*7    
    NOC_FLOW_PRIORITY_LEVELS = 10
    
    ##############################
    ## local scheduler specific ##
    ##############################
    INTERRUPT_FREQ = 65
    LOCAL_SCHEDULER_TYPE =  LocalMPEG2FramePriorityScheduler()    
    
    ########################
    ## resources specific ##
    ########################
    SHARED_MEM_SIZE = 1024 # in MB
    SHARED_MEM_WRITE_TIME_PER_MB = 0.000078125 # DDR3-1600    PC3-12800    12800 MB/s        
    
    
    ########################
    ## monitoring ##########
    ########################    
    SIM_MONITOR_SAMPLE_RATE = 0.5 # nyquist
    TRACK_INSTUTIL = True
    TRACK_INPUTBUFF = False
    TRACK_OUTPUTBUFF = False
    TRACK_NODESTASKQ = False
    
    
    #########################
    ## DEBUG Levels on/off ##
    #########################
    
    DEBUG_LVL_CAT_INTERRUPT             = False
    DEBUG_LVL_CAT_TRANSMIT              = False
    DEBUG_LVL_CAT_SCHEDANALYSIS         = True
    DEBUG_LVL_CAT_RUNTIMEAPP            = True
    
    DEBUG_LVL_CAT_CPUINFO               = False
    DEBUG_LVL_CAT_RMINFO                = False
    DEBUG_LVL_CAT_MAPPERINFO            = False
    DEBUG_LVL_CAT_RMINFO_VERBOSE        = False
    DEBUG_LVL_CAT_TDINFO                = True
    DEBUG_LVL_CAT_NOCFLWTBLINFO         = False
    DEBUG_LVL_CAT_NOCFLWTBLINFO_VERBOSE = False
    DEBUG_LVL_CAT_NOCFLOW               = False
    
    
    ## log output ##
    LOG_OUTPUT_NOCFLOWINFO          = False
    LOG_OUTPUT_SCHED_TEST_REPORT    = False
    

    