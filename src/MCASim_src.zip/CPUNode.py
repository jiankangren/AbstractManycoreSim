import pprint
import sys

import simpy

## local imports
from Node import Node
from SimParams import SimParams
from Node import NodeStatus
from Task import TaskModel, TaskStatus
from Buffer import Buffer, BufferType
from Debug import Debug, DebugCat


class CPU_RMStatus:
    RM_SLEEPING       = 1     # i.e sleeping
    RM_BUSYWAITING    = 2     # i.e waiting for someone else/resource
    RM_BUSY           = 3     # i.e busy computing
    RM_ACTIVE         = 4     # i.e. ready and doing work    
    NODE_JUSTWOKEUP   = 5


class CPUNode(Node):
    
    def __init__(self, env, id, tq_size):
        Node.__init__(self, env, 'CPUNode', id)              
        self.label = self.type + "-" + str(self.id)
        self.taskQueue = []
        self.currentRunningTaskID = None
        
        # semaphore for the taskQ
        self.mutex_tq = simpy.Container(self.env, capacity=1, init=0)
        
        self.taskQueueSize = tq_size
        self.completedTasks = []        
        self.tasks_that_missed_deadline = []
        self.memWrite = 0   # how much of data has been written to shared memory by this node ?
        self._memWriteCounter = 0
        self.tasks_that_missed_deadline_by_other_cores = []
        
        self.IDLE_SLEEP_TIME = SimParams.CPU_IDLE_SLEEP_TIME        
        self.scheduler = SimParams.LOCAL_SCHEDULER_TYPE
        
        # the dependency buffer will contain just task_ids of completed tasks, not the actual task itself
        self.dependency_buff = Buffer(env, BufferType.BUFFER_TYPE_INPUT, size=SimParams.CPUNODE_DEPENDANCY_BUFF_SIZE)        
        
        # Start the run process everytime an instance is created.        
        p = env.process(self.getRun(SimParams.TASK_MODEL))
        self.set_processInstance(p)       

        
    def getRun(self, task_model):
        if task_model == TaskModel.TASK_MODEL_MHEG2_FRAME_LEVEL:
            Debug.PPrint("%f"%self.env.now + "," + self.label + "," + "getRun::," + "TaskModel.TASK_MODEL_MHEG2_FRAME_LEVEL", DebugCat.DEBUG_CAT_CPUINFO)
            return self.run_MPEG2FrameTask_ExecutionLoop()
        
        elif task_model == TaskModel.TASK_MODEL_MHEG2_FRAME_TT_LEVEL:
            Debug.PPrint("%f"%self.env.now + "," + self.label + "," + "getRun::," + "TaskModel.TASK_MODEL_MHEG2_FRAME_TT_LEVEL", DebugCat.DEBUG_CAT_CPUINFO)
            return self.run_MPEG2FrameTask_TT_ExecutionLoop()
        
        elif task_model == TaskModel.TASK_MODEL_MHEG2_FRAME_ET_LEVEL:
            Debug.PPrint("%f"%self.env.now + "," + self.label + "," + "getRun::," + "TaskModel.TASK_MODEL_MHEG2_FRAME_ET_LEVEL", DebugCat.DEBUG_CAT_CPUINFO)
            return self.run_MPEG2FrameTask_ET_ExecutionLoop()
        
        elif task_model == TaskModel.TASK_MODEL_MHEG2_GOP_LEVEL:
            Debug.PPrint("%f"%self.env.now + "," + self.label + "," + "getRun::," + "TaskModel.TASK_MODEL_MHEG2_GOP_LEVEL", DebugCat.DEBUG_CAT_CPUINFO)
            return self.run_MPEG2GOPTask_ExecutionLoop()
        
        else:
            return None
    
    
    
    
    #######################    
    # Buffer management
    #######################
    
    def OutputBuff_put(self, n):
        self.outputBuffInstance.simpy_container_instance.put(n)

    def OutputBuff_areAllTasksInside(self):        
        
        #pprint.pprint(self.outputBuffInstance.get_level())
        #pprint.pprint(self.resource_manager_instance.get_maxTasks())
        if(self.outputBuffInstance.get_level() == self.resource_manager_instance.get_maxTasks()):
            return True
        else:
            return False
        
    def dependencyBuff_put(self,completed_task):
        if(self.dependency_buff.isFull() == False):
            self.dependency_buff.add_Item(completed_task, completed_task.get_id())
            self.dependency_buff.simpy_container_instance.put(1)
            return True # successfully entered into buff
        else:            
            return False # buffer is full
    
    def dependencyBuff_getLevel(self):
        return len(self.dependency_buff.get_BuffContents())
        
    
    def dependencyBuff_IsTaskInBuff(self,task_id):
        for each_task in self.dependency_buff.get_BuffContents():
            if(each_task.get_id() == task_id):
                return True        
        return False
    
    def dependencyBuff_removeTask(self, task_id):
        self.dependency_buff.remove_Item_byKey(task_id)
        self.dependency_buff.simpy_container_instance.get(1)
        
    # finished task, are there any in the taskQ waiting, that 
    # still needs me ??
    # if true - don't remove, else remove
    def dependencyBuff_cleanUp(self, finished_task):
        
        # get finished tasks, dependencies
        finished_tasks_deps = finished_task.get_dependencies()
        
        # check if any of the deps are needed by tasks in the:
        # - taskQ buffer
        # - task_mapping table
        for each_finished_tasks_deps_id in finished_tasks_deps:
            drop = True
            for each_task_in_taskq in self.taskQueue:
                if(each_finished_tasks_deps_id in each_task_in_taskq.get_dependencies()):
                    drop = False
                    break
            
            # no one in the taskQ needs it, now check if any of 
            # the deps are needed by tasks in the task_mapping_table (not yet released)
            if(drop == True):
                
                for (t_id, val) in self.resource_manager_instance.task_mapping_table.iteritems():   
                    for each_ibuff_id in xrange(len(self.resource_manager_instance.input_buffers)):    
                        if(t_id in self.resource_manager_instance.input_buffers[each_ibuff_id].get_BufferItemsList()):              
                            task_in_inputbuff = self.resource_manager_instance.input_buffers[each_ibuff_id].get_BufferItemsList()[t_id]                    
                            if(each_finished_tasks_deps_id in task_in_inputbuff.get_dependencies()): # tasks
                                if(val['node_id'] == self.id) and \
                                (val['status'] != TaskStatus.TASK_COMPLETED):
                                    drop = False
                                    break  
                
                if(drop == True):
                    self.dependencyBuff_removeTask(each_finished_tasks_deps_id)
    
    
    #######################    
    # task que management
    #######################
    def add_Task(self, Task):
        if(len(self.taskQueue) < self.taskQueueSize):
            
            # update tasks interference patterns
            for idx, each_task in enumerate(self.taskQueue):
                if(each_task.get_priority() <= Task.get_priority()):
                    Task.addBlockedBy(each_task)
                else:
                    self.taskQueue[idx].addBlockedBy(each_task)
            
            self.taskQueue.append(Task)            
            return True
        else:
            print("%.11f"%self.env.now + "," + self.label + "," + 'add_Task::, TaskQ FULL!, new_task_id='+str(Task.get_id()))
            pprint.pprint(self.taskQueue)
            return False
               
    def getTaskQ_level(self):
        return len(self.taskQueue)
        
    def markTaskAsCompleted(self, task):
        # add to completed tasks
        self.completedTasks.append(task)
    
    # mark task as active in RM's Task mapping table
    def setTaskStatus_inRM_TMTbl(self, task_id, task_status):
        # first map child tasks
        self.lock_RM_TMtbl()
        
        if(task_id in self.resource_manager_instance.task_mapping_table):
            self.resource_manager_instance.task_mapping_table[task_id]['status'] = task_status
        
        self.release_RM_TMtbl()
    
    def setTaskStatus(self, tq_ix, task_id, status):
        self.setTaskStatus_inRM_TMTbl(task_id, status)   # set task status
        self.taskQueue[tq_ix].set_status(status)    
    
    def updateTaskRemainingCompCost(self, tq_ix):
        last_active_time = self.taskQueue[tq_ix].get_lastActiveTime()        
        start_time = self.taskQueue[tq_ix].get_taskStartTime()
        remaining_comp_cost = self.taskQueue[tq_ix].get_remainingComputationCost()        
        
        rt = remaining_comp_cost - (self.env.now - last_active_time)
        
        self.taskQueue[tq_ix].set_remainingComputationCost(rt)
        
        
    
    def remove_Task(self, ix=0):
        
        temp_finished_task = self.taskQueue[ix]        
        # update the interference to the other tasks        
        for tq_idx, each_task in enumerate(self.taskQueue):
            if temp_finished_task in self.taskQueue[tq_idx].get_blockedBy():
                self.taskQueue[tq_idx].removeBlockedBy(temp_finished_task)
       
        
        #print(self.label + ' : Now removing task - at %f' % (self.env.now))        
        # remove from task Q
        del self.taskQueue[ix]    
        
    def numLateTasksInTQ(self):
        count = 0
        for tq_idx, each_task in enumerate(self.taskQueue):
            if each_task.isLate(self.env.now) == True:
                count += 1
        
        return count
            
        

      
    def isTaskQEmpty(self):
        return len(self.taskQueue) == 0
    
    def isTaskQFull(self):
        return len(self.taskQueue) == self.taskQueueSize          
        
    def get_Task(self,ix):
        return self.taskQueue[ix]
    
    def get_NumTasksInQ(self):
        return len(self.taskQueue)
    
    def get_TotalCompletedTasks(self):
        return len(self.completedTasks)
    
    def get_TotalTaskExecutionTime(self):
        cc = 0
        for each_task in self.completedTasks:
            cc = cc +  each_task.get_computationCost()
            
        return cc
    
    
    #######################    
    # memory i/o management
    #######################
    
    def get_memWrite(self):
        return self.memWrite
    
    def flushMemoryWriteCounter(self):
        ## every x times he wakes up we flush the memwrite
        if(self._memWriteCounter > SimParams.MEMWRITE_FLUSH_WINDOW):
            self._memWriteCounter = 0
            self.memWrite = 0
        else:
            self._memWriteCounter = self._memWriteCounter + 1
    
    
######################################################
#    TASK EXECUTION LOOPS
#    The Node has a seperate execution loop function
#    for different Task-Types
######################################################

    # non-preemptive - event triggered
    def run_MPEG2FrameTask_ET_ExecutionLoop(self):
        Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'run_MPEG2FrameTask_ET_ExecutionLoop::, : run starting', DebugCat.DEBUG_CAT_CPUINFO)
        task_tq_ix = 0
        while True:
            # set node status
            self.status = NodeStatus.NODE_ACTIVE
            #######################################################
            ## check taskq, select next task to execute based on
            ## local scheduling policy
            #######################################################
            if(self.isTaskQEmpty() == False):
                # set node status
                self.status = NodeStatus.NODE_ACTIVE
                
                # clean task-Q, w.r.t missed deadlines by other tasks
                self.check_taskDeadlineMissedbyOtherCores()
                
                # get next task from scheduler
                (task_tq_ix, task) = self.scheduler.nextTask(self.taskQueue, task_tq_ix, self.dependency_buff.get_BuffContents(), self.env.now)
                
                if (task != None):                
                    ## process the next task ##
                    
                    # set task start-time, remaining time
                    if(task.get_taskStartTime() == None):
                        task.set_taskStartTime(self.env.now)
                        self.taskQueue[task_tq_ix].set_taskStartTime(self.env.now)
                        
                    Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'run_MPEG2FrameTask_ET_ExecutionLoop::, : Now running Task - %s' % (task._debugShortLabel()), DebugCat.DEBUG_CAT_CPUINFO)
                    
                    # pre=emptive mode, therefore task runs till completion or until interrupted                    
                    try:                                    
                        ##############################
                        ## Start computation
                        ##############################
                        # set task status
                        self.status = NodeStatus.NODE_BUSY    # set node status
                        self.setTaskStatus(task_tq_ix, task.get_id(), TaskStatus.TASK_RUNNING)                                                               
                        
                        # set last activation time
                        self.taskQueue[task_tq_ix].set_lastActiveTime(self.env.now)                                                
                        
                        self.currentRunningTaskID = task   # set current running task
                        runtime = self.taskQueue[task_tq_ix].get_remainingComputationCost()                   
                        yield self.env.timeout(runtime)                        
                        
                        self.status = NodeStatus.NODE_IDLE  # set node status
                                
                        ##############################
                        ## Set task specific params 
                        ##############################                    
                        # set task complete time
                        task.set_taskCompleteTime(self.env.now)
                        self.taskQueue[task_tq_ix].set_taskCompleteTime(self.env.now)
                        self.taskQueue[task_tq_ix].set_remainingComputationCost(0.0)
                        
                        ##############################
                        ## record task as completed
                        ############################## 
                        self.markTaskAsCompleted(task)
                        self.setTaskStatus(task_tq_ix, task.get_id(), TaskStatus.TASK_COMPLETED)                   
                        
                        ##############################
                        ## notify RM to populate the 
                        ## mapping and flow tables
                        ##############################
                        
                        # first map child tasks
#                        self.lock_RM_TMtbl()
#                        self.lock_RM_FLWtbl()            
#                        self.resource_manager_instance.Mapper.mapChildTasks(task)   
#                        self.release_RM_TMtbl()
#                        self.release_RM_FLWtbl()       
                        
                        # then try to release them
                        self.lock_RM_TMtbl()
                        self.lock_RM_FLWtbl()
                        new_scheduled_tasks = self.resource_manager_instance.Mapper.releaseChildTasks(task, self.get_id())
                        self.release_RM_TMtbl()
                        self.release_RM_FLWtbl()                 
                        
                        if(len(new_scheduled_tasks) > 0):                        
                            Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'run_MPEG2FrameTask_ET_ExecutionLoop:: scheduled new tasks, so going to interrupt RM', DebugCat.DEBUG_CAT_CPUINFO)
                            when_to_interrupt = self.env.now + SimParams.SYNCH_TIME_OFFSET
                            self.env.process(self.interruptRMAfterDelay(when_to_interrupt, task.get_id()))
                            #self.env.process(self.interruptRMImmediately())
                            
                    
                        ##############################
                        ## Task is now finished
                        ##############################
                        ## TODO:: (1) send output to other nodes - with induced network delay
                        self.sendCompletedTaskToOtherNodes_ET(task)                    
                        
                        ## (2) send output to output buffer and sleep accordingly
                        # update memory write
                        self.memWrite = self.memWrite + task.get_maxMemConsumption()
                        
                        # go to sleep for the time equal to writing to shared mem                    
                        self.status = NodeStatus.NODE_BUSY_DATAIO    # set node status
                        # remove from taskq
                        
                        #print(self.label + ' : Now removing task (%d)- at %f' % (task.get_id(), self.env.now))
                        self.remove_Task(task_tq_ix)                     
                        
                        # tell RM that task has finished
                        self.resource_manager_instance.UpdateVideoStreamInfo_taskCompleted(task)                    
                        
                        # update slack in slack-reclaim-table
                        if(SimParams.SLACK_FEEDBACK_ENABLED == True):
                            if(self.resource_manager_instance.addToSlackReclaimTable(task.get_id(), self.get_id(), self.env.now) == True):
                                # tell RM to update his task tables, based on reclaimed_slack
                                
                                self.lock_RM_TMtbl()                       
                                (result, interrupt_time) = self.resource_manager_instance.reclaimSlack(task)
                                self.release_RM_TMtbl() 
                                                            
                                if(result == True):
                                    self.env.process(self.interruptRMAfterDelay(interrupt_time, task.get_id()))
                        
                        # signal RM regarding end of stream processing
                        self.notifyRM_endofStream(task)
                        
                        # send the completed task to the output buffer
                        self.env.process(self.sendTaskToOutputBuffAfterDelay(task, task_tq_ix))
                        
                        # remove dependencies                    
                        self.dependencyBuff_cleanUp(task)                        
                    
                    except simpy.Interrupt:
                        #print(self.label + ' : I got interrupted !! but I was BUSY computing ! - status = '+ str(self.status))
                        #sys.exit()
                        Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'run_MPEG2FrameTask_ET_ExecutionLoop::, : I got interrupted !! but I was BUSY computing !', DebugCat.DEBUG_CAT_INTERRUPT)
                        
                        #### task computation gets pre-empted by another higher priority task ####
                        # set the currently running task to null
                        self.currentRunningTaskID = None
                        
                        # suspend the task
                        self.setTaskStatus(task_tq_ix, task.get_id(), TaskStatus.TASK_SUSPENDED)
                        
                        # update the remaining computation cost
                        self.updateTaskRemainingCompCost(task_tq_ix)
                    
                                       
                else:
                    try:
                        # taskQ is not empty - but none of the tasks are ready to run (missing deps ??)
                        # so go to sleep
                        print(self.label + ' : None of the tasks in this CPU, has all their deps -  at %f' % self.env.now)
                        pprint.pprint(self.taskQueue)
                        pprint.pprint(self.resource_manager_instance.task_mapping_table)
                        sys.exit()
                        
                        self.status = NodeStatus.NODE_IDLE # set node status                  
                        #print(self.label + ' : my task-q is empty! at %d' % self.env.now)
                        yield self.env.timeout(self.IDLE_SLEEP_TIME)
                    except simpy.Interrupt:
                        self.status = NodeStatus.NODE_JUSTWOKEUP # set node status
                        Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'run_MPEG2FrameTask_ET_ExecutionLoop::, : I got interrupted (again) now!', DebugCat.DEBUG_CAT_INTERRUPT) 
                    
                
            else:   ## TASK-Q IS EMPTY !!
                try:
                    # set node status
                    self.status = NodeStatus.NODE_IDLE                    
                    #print(self.label + ' : my task-q is empty! at %d' % self.env.now)
                    yield self.env.timeout(self.IDLE_SLEEP_TIME)
                except simpy.Interrupt:
                    self.status = NodeStatus.NODE_JUSTWOKEUP # set node status
                    Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'run_MPEG2FrameTask_ET_ExecutionLoop::, : I got interrupted now!', DebugCat.DEBUG_CAT_INTERRUPT)
    
    
    
#    # non-preemptive - time triggered
#    def run_MPEG2FrameTask_TT_ExecutionLoop(self):
#        Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'run_MPEG2FrameTask_TT_ExecutionLoop::, : run starting', DebugCat.DEBUG_CAT_CPUINFO)
#        ix = 0
#        while True:
#            # set node status
#            self.status = NodeStatus.NODE_ACTIVE
#            #######################################################
#            ## check taskq, select next task to execute based on
#            ## local scheduling policy
#            #######################################################
#            if(self.isTaskQEmpty() == False):
#                # set node status
#                self.status = NodeStatus.NODE_ACTIVE
#                
#                # clean task-Q, w.r.t missed deadlines by other tasks
#                self.check_taskDeadlineMissedbyOtherCores()
#                
#                # get next task from scheduler
#                (ix, task) = self.scheduler.nextTask(self.taskQueue, ix, self.dependency_buff.get_BuffContents(), self.env.now)
#                
#                if (task != None):                
#                    ## process the next task ##
#                    
#                    # set task start-time
#                    if(task.get_taskStartTime() == None):
#                        task.set_taskStartTime(self.env.now)
#                        
#                    Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'run_MPEG2FrameTask_TT_ExecutionLoop::, : Now running Task - %s' % (task._debugShortLabel()), DebugCat.DEBUG_CAT_CPUINFO)
#                    
#                    # non-preemptive mode, therefore task runs till completion
#                    # going to sleep till the time of computation time
#                    
#                    task.compute(task.get_computationCost())
#                    self.status = NodeStatus.NODE_BUSY    # set node status  
#                    try:              
#                        yield self.env.timeout(task.get_computationCost())
#                    except simpy.Interrupt:
#                        print(self.label + ' : I got interrupted !! but I was BUSY computing ! - status = '+ str(self.status))
#                        sys.exit()
#                                
#                    ##############################
#                    ## Set task specific params 
#                    ##############################                    
#                    # set task complete time
#                    task.set_taskCompleteTime(self.env.now)
#                    
#                    ##############################
#                    ## record task as completed
#                    ############################## 
#                    self.markTaskAsCompleted(task)
#                
#                    ##############################
#                    ## Task is now finished
#                    ##############################
#                    ## TODO:: (1) send output to other nodes - with induced network delay
#                    self.sendCompletedTaskToOtherNodes(task)                    
#                    
#                    ## (2) send output to output buffer and sleep accordingly
#                    # update memory write
#                    self.memWrite = self.memWrite + task.get_maxMemConsumption()
#                    
#                    # go to sleep for the time equal to writing to shared mem                    
#                    self.status = NodeStatus.NODE_BUSY_DATAIO    # set node status
#                    # remove from taskq
#                    
#                    #print(self.label + ' : Now removing task (%d)- at %f' % (task.get_id(), self.env.now))
#                    self.remove_Task(ix) 
#                    
#                    
#                    # tell RM that task has finished
#                    self.resource_manager_instance.UpdateVideoStreamInfo_taskCompleted(task)
#                    
#                    
#                    # update slack in slack-reclaim-table
#                    if(SimParams.SLACK_FEEDBACK_ENABLED == True):
#                        if(self.resource_manager_instance.addToSlackReclaimTable(task.get_id(), self.get_id(), self.env.now) == True):
#                            # tell RM to update his task tables, based on reclaimed_slack
#                            
#                            while(self.resource_manager_instance.mutex_tmtbl.level == 1):
#                                i=1 # busy wait                                
#                            
#                            self.resource_manager_instance.mutex_tmtbl.put(1)                            
#                            (result, interrupt_time) = self.resource_manager_instance.reclaimSlack(task)
#                            self.resource_manager_instance.mutex_tmtbl.get(1)
#                            
#                                                        
#                            if(result == True):
#                                self.env.process(self.interruptRMAfterDelay(interrupt_time, task.get_id()))
#                    
#                    
#                    # removes from the task mapping table
#                    while(self.resource_manager_instance.mutex_tmtbl.level == 1):
#                        i=1 # busy wait   
#                    self.resource_manager_instance.mutex_tmtbl.put(1)                                  
#                    self.resource_manager_instance.removeMapppingTableEntry(task.get_id())    
#                    self.resource_manager_instance.mutex_tmtbl.get(1)               
#                    
#                    # send the completed task to the output buffer
#                    self.env.process(self.sendTaskToOutputBuffAfterDelay(task, ix))                    
#                    
#                    # remove dependencies
#                    # TODO::
#                    self.dependencyBuff_cleanUp(task)                    
#                else:
#                    try:
#                        # taskQ is not empty - but none of the tasks are ready to run (missing deps ??)
#                        # so go to sleep
#                        print(self.label + ' : None of the tasks in this CPU, has all their deps -  at %f' % self.env.now)
#                        pprint.pprint(self.taskQueue)
#                        pprint.pprint(self.resource_manager_instance.task_mapping_table)
#                        sys.exit()
#                        
#                        self.status = NodeStatus.NODE_IDLE # set node status                  
#                        #print(self.label + ' : my task-q is empty! at %d' % self.env.now)
#                        yield self.env.timeout(self.IDLE_SLEEP_TIME)
#                    except simpy.Interrupt:
#                        self.status = NodeStatus.NODE_JUSTWOKEUP # set node status
#                        Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'run_MPEG2FrameTask_TT_ExecutionLoop::, : I got interrupted (again) now!', DebugCat.DEBUG_CAT_INTERRUPT) 
#                    
#                
#            else:   ## TASK-Q IS EMPTY !!
#                try:
#                    # set node status
#                    self.status = NodeStatus.NODE_IDLE                    
#                    #print(self.label + ' : my task-q is empty! at %d' % self.env.now)
#                    yield self.env.timeout(self.IDLE_SLEEP_TIME)
#                except simpy.Interrupt:
#                    self.status = NodeStatus.NODE_JUSTWOKEUP # set node status
#                    Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'run_MPEG2FrameTask_TT_ExecutionLoop::, : I got interrupted now!', DebugCat.DEBUG_CAT_INTERRUPT)
#    
    # non-preemptive
#    def run_MPEG2FrameTask_ExecutionLoop(self):
#        Debug.PPrint(self.label + ' : run starting at %f' % self.env.now, DebugCat.DEBUG_CAT_CPUINFO)
#        ix = 0
#        while True:
#            # set node status
#            self.status = NodeStatus.NODE_ACTIVE
#            #######################################################
#            ## check taskq, select next task to execute based on
#            ## local scheduling policy
#            #######################################################
#            if(self.isTaskQEmpty() == False):
#                # set node status
#                self.status = NodeStatus.NODE_ACTIVE
#                
#                # clean task-Q, w.r.t missed deadlines by other tasks
#                self.check_taskDeadlineMissedbyOtherCores()
#                
#                # get next task from scheduler
#                (ix, task) = self.scheduler.nextTask(self.taskQueue, ix, self.dependency_buff.get_BuffContents(), self.env.now)
#                
#                if (task != None):                
#                    ## process the next task ##
#                    
#                    # set task start-time
#                    if(task.get_taskStartTime() == None):
#                        task.set_taskStartTime(self.env.now)
#                        
#                    Debug.PPrint(self.label + ' : Now running Task - %s at %f' % (task._debugShortLabel() , self.env.now), DebugCat.DEBUG_CAT_CPUINFO)
#                    
#                    # non-preemptive mode, therefore task runs till completion
#                    # going to sleep till the time of computation time
#                    # but first need to check if deadline won't pass after executing
#                    if(task.willTaskMissItsDeadline(self.env.now) == True):              
#                        
#                        Debug.PPrint(self.label + ' : Task '+ str(task.get_id())+' will probably miss its deadline.., abd=' + str(task.get_absDeadline()), DebugCat.DEBUG_CAT_CPUINFO)
#                        task.set_missedDeadlineFlag(True)
#                        # add to drop task list
#                        self.tasks_that_missed_deadline.append(task)
#                        # remove from taskq
#                        self.remove_Task(ix)
#                        # notify other dependent nodes
#                        # TODO::
#                        self.notifyOtherNodes_TaskDeadlineMiss(task)
#                        
#                    else:
#                        task.compute(task.get_computationCost())
#                        self.status = NodeStatus.NODE_BUSY    # set node status  
#                        try:              
#                            yield self.env.timeout(task.get_computationCost())
#                        except simpy.Interrupt:
#                            print(self.label + ' : I got interrupted !! but I was BUSY computing ! - status = '+ str(self.status))
#                            sys.exit()
#                                    
#                        ##############################
#                        ## Set task specific params 
#                        ##############################                    
#                        # set task complete time
#                        task.set_taskCompleteTime(self.env.now)
#                        
#                        ##############################
#                        ## record task as completed
#                        ############################## 
#                        self.markTaskAsCompleted(task)
#                    
#                        ##############################
#                        ## Task is now finished
#                        ##############################
#                        ## TODO:: (1) send output to other nodes - with induced network delay
#                        self.sendCompletedTaskToOtherNodes(task)                    
#                        
#                        ## (2) send output to output buffer and sleep accordingly
#                        # update memory write
#                        self.memWrite = self.memWrite + task.get_maxMemConsumption()
#                        
#                        # go to sleep for the time equal to writing to shared mem                    
#                        self.status = NodeStatus.NODE_BUSY_DATAIO    # set node status
#                        # remove from taskq
#                        self.remove_Task(ix)
#                        # send the completed task to the output buffer
#                        self.env.process(self.sendTaskToOutputBuffAfterDelay(task, ix))               
#                        
#                        # remove dependencies
#                        # TODO::
#                        self.dependencyBuff_cleanUp(task)                    
#                else:
#                    try:
#                        # taskQ is not empty - but none of the tasks are ready to run (missing deps ??)
#                        # so go to sleep
#                        #print(self.label + ' : None of the tasks in this CPU, has all their deps -  at %f' % self.env.now) 
#                        self.status = NodeStatus.NODE_IDLE # set node status                  
#                        #print(self.label + ' : my task-q is empty! at %d' % self.env.now)
#                        yield self.env.timeout(self.IDLE_SLEEP_TIME)
#                    except simpy.Interrupt:
#                        self.status = NodeStatus.NODE_JUSTWOKEUP # set node status
#                        Debug.PPrint(self.label + ' : I got interrupted (again) now! at %f' % self.env.now, DebugCat.DEBUG_CAT_INTERRUPT) 
#                    
#                
#            else:   ## TASK-Q IS EMPTY !!
#                try:
#                    # set node status
#                    self.status = NodeStatus.NODE_IDLE                    
#                    #print(self.label + ' : my task-q is empty! at %d' % self.env.now)
#                    yield self.env.timeout(self.IDLE_SLEEP_TIME)
#                except simpy.Interrupt:
#                    self.status = NodeStatus.NODE_JUSTWOKEUP # set node status
#                    Debug.PPrint(self.label + ' : I got interrupted now! at %f' % self.env.now, DebugCat.DEBUG_CAT_INTERRUPT)                
#                    
    
                
    ######################################################
    # Task dependency management
    # send/receive completed tasks
    ######################################################
    def sendTaskToOutputBuffAfterDelay(self, task, ix):
        
        max_mem_consumption_mb = float(float(task.get_maxMemConsumption())/float((1024.0*1024.0)))
        mem_transfer_delay = SimParams.SHARED_MEM_WRITE_TIME_PER_MB * (max_mem_consumption_mb)                    
        yield self.env.timeout(mem_transfer_delay)       
       
        # add to output buff
        self.outputBuffInstance.add_Item(task, task.get_id())                    
        self.OutputBuff_put(1)   
        
        self.resource_manager_instance.Mapper.taskMappingTable_Remove(task)     
        
        if(self.OutputBuff_areAllTasksInside()):
            print("%f"%self.env.now + "," + self.label + "," +'sendTaskToOutputBuffAfterDelay::, : SIMULATION FINISHED  (max tasks in output buff)!')
            simpy.core._stop_simulate(1)
            #self.env.exit()
            #sys.exit("All tasks simulated")
        else:
            if(self.resource_manager_instance.endSimulation() == True):
                print("%f"%self.env.now + "," + self.label + "," +'sendTaskToOutputBuffAfterDelay::, : SIMULATION FINISHED (RM says end of sim)!')
                simpy.core._stop_simulate(1)
            
            
    
    def sendTaskToNodeAfterDelay(self, task, node, delay, flow_id):            
            
            yield self.env.timeout(delay)   # delay            
            # put to dest node's  dep-buff
            result = node.dependencyBuff_put(task)
            if(result == True):
                Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'sendTaskToNodeAfterDelay::, : task-'+ str(task.get_id()) + ' successfully transmitted to Node-'+str(node.get_id()) + ', with TxDelay='+str(delay), DebugCat.DEBUG_CAT_TRANSMIT)
                
                # notify RM that the flow has completed
                self.lock_RM_FLWtbl()
                self.lock_RM_TMtbl() 
                new_released_tasks = self.resource_manager_instance.Mapper.notifyFlowComplete(flow_id)
                self.release_RM_FLWtbl()
                self.release_RM_TMtbl() 
                
                if(len(new_released_tasks) > 0):                    
                    when_to_interrupt = self.env.now + SimParams.SYNCH_TIME_OFFSET
                    self.env.process(self.interruptRMAfterDelay(when_to_interrupt, -1))
                    
                
            else:
                print("%f"%self.env.now + "," + self.label + "," +'sendTaskToNodeAfterDelay::, : node-'+ str(node.get_id()) + ", --- dep_buff is FULL ! ")
                pprint.pprint(node.dependency_buff.get_BuffContents())
                pprint.pprint(self.resource_manager_instance.task_mapping_table)
                sys.exit()
                
            
            # if node is asleep wake him up !!
            #if(node.get_status() == NodeStatus.NODE_IDLE):                  
            #    node.processInstance.interrupt()
    
#    def sendCompletedTaskToOtherNodes(self, task):
#        
#        print self.label + ": sendCompletedTaskToOtherNodes:: Enter : taskid =" + str(task.get_id()) 
#        
#        # need to maintain temp_distribution list so that we don't duplicate any transmissions
#        # e.g. P, B mapped to core-B, I mapped to core-A, so A sends task *twice* to core-B - WRONG !!
#        temp_distribution_list = []
#        
#        # which tasks needs this task ?
#        dependent_tasks_list = task.get_which_tasks_needs_me()
#        
#        # which nodes should this task be sent to ?
#        for each_task_id in dependent_tasks_list:
#            
#            node_id = self.getTaskMappedNode(each_task_id)
#            #print  "node_id : " + str(node_id)          
#            if(node_id != None):
#                if((node_id in temp_distribution_list) == False):
#                    temp_distribution_list.append(node_id)
#                    
#                    # send to node, but before sending we need to check if
#                    # we have already sent it before..
#                    if(self.node_network.get_Nodes()[node_id].dependencyBuff_IsTaskInBuff(task.get_id()) == False):
#                        
#                        # check if source == dest (no transmission needed!)
#                        if(self.get_id() == node_id):
#                            result = self.dependencyBuff_put(task)
#                            
#                            self._markDepsCompleted_InRMTMTbl(task.get_id(), each_task_id)
#                            
#                            if(result == False):
#                                print(self.label + ' sendCompletedTaskToOtherNodes : node-'+ str(self.get_id()) + ", --- dep_buff is FULL ! at " +  str(self.env.now))
#                                sys.exit()
#                            #else:
#                            #    # mark dependancies completed
#                            #    if(task.get_id() not in self.resource_manager_instance.task_mapping_table[each_child_task_id]['deps_completed']):
#                                
#                        else:                        
#                            
#                            
#                            #### (3) add a flow table entry
#                            # finished task to all it's children tasks - previous step
#                            # should have mapped all children tasks
#                            
#                            while(self.resource_manager_instance.flow_table.mutex.level == 1):
#                                i=1 # busy wait                                       
#                            self.resource_manager_instance.flow_table.mutex.put(1)   # obtain lock    
#                            while(self.resource_manager_instance.mutex_tmtbl.level == 1):
#                                i=1 # busy wait                                                            
#                            self.resource_manager_instance.mutex_tmtbl.put(1)      # obtain lock                           
#                                                                                
#                            self.resource_manager_instance.Mapper.addTo_RM_FlowTable([task], self.env.now, self.get_id())
#                            
#                            self.resource_manager_instance.mutex_tmtbl.get(1)      # obtain lock      
#                            self.resource_manager_instance.flow_table.mutex.get(1)   # obtain lock                            
#                            
#                            #delay = self.onchip_network.getRouteCost(self.get_id(), node_id, task.get_completedTaskSize())
#                            
#                            # update RM flow table                            
##                            (flow_id, flow) = self.resource_manager_instance.flow_table.get_flow(src_task_id=task.get_id(), 
##                                                                                                 dst_task_id=each_task_id,
##                                                                               src_node_id=self.get_id(), 
##                                                                               dst_node_id=node_id)
##                            self.resource_manager_instance.flow_table.set_releaseTime(self.env.now, flow_id=flow_id)
##                            self.resource_manager_instance.flow_table.set_active(True, flow_id=flow_id)                                             
##                            self.env.process(self.sendTaskToNodeAfterDelay(task, self.node_network.get_Nodes()[node_id], delay, flow_id))
#            
#            else:
#                print(self.label + ' sendCompletedTaskToOtherNodes : each_task_id -'+str(each_task_id) + ' not yet mapped!, curr_task='+str(task.get_id()))
#                sys.exit()
    
    
    def sendCompletedTaskToOtherNodes_ET(self, task):
       
        Debug.PPrint("%.15f"%self.env.now + "," + self.label + "," +'sendCompletedTaskToOtherNodes_ET::, Enter (taskid=%d)' % (task.get_id()), DebugCat.DEBUG_CAT_CPUINFO)
        
        # need to maintain temp_distribution list so that we don't duplicate any transmissions
        # e.g. P, B mapped to core-B, I mapped to core-A, so A sends task *twice* to core-B - WRONG !!
        temp_distribution_list = []
        
        # which tasks needs this task ?
        dependent_tasks_list = task.get_which_tasks_needs_me()        
        
        ## check if all of the dep tasks have a mapped core, else raise error
        for each_dep_t in dependent_tasks_list:
            node_id = self.getTaskMappedNode(each_dep_t)
            if(node_id == None):
                print(self.label + ' sendCompletedTaskToOtherNodes_ET : each_task_id -'+str(each_dep_t) + ' not yet mapped!, curr_task='+str(task.get_id()))
                sys.exit()
            else:
                
                # send to node, but before sending we need to check if
                # we have already sent it before..
                if(self.node_network.get_Nodes()[node_id].dependencyBuff_IsTaskInBuff(task.get_id()) == False):                
                
                    # check if child is mapped on same node
                    # if true, put to self nodes dep buffer and mark dep check list in RMTM table
                    if(node_id == self.get_id()):
                        result = self.dependencyBuff_put(task)
                        if(result == False):
                            print(self.label + ' sendCompletedTaskToOtherNodes_ET : node-'+ str(self.get_id()) + ", --- dep_buff is FULL ! at " +  str(self.env.now))
                            sys.exit()                            
                        self._markDepsCompleted_InRMTMTbl(task.get_id(), each_dep_t)
        
        self.lock_RM_FLWtbl()
        self.lock_RM_TMtbl()                           
                                                            
        self.resource_manager_instance.Mapper.addTo_RM_FlowTable([task], self.env.now, self.get_id())
        
        #self.resource_manager_instance.mutex_tmtbl.get(1)      # release lock      
        #self.resource_manager_instance.flow_table.mutex.get(1)   # release lock   
        
        self.release_RM_FLWtbl()
        self.release_RM_TMtbl()              
                            
    
    
    
    # all cores maintain a list, which tracks task-deadlines missed by other cores
    # if a task deadline is missed by the current core, then this function is called
    # this function then adds the missed-task into the relevent other cores' task-missed list
    def notifyOtherNodes_TaskDeadlineMiss(self, task):
         
        # which tasks needs this task ?
        dependent_tasks_list = task.get_which_tasks_needs_me()
        
        # which nodes should be notified ?
        for each_task_id in dependent_tasks_list:            
            node_id = self.getTaskMappedNode(each_task_id)
            if node_id != None:
                nn = self.node_network.get_Nodes()      
                nn[node_id].tasks_that_missed_deadline_by_other_cores.append(task.get_id())
                
    # all cores maintain a list, which tracks task-deadlines missed by other cores
    # this list needs to be checked, to see if before processing the next task if a dependent
    # task is missed ? 
    def check_taskDeadlineMissedbyOtherCores(self):
        needed_dep_tasks = []
        
        tasks_in_q = self.taskQueue
        
        # get all dependent tasks required
        for ix, each_task in enumerate(tasks_in_q):
            
            dep_tasks = each_task.get_dependencies()
            
            # get common elements in two lists
            if((dep_tasks != None) and (self.tasks_that_missed_deadline_by_other_cores != None)):
            
                common = list(set(dep_tasks).intersection(self.tasks_that_missed_deadline_by_other_cores))
                
                if( len(common) > 0): # if there are common, then drop task from taskQ
                    each_task.set_missedDeadlineFlag(True)
                    # add to drop task list
                    self.tasks_that_missed_deadline.append(each_task)
                    # remove from taskq
                    self.remove_Task(ix)
    
        
    def interruptRMAfterDelay(self, when_to_interrupt, finished_task_id):
        
        delay = when_to_interrupt - self.env.now
        
        if(delay > 0):
            yield self.env.timeout(delay)   # delay   
        
            if(self.resource_manager_instance.status == CPU_RMStatus.RM_SLEEPING):
                Debug.PPrint("%.15f"%self.env.now + "," + self.label + "," +'interruptRMAfterDelay::, interrupting RM (finished_task_id=%d)' % (finished_task_id), DebugCat.DEBUG_CAT_INTERRUPT)
                self.resource_manager_instance.processInstance.interrupt("CPU-"+str(self.get_id()))
        
    
    def interruptRMImmediately(self):
        if(self.resource_manager_instance.status == CPU_RMStatus.RM_SLEEPING):
            Debug.PPrint("%f"%self.env.now + "," + self.label + "," +'interruptRMImmediately::, interrupting RM ', DebugCat.DEBUG_CAT_INTERRUPT)
            self.resource_manager_instance.processInstance.interrupt("CPU-"+str(self.get_id()))
    
    
    def _markDepsCompleted_InRMTMTbl(self, fin_task_id, child_task_id):
        self.lock_RM_TMtbl()  
                     
        if(fin_task_id not in self.resource_manager_instance.task_mapping_table[child_task_id]['deps_completed']):
            self.resource_manager_instance.task_mapping_table[child_task_id]['deps_completed'].append(fin_task_id)
        
        self.release_RM_TMtbl()
        
        
        
    ######################################################
    # Shared resources locking mechanisms
    #  - RM task mapping table
    #  - RM flow table
    ######################################################
    
    def lock_RM_TMtbl(self):
        while(self.resource_manager_instance.mutex_tmtbl.level == 1):
            i=1 # busy wait                                                            
        self.resource_manager_instance.mutex_tmtbl.put(1) # obtain lock
        
    def release_RM_TMtbl(self):
        self.resource_manager_instance.mutex_tmtbl.get(1) # release lock
        
    def lock_RM_FLWtbl(self):
        while(self.resource_manager_instance.flow_table.mutex.level == 1):
            i=1 # busy wait                                       
        self.resource_manager_instance.flow_table.mutex.put(1)   # obtain lock   
    
    def release_RM_FLWtbl(self):
        self.resource_manager_instance.flow_table.mutex.get(1) # release lock
    
    ######################################################
    # Related to runtime application management
    ######################################################
    
    def notifyRM_endofStream(self, task):
        
        if(task.get_isTailVideoGop() == True):
            if(task.get_frameIXinGOP() == (len(task.get_gopstructure())-1)):
                
                #sys.exit("here")                
        
                wf_id = task.get_wfid()
                strm_id = task.get_video_stream_id()
                
                self.resource_manager_instance.RuntimeApp_removeStream(wf_id, strm_id)
                
                
        