import pprint.pprint

## local imports


class TaskQueue:
    def __init__(self):