import pprint
import sys

import simpy

## local imports
import Task
import Buffer
from SimParams import SimParams
from Task import TaskModel
from RunTimeTaskManager_TT import RMStatus
from Debug import Debug, DebugCat


class TaskDispatcher:
    def __init__(self, env, in_buffs, ts, multiple_workflows, period, rm):
        self.env = env
        self.input_buffers = in_buffs
        self.taskset_pool = ts
        self.multiple_workflows = multiple_workflows
        self.label = "TaskDispatcher"
        self.dispatch_period = period
        self.runtimeTaskManagerInstance = rm
        
        self.rejectedVideoStreams = []
        
        self.total_blocks_dispatched = 0
                
        # in one invocation, how many tasks should be mapped to the cores
        self.dispatch_block_size = SimParams.TASKDISPATCHER_BLOCK_SIZE        
    
        # Start the run process everytime an instance is created.        
        self.processInstance = env.process(self.runMultipleWorkflows_ET())
        
    
#    ### assume :
#    ## - all workflows operate at same rate
#    ## - one gop is inserted into each input buff from respective workflows at each event
#    def runMultipleWorkflows(self):
#        ## wait for a bit before starting - give time for nodes to catch up
#        ## due to node's initial start sleep delay 
#        yield self.env.timeout(SimParams.TASKDISPATCHER_RESET_DELAY)          
#        
#        print("%f"%self.env.now + "," + self.label + "," + "runMultipleWorkflows::," +' : run starting')
#        
#        if(len(self.input_buffers) != len(self.multiple_workflows)):
#            print(self.label + ' : NumInputBuffers != NumWorflows %f' % self.env.now)
#            sys.exit()
#            
#        while True:
#            
#            num_tasks_dispatched_in_this_cycle = 0
#            
#            for wf_id in xrange(len(self.input_buffers)):                
#                if(self.multiple_workflows[wf_id].isEmpty() == False):
#                    #print(self.label + ' : waking up and doing work at:  %d' % self.env.now)            
#                    
#                    ## perform task dispatch - take from pool and put into input buffer
#                    # we enter a whole block in one go ! (block size defined elsewhere)
#                    if(self.InputBuffer_isFull(offset=self.dispatch_block_size, id=wf_id) == False):                        
#                        
#                        for j in xrange(0,self.dispatch_block_size):
#                            task = self.multiple_workflows[wf_id].get_Task()
#                            
#                            # set the dispatch time of the task
#                            #print(self.label + ' : Dispatch time ----------  : %f' % self.env.now)    
#                            task.set_dispatchTime(self.env.now)
#                            
#                            self.input_buffers[wf_id].add_Item(task, task.get_id())
#                                            
#                            #print "self.simpy_container_instance.level (before) = " + str(self.input_buffer.simpy_container_instance.level)
#                            #self.input_buffer.simpyContainer_put(1) ## add to simpy container
#                            self.InputBuffer_put(1, id=wf_id)
#                            #print "self.simpy_container_instance.level (after) = " + str(self.input_buffer.simpy_container_instance.level)
#                            
#                            num_tasks_dispatched_in_this_cycle += 1
#                        
#                        self.total_blocks_dispatched +=1                    
#                            
#                    else:
#                        Debug.PPrint("%f"%self.env.now + "," + self.label + "," + 'runMultipleWorkflows::, InputBuffer FULL!!', DebugCat.DEBUG_CAT_TDINFO)    
#                else:
#                    Debug.PPrint("%f"%self.env.now + "," + self.label + "," + 'runMultipleWorkflows::, : WorkFlow [%d] is empty !!' % (wf_id), DebugCat.DEBUG_CAT_TDINFO)
#                    #self.env.stop()
#                    
#                    
#            ## all appropriate tasks in all workflows are now dispatched to respective inputbuffers, 
#            ## now wake up RM and go to sleep
#            if(num_tasks_dispatched_in_this_cycle > 0):
#                Debug.PPrint("%f"%self.env.now + "," + self.label + "," + 'runMultipleWorkflows::, : %d tasks submitted to input buffers !!!! ' % (num_tasks_dispatched_in_this_cycle), DebugCat.DEBUG_CAT_TDINFO)
#                self.wakeUpRM()
#            else:
#                Debug.PPrint("%f"%self.env.now + "," + self.label + "," + 'runMultipleWorkflows::, : No tasks dispatched !!!! ', DebugCat.DEBUG_CAT_TDINFO)
#            
#            ## go back to sleep
#            #print(self.label + ' : going to sleep  at:  %f' % self.env.now)
#            yield self.env.timeout(self.dispatch_period)
                
                
    ### assume :
    ## - fixed number of workflows in simulation
    ## - within a workflow jobs will have different arrival rates
    ## - one gop is inserted into each input buff from respective workflows at each event
    def runMultipleWorkflows_ET(self):
        ## wait for a bit before starting - give time for nodes to catch up
        ## due to node's initial start sleep delay 
        yield self.env.timeout(SimParams.TASKDISPATCHER_RESET_DELAY)          
        
        print("%f"%self.env.now + "," + self.label + "," + 'runMultipleWorkflows_ET::, : run starting')
        
        if(len(self.input_buffers) != len(self.multiple_workflows)):
            print("%f"%self.env.now + "," + self.label + "," + 'runMultipleWorkflows_ET::, : NumInputBuffers != NumWorflows')
            sys.exit()
            
        while True:
            
            num_tasks_dispatched_in_this_cycle = 0
            tasks_ids_dispatched_this_cycle = []
            
            for wf_id in xrange(SimParams.NUM_WORKFLOWS):   
                new_video_submitted = False             
                if(self.multiple_workflows[wf_id].tasksNotDispatched() > 0):
                    
                    ## perform task dispatch - take from pool and put into input buffer
                    # each task has a specified dispatch time, all scheduled dispatched
                    # times matching the current dispatch time is dispatched
                    if(self.InputBuffer_isFull(offset=self.dispatch_block_size, id=wf_id) == False) and \
                    ((self.IsPlatformOverloaded() == False)):
                        
                        # if a new video stream, then check if it can be permitted into the system before releasing first GOP                        
                        self._canVideoBeDispatched(wf_id)   # this disables submission of rejected video streams           
                        
                        temp_count = 0
                        for task in self.multiple_workflows[wf_id].get_stream_content():
                            #print task
                            #print self._canTaskBeDispatched(task)
                            if(self._canTaskBeDispatched(task) == True):                                
                                                                
                                # set the dispatch time of the task
                                #print(self.label + ' : Dispatch time ----------  : %f' % self.env.now)    
                                task.set_dispatchTime(self.env.now)
                                
                                # place in input buffer
                                self.input_buffers[wf_id].add_Item(task, task.get_id())
                                self.InputBuffer_put(1, id=wf_id)
                                
                                num_tasks_dispatched_in_this_cycle += 1
                                tasks_ids_dispatched_this_cycle.append(task.get_id())
                                temp_count += 1
                                
                                # is task the first frame of a new video ?
                                if(task.get_parentGopId() == 0):                                    
                                    new_video_submitted = True
                                else:
                                    new_video_submitted = False                                
                        
                        if(temp_count == 12):
                            self.total_blocks_dispatched +=1
                    else:
                        Debug.PPrint("%f"%self.env.now + "," + self.label + "," + 'runMultipleWorkflows_ET::, : InputBuffer FULL!!, inbuffid='+str(wf_id), DebugCat.DEBUG_CAT_TDINFO)
                        
                        # update dropped tasks tracking in RM
                        self.notifyRM_droppedTasks(wf_id)
                         
                else:
                    Debug.PPrint("%f"%self.env.now + "," + self.label + "," + 'runMultipleWorkflows_ET::, : WorkFlow [%d] is empty !!' % (wf_id), DebugCat.DEBUG_CAT_TDINFO)
                    
                    # check if it is time to stop the simulation 
                    if(self.runtimeTaskManagerInstance.endSimulation()==True):
                        Debug.PPrint("%f"%self.env.now + "," + self.label + "," + 'runMultipleWorkflows_ET::, : RM says to END simulation !!', DebugCat.DEBUG_CAT_TDINFO)
                        simpy.core._stop_simulate(1)
                        
                        
            ##### DEBUG #########
#            if(self.env.now >121):
#                for i in xrange(SimParams.NUM_INPUTBUFFERS):
#                    print ""
#                    print "inputbuff="+str(i)
#                    print "-----------------"
#                    pprint.pprint(self.input_buffers[i].get_BuffContents())
#                #pprint.pprint(self.runtimeTaskManagerInstance.task_mapping_table)
#                pprint.pprint(self.runtimeTaskManagerInstance.flow_table.flowEntries)
#                pprint.pprint(self.runtimeTaskManagerInstance.flow_table.fire_rqs_outstanding)
#                pprint.pprint(self.runtimeTaskManagerInstance.numTasksInCPUTaskQs())
#                
#                sys.exit("TaskDispatcher:: runMultipleWorkflows_ET:: forced stop!!!!")
            #####################
            
                    
            ## all appropriate tasks in all workflows are now dispatched to respective inputbuffers, 
            ## now wake up RM and go to sleep
            if(num_tasks_dispatched_in_this_cycle > 0):
                t_list_str = ', '.join(str(x) for x in tasks_ids_dispatched_this_cycle)
                Debug.PPrint("%f"%self.env.now + "," + self.label + "," + ('runMultipleWorkflows_v2::, : %d tasks submitted to input buffers  - ' % (num_tasks_dispatched_in_this_cycle)) + t_list_str , DebugCat.DEBUG_CAT_TDINFO)                
                self.wakeUpRM()
            else:
                Debug.PPrint("%f"%self.env.now + "," + self.label + "," + 'runMultipleWorkflows_v2::, : No tasks dispatched !!!!', DebugCat.DEBUG_CAT_TDINFO)
            
            ## go back to sleep
            #print(self.label + ' : going to sleep  at:  %f' % self.env.now)
            #yield self.env.timeout(self.dispatch_period)
            
            # find when to dispatch next
            next_dispatch_time = self.nextTaskDispatchTime()
            
            if next_dispatch_time == None:
                yield self.env.timeout(self.dispatch_period)
            else:
                yield self.env.timeout(next_dispatch_time - self.env.now)
            
                
    # goes through all the workflows and finds the task that should be dispatched soonest, based on
    # current time
    def nextTaskDispatchTime(self):
        
        tmptasks = []
        for each_wf_val in self.multiple_workflows:        
            for each_task in each_wf_val.get_stream_content():
                if (each_task.get_scheduledDispatchTime() > self.env.now):
                    tmptasks.append(each_task)
                    break
                    
        sorted_tmptasks = sorted(tmptasks, key=lambda x: x.get_scheduledDispatchTime(), reverse=False)
        
        if len(sorted_tmptasks) > 0:
            return sorted_tmptasks[0].get_scheduledDispatchTime()
        else:
            return None
    
    
    ## notify RM of the tasks that could not be dispatched, because of overloaded platform
    # this is called when the task is ready to be dispatched (and dispatchDisabled is false) , but system is overloaded
    def notifyRM_droppedTasks(self, wf_id):
        
        Debug.PPrint("%f"%self.env.now + "," + self.label + "," + 'notifyRM_droppedTasks::, : Enter', DebugCat.DEBUG_CAT_TDINFO)
        
        dropped_task_list = []
        
        for task in self.multiple_workflows[wf_id].get_stream_content():
            if(self._canTaskBeDispatched(task) == True):    # task can be dispatched, but input buffers are full                
                if(task.get_parentGopId() == 0): # if dropping the start gop of a video stream, then drop the full video stream
                    
                    Debug.PPrint("%f"%self.env.now + "," + self.label + "," + 'notifyRM_droppedTasks::, : first gop of video stream skipped :' + str(wf_id) + " - " + str(task.get_video_stream_id()), DebugCat.DEBUG_CAT_TDINFO)
                    
                    # disable disapatch of all tasks in video stream
                    full_video_tasks = self._disableAllTaskDispatchInVS(wf_id, task.get_video_stream_id())                    
                    dropped_task_list.extend(full_video_tasks)
                    
                    # record rejection
                    self.rejectedVideoStreams.append(self._getVSInfoFromTask(task))
                else:
                    dropped_task_list.append(task)
                
        if(len(dropped_task_list) > 0):
            self.runtimeTaskManagerInstance.addDroppedTask(dropped_task_list, wf_id)
            
            # is this part of the last gop of the video stream ? if so signal RM to remove video stream from runtime app
            if(dropped_task_list[0].get_isTailVideoGop() == True):
                vs_id = dropped_task_list[0].get_video_stream_id()                
                Debug.PPrint("%f"%self.env.now + "," + self.label + "," + 'notifyRM_droppedTasks::, : last gop of video stream skipped :' + str(wf_id) + " - " + str(vs_id), DebugCat.DEBUG_CAT_TDINFO)
                self.runtimeTaskManagerInstance.RuntimeApp_removeStream(wf_id, vs_id)
                       
    
    def wakeUpRM(self):
        ## now need to wake up resource manager if sleeping
        if(self.runtimeTaskManagerInstance.status == RMStatus.RM_SLEEPING):
            Debug.PPrint("%f"%self.env.now + "," + self.label + "," + 'runMultipleWorkflows_v2::, : interrupting RM ', DebugCat.DEBUG_CAT_INTERRUPT)
            self.runtimeTaskManagerInstance.processInstance.interrupt("TaskDispatcher")
    
    
    
    def _canTaskBeDispatched(self, task):
        if(
           ( ("%.15f"%task.get_scheduledDispatchTime()) == ("%.15f"%self.env.now)) and
           (task.get_dispatchDisabled() == False)           
           ):
            return True
        else:
            return False
    
    def _isNewVideoStream(self, wf_id):
        for each_task in self.multiple_workflows[wf_id].get_stream_content():        
            if ( ("%.15f"%each_task.get_scheduledDispatchTime()) == ("%.15f"%self.env.now)):
                task = each_task                        
                break;
            
        if task == None:
            return False
        else:               
            if(task.get_parentGopId() == 0): # this is a start of a new video
                return True
            else:
                return False
        
        
    # check with RM if the video can be admitted to the system
    def _canVideoBeDispatched(self, wf_id, task=None, video_stream = None):
        #print "_canVideoBeDispatched:: Enter"
        
        if(video_stream == None):
                        
            if(task==None): # need to find the task to be dispatched now
                for each_task in self.multiple_workflows[wf_id].get_stream_content():        
                    
                    # debug #
#                    if(wf_id==0) and (each_task.get_id() == 0):
#                        print "now: %.15f" % self.env.now
#                        print "id=" +str(each_task.get_id())
#                        print "sdt=%.15f" % each_task.get_scheduledDispatchTime()
#                        print "pgid=" + str(each_task.get_parentGopId())
#                        print each_task.get_scheduledDispatchTime() == self.env.now
#                        print each_task.get_parentGopId() == 0
                    # debug #
                    
                    
                    if ( ("%.15f" % each_task.get_scheduledDispatchTime()) == ("%.15f" % self.env.now)) and (each_task.get_parentGopId() == 0):
                        task = each_task      
                        break;
            
                if task == None:
                    return False
                else:                
                
                    if(task.get_parentGopId() == 0): # this is a start of a new video
                        
#                        print "---"
#                        print task.getSchedulability_toString()
#                        print "---"
                        
                        # gather specs of video
                        video_specs = self._getVSInfoFromTask(task)
                        
                        #pprint.pprint(video_specs)
                        
                        # request the RM to provide an initial mapping
                        mapping_result = self.runtimeTaskManagerInstance.mapStreamFrames(video_specs)                       
                        if(mapping_result == None): # check if pre-mapping was successful
                            # disable disapatch of all tasks in video stream
                            self._disableAllTaskDispatchInVS(wf_id, task.get_video_stream_id())
                            # record rejection
                            self.rejectedVideoStreams.append(video_specs)
                            
                            Debug.PPrint("%f"%self.env.now + "," + self.label + "," + '_canVideoBeDispatched::, : vid_rejected :' + str(wf_id) + " - " + str(task.get_video_stream_id()), DebugCat.DEBUG_CAT_TDINFO)
                            
                            return False                         
                        else:
                            
                            # tell RM to add the new stream to it's runtime app model - temporary admission
                            gop_tasks = self._getVideoStreamGoPTasks(self.env.now, wf_id, task.get_video_stream_id())
                            self.runtimeTaskManagerInstance.RuntimeApp_addStream(video_specs["wf_id"], gop_tasks , self.env.now)    
                            
                            # perform the admission controller check                       
                            result = self.runtimeTaskManagerInstance.StreamAdmission_NewVideo_ET(video_specs)
                           
                            if(result == False):    # set all tasks in video to false                            
                                # remove previously added stream - reverse admission
                                self.runtimeTaskManagerInstance.RuntimeApp_removeStream(video_specs["wf_id"], video_specs["vid_strm_id"])
                                
                                # disable disapatch of all tasks in video stream
                                self._disableAllTaskDispatchInVS(wf_id, task.get_video_stream_id())
                                
                                # record rejection
                                self.rejectedVideoStreams.append(video_specs)                                    
                                
                                Debug.PPrint("%f"%self.env.now + "," + self.label + "," + '_canVideoBeDispatched::, : vid_rejected :' + str(wf_id) + " - " + str(task.get_video_stream_id()), DebugCat.DEBUG_CAT_TDINFO)
                                
                                return False
                            else:
                                return True
                    else:
                        sys.exit("_canVideoBeDispatched::error -  not gopid = 0")
                
            else:
                return True
        else:
            sys.exit("_canVideoBeDispatched:: not implemented yet!")
    
    def _getVSInfoFromTask(self, task):
        video_specs = {
               "wf_id" : task.get_wfid(),
               "vid_strm_id" : task.get_video_stream_id(),
               "frame_h" : task.get_frame_h(),
               "frame_w" : task.get_frame_w(),
               "fps" : task.get_framerate(),
               "gop_struct" : task.get_gopstructure(),
               "wcc_I" : task.get_wccIFrame(),
               "wcc_P" : task.get_wccPFrame(),
               "wcc_B" : task.get_wccBFrame(),
               "decoded_frame_size" : task.get_completedTaskSize()                
               }
        return video_specs
           
    def _disableAllTaskDispatchInVS(self, wf_id, vs_id):
        disabled_list = []
        for each_task in self.multiple_workflows[wf_id].get_stream_content():
            if(each_task.get_video_stream_id() == vs_id):
                if(each_task.get_dispatchDisabled() == False):
                    each_task.set_dispatchDisabled(True)
                    disabled_list.append(each_task)
        
        #print "_disableAllTaskDispatchInVS"
        #print disabled_list
               
        return disabled_list
            
    def IsPlatformOverloaded(self):
        if(self.runtimeTaskManagerInstance.areNodesOverCapacity() == True):
            return True
        else:
            return False
    
    def InputBuffer_isFull(self, offset=0, id=0):
        return (self.input_buffers[id].simpy_container_instance.level >= (self.input_buffers[id].simpy_container_instance.capacity - offset))
    
    def InputBuffer_put(self,n, id=0):
        self.input_buffers[id].simpy_container_instance.put(n)
    
    
    def _getVideoStreamGoPTasks(self, scheduled_dispatch_time, wf_id, stream_id):
        tasks = []
        
        for each_task in self.multiple_workflows[wf_id].get_stream_content():
            if (("%.15f" % each_task.get_scheduledDispatchTime()) == ("%.15f" % scheduled_dispatch_time)) and \
            (each_task.get_video_stream_id() == stream_id) and \
            (each_task.get_wfid() == wf_id):
                tasks.append(each_task)
        
        return tasks
                
        
        
        
            
    ## getters
    def get_processInstance(self):
        return self.processInstance     
    
    # are there any tasks scheduled to dispatch in the future, which are not disabled ?
    def _areAllWorkflowsEmpty(self):
        count = 0
        for wf_id in xrange(SimParams.NUM_WORKFLOWS):
            for each_task in  self.multiple_workflows[wf_id].get_stream_content():   
                if(each_task.get_scheduledDispatchTime() >= self.env.now):
                    if(each_task.get_dispatchDisabled() == False):
                        count += 1
        
        if(count > 0):
            return False
        else:
            return True
            
            
