import itertools
import random, sys

import simpy


class Buffer():
    def __init__(self, env, id, cap):
        self.env = env
        self.id = id
        self.cap = cap
        
        self.container_inst = simpy.Container(self.env, self.cap, init=0)
    

class Monitor():
    def __init__(self, env, id, rate, buff):
        self.env = env
        self.id = id
        self.rate = rate
        self.buff_inst = buff
        self.process_inst = env.process(self.run())
    
    def run(self):
        
        while True:
            # show stats
            print "-------------- Monitor :: time=" + str(self.env.now) + ", level="+str(self.buff_inst.container_inst.level)
            
            yield self.env.timeout(self.rate)





class Producer():    
    def __init__(self, env, id, rate, buff):
        self.env = env
        self.id = id
        self.rate = rate
        self.buff_inst = buff
        self.process_inst = env.process(self.run())
        
    def run(self):
        
        while True:
            # wake up and produce
            if(self.buff_inst.container_inst.level < self.buff_inst.container_inst.capacity):
                print "Producer("+str(self.id)+"), time=" + str(self.env.now)               
                self.buff_inst.container_inst.put(1)
            
            # sleep
            yield self.sleep()


    def sleep(self):
        return self.env.timeout(self.rate)


class Consumer():    
    def __init__(self, env, id, rate, buff, end_event):
        self.env = env
        self.id = id 
        self.rate = rate
        self.buff_inst = buff
        self.process_inst = env.process(self.run())
        self.end_event = end_event
        
    def run(self):
        
        while True:
            # wake up and consume
            if(self.buff_inst.container_inst.level != 0):
                print "Consumer("+str(self.id)+"), time=" + str(self.env.now)
                self.buff_inst.container_inst.get(1)      
            
#            if(self.buff_inst.container_inst.level > 10):
#                #yield self.end_event
#                #sys.exit()
#                print self.buff_inst.container_inst.level
#                simpy.core._stop_simulate(1)
#                
#            else:
#                print self.buff_inst.container_inst.level
               
            # sleep
            yield self.sleep()
        
    def sleep(self):
        return self.env.timeout(self.rate)
        
        
env = simpy.Environment()
halt_event = env.event()

buff = Buffer(env,1,100)

prod1 = Producer(env,1, 1, buff)
prod2 = Producer(env,2, 2, buff)
prod3 = Producer(env,3, 3, buff)
prod4 = Producer(env,4, 4, buff)

cons1 = Consumer(env,1, 5, buff, halt_event)
cons2 = Consumer(env,2, 6, buff, halt_event)
cons3 = Consumer(env,3, 7, buff, halt_event)
cons4 = Consumer(env,4, 8, buff, halt_event)

mon = Monitor(env,1, 1, buff)


# Execute!
env.run(until=100)
