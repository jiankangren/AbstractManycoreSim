import pprint
import sys
import math
import networkx as nx
import simpy
import matplotlib.pyplot as plt
from datetime import timedelta, datetime

## local imports
from SimParams import SimParams
from Debug import Debug, DebugCat


class NoCFlow:
    
    def __init__(self, id, resptaskSrc, resptaskSrcid, resptaskDstid, source, destination, route,
                 priority, releaseJitter, basicLatency, payload, endTime_wrt_BasicLatency):
        self.id = id
        self.respectiveSrcTask = resptaskSrc
        self.respectiveSrcTaskId = resptaskSrcid
        self.respectiveDstTaskId = resptaskDstid    # this could be a list of taskids
        self.source = source
        self.destination = destination        
        self.route = route
        self.priority = priority        
        self.releaseJitter =  releaseJitter      
        self.basicLatency = basicLatency        
        self.payload = payload        
        self.endTime_wrt_BL = endTime_wrt_BasicLatency
        self.period = None
        
        
        self.analytical_wcet = None
        self.actualLatency = None
        self.actualInterferers = []
                
    
    def __repr__(self):
        debug = "<Flow "
        debug += " id=" + str(self.id)
        debug += " wfstmids='(" + str(self.respectiveSrcTask.get_wfid()) + "," + str(self.respectiveSrcTask.get_video_stream_id()) + ")'"
        debug += " stid=" + str(self.respectiveSrcTaskId)       
        debug += " dtid=" + str(self.respectiveDstTaskId)
        debug += " ugid=" + str(self.get_respectiveSrcTask().get_unique_gop_id())   # unique gop id of src task
        debug += " stgid=" + str(self.get_respectiveSrcTask().get_frameIXinGOP())  # gop ix of src task 
        debug += " src=" + str(self.source)        
        debug += " dst=" + str(self.destination)
        debug += " route=" + str(self.route)
        debug += " pri=" + str(self.priority)
        debug += " bl=" +  str(self.basicLatency)        
        debug += " al=" +  str(self.actualLatency)
        debug += " />"
        
        return debug
    
    
    def toString(self):
        debug = "<Flow "
        debug += " id=" + str(self.id)
        debug += " wfstmids='(" + str(self.get_respectiveSrcTask().get_wfid()) + "," + str(self.get_respectiveSrcTask().get_video_stream_id()) + ")'"
        debug += " stid=" + str(self.respectiveSrcTaskId)       
        debug += " dtid=" + str(self.respectiveDstTaskId)
        debug += " ugid=" + str(self.get_respectiveSrcTask().get_unique_gop_id())   # unique gop id of src task
        debug += " r=" + str(self.route)
        debug += " p=" + str(self.priority)
        debug += " aI=" + str(self.actualInterferers)
        debug += " aL=" +  str(self.actualLatency)
        debug += " />"
        
        return debug
    
    
        
    # minimal version of to-string (for schedulability debug)
    def getSchedulability_toString(self):
        debug = ""
        debug += " id='" + str(self.id)+ "'"
        debug += " wfstmids='(" + str(self.respectiveSrcTask.get_wfid()) + "," + str(self.respectiveSrcTask.get_video_stream_id()) + ")'"
        debug += " stid='" + str(self.respectiveSrcTaskId) + "'"      
        debug += " dtid='" + str(self.respectiveDstTaskId)+ "'"   
        debug += " src='" + str(self.source) + "'"       
        debug += " dst='" + str(self.destination)+ "'"
        debug += " route='" + str(self.route)+ "'"
        debug += " pri='" + str(self.priority)+ "'"
        debug += " p='" + str(self.period)+ "'"
        debug += " j='" + str(self.releaseJitter)+ "'"     
        
        return debug    
        
        
        
    def addActualInterferer(self, interf):
        self.actualInterferers.append(interf)
        
    
    ## getters/setters    
    def set_extendedLatency(self, extL):
        self.extendedLatency = extL    
    def set_releaseJitter(self, rj):
        self.releaseJitter = rj
    def set_period(self, p):
        self.period = p
    def set_analytical_wcet(self, w):
        self.analytical_wcet = w
    def set_actualLatency(self, al):
        self.actualLatency = al
    
    
    def get_extendedLatency(self):
        return self.extendedLatency
    def get_intersections(self):
        return self.waitsFor
    def get_respectiveSrcTask(self):
        return self.respectiveSrcTask
    def get_respectiveSrcTaskId(self):
        return self.respectiveSrcTaskId
    def get_respectiveDstTaskId(self):
        return self.respectiveDstTaskId
    def get_destination(self):
        return self.destination
    def get_source(self):
        return self.source
    def get_priority(self):
        return self.priority
    def get_id(self):
        return self.id
    def get_basicLatency(self):
        return self.basicLatency
    def get_route(self):
        return self.route
    def get_releaseJitter(self):
        return self.releaseJitter
    def get_period(self):
        return self.period
    def get_analytical_wcet(self):
        return self.analytical_wcet
    
    def getUtilisation(self):
        util = float(self.basicLatency/SimParams.NOC_PERIOD)
        return util
    
    ###############################################
    ## functions to assist schedulability analysis
    ###############################################
    
    # all traffic flows that :
    # - have higher (or equal) priority than the traffic in question
    # - share at least one link with the  traffic in question    
    def getDirectInterferenceSet(self, all_flows):
        
        subset = []
        
        for each_flw in all_flows:            
            if(self._equals_v2(self, each_flw) == False) and (each_flw.get_priority() <= self.get_priority()):
                if(self._intersects(each_flw, self) > 0):                    
                    subset.append(each_flw)
                
        return subset
    
    
    # all traffic flows that :
    # - have higher (or equal) priority than the traffics that interfere with the traffic in question
    # - don't share links with the  traffic in question    
    def getIndirectInterferenceSet(self, all_flows):
        
        subset = []
        direct = self.getDirectInterferenceSet(all_flows)
        
        for each_flw in all_flows:            
            if(self._equals_v2(self, each_flw) == False) and (each_flw not in direct):                
                for each_d_flw in direct:                    
                    if(each_flw.get_priority() <= each_d_flw.get_priority()) and (self._intersects(each_d_flw, each_flw)>0):                            
                        subset.append(each_flw)
#                    else:
#                        print "---"
#                        pprint.pprint(each_flw)
#                        pprint.pprint(each_d_flw)
#                        print "---"
        return subset    
    
    
    # all traffic flows that :
    # - have higher (or equal) priority than the traffic in question
    # - share at least one link with the  traffic in question
    # - flows of child tasks will not interfere with flows of parent task - precedence constraints
    def getDirectInterferenceSet_withPrCnst(self, all_flows):
        
        subset = []
        
        for each_flw in all_flows:            
            if(self._equals_v2(self, each_flw) == False) and (each_flw.get_priority() <= self.get_priority()):
                if(self._intersects(each_flw, self) > 0):
                    if(self._isFlowAnInterferer(each_flw) == True):
                        subset.append(each_flw)
                
        return subset
    
    
    # all traffic flows that :
    # - have higher (or equal) priority than the traffics that interfere with the traffic in question
    # - don't share links with the  traffic in question
    # - flows of child tasks will not interfere with flows of parent task - precedence constraints
    def getIndirectInterferenceSet_withPrCnst(self, all_flows):
        
        subset = []
        direct = self.getDirectInterferenceSet_withPrCnst(all_flows)
        
        for each_flw in all_flows:            
            if(self._equals_v2(self, each_flw) == False) and (each_flw not in direct):
                for each_d_flw in direct:
                    #print "getIndirectInterferenceSet:: here - 1"
                    if(each_flw.get_priority() <= each_d_flw.get_priority()) and (self._intersects(each_d_flw, each_flw)>0):
                        #print "getIndirectInterferenceSet:: here - 2"
                        #pprint.pprint(each_flw)
                        #pprint.pprint(self)
                        if(self._isFlowAnInterferer(each_flw) == True):
                            #print "getIndirectInterferenceSet:: here - 3"
                            subset.append(each_flw)
                        
        return subset
    
    
    ### INCORRECT !!!!
    # this checks the following conditions to determine if the given flow truly does interfer (w.r.t precedences):
    # - is the given flow's source task a parent or child of the current flows' source task    
    def _isFlowAnInterferer_v1(self, flow):
        Ti = self.get_respectiveSrcTask()
        Tj = flow.get_respectiveSrcTask()
        
        result = True
        if(Ti.get_unique_gop_id() == Tj.get_unique_gop_id()):    # so they are in the same taskset, so maybe they don't intefere    
        
            Tj_childframes = Ti.get_children_frames()
            Tj_childframes = Tj.get_children_frames()
            
            # is the source task the same ? (because there can be more than one flow released by the same source task)
            if(Ti.get_id() != Tj.get_id()):               
                # now find if the src tasks are child/parent            
                if(Tj.get_frameIXinGOP() not in Ti.get_possible_interfering_frame()):
                    result = False             
        
        return result    
        
    
    def _isFlowAnInterferer_null(self, flow):
        return True
    
    def _isFlowAnInterferer(self, flow):
        Ti = self.get_respectiveSrcTask()   
        Tj = flow.get_respectiveSrcTask()
        
        Ti_dst_ix = self.get_respectiveDstTaskId()   
        Tj_dst_ix = flow.get_respectiveDstTaskId()
        
        ## we can only do a easy test if the flow is to only 1 dst task        
        if(Ti.get_unique_gop_id() == Tj.get_unique_gop_id()):
            
            if(len(Ti_dst_ix) > 1) or (len(Tj_dst_ix) > 1):
                return True
            else:
            
            
                if( Ti_dst_ix[0] in [2, 3, 5, 6, 8, 9, 10, 11]): # if dst task is a B-frame
                    return True
                elif(Tj_dst_ix[0] in [2, 3, 5, 6, 8, 9, 10, 11]): # if dst task is a B-frame
                    return True
                else:
                    # if I0->P1 case : only interfers with anything from I0
                    if ((Ti.get_frameIXinGOP() == 0) and (Ti_dst_ix[0] == 1)) and \
                    (Tj.get_frameIXinGOP() != 0):
                            return False
                   
                    # P1->P4 vs. I0-> P1 case
                    elif ((Ti.get_frameIXinGOP() == 1) and (Ti_dst_ix[0] == 4)) and \
                    ((Tj.get_frameIXinGOP() == 0) and (Tj_dst_ix[0] == 1)):
                        return False
                    
                    # P1->P4 vs. any flow originating from P4, or P7
                    elif ((Ti.get_frameIXinGOP() == 1) and (Ti_dst_ix[0] == 4)) and \
                    (Tj.get_frameIXinGOP() in [4, 7]):
                        return False
                    
                    # P4->P7 vs. I0->P1 case
                    elif ((Ti.get_frameIXinGOP() == 4) and (Ti_dst_ix[0] == 7)) and \
                    ((Tj.get_frameIXinGOP() == 0) and (Tj_dst_ix[0] == 1)):
                        return False
                        
                    # P4->P7 vs. P1->P4 case
                    elif ((Ti.get_frameIXinGOP() == 4) and (Ti_dst_ix[0] == 7)) and \
                    ((Tj.get_frameIXinGOP() == 1) and (Tj_dst_ix[0] == 4)):
                        return False                    
                    
                    # P4->P7 vs. any flow originating from P7
                    elif ((Ti.get_frameIXinGOP() == 4) and (Ti_dst_ix[0] == 7)) and \
                    (Tj.get_frameIXinGOP() in [7]):
                        return False
                    
                    
                    # Any flow originating from P7 will not interfer with I0->P1
                    elif ((Ti.get_frameIXinGOP() == 7)) and \
                    ((Tj.get_frameIXinGOP() == 0) and (Tj_dst_ix[0] == 1)):
                        return False
                    
                    
                    # Any flow originating from P7 will not interfer with P1->P4
                    elif ((Ti.get_frameIXinGOP() == 7)) and \
                    ((Tj.get_frameIXinGOP() == 1) and (Tj_dst_ix[0] == 4)):
                        return False
                    
                    
                    # Any flow originating from P7 will not interfer with P4->P7
                    elif ((Ti.get_frameIXinGOP() == 7)) and \
                    ((Tj.get_frameIXinGOP() == 4) and (Tj_dst_ix[0] == 7)):
                        return False
                    
                    else:
                        return True
                    
                    
                
        else:
            return True
            
    
    
    
    
    # latency when no interference is present
    def getBasicLatency(self):
        
        cost = 0.0        
        num_flits = int(self.payload/SimParams.NOC_FLIT_BYTES)
        route = self.route
        num_hops = float(len(route))        
        cost = ((num_hops * SimParams.NOC_ARBITRATION_COST) + num_flits) * SimParams.NOC_PERIOD  
        
        return cost
    
    # calculates the worst case communication latency only considering the direct interference
    def getDirectInterferenceWorstCaseLatency(self, all_flows):
        
        wl = self.getBasicLatency()
        sdi = self.getDirectInterferenceSet_withPrCnst(all_flows)
        
        
        wlcopy = 0.0
        while((wl != wlcopy) and (wl <= self.get_period())):
            wlcopy = wl
            interf = 0.0
    
            for each_sdi in sdi:
                flowj = each_sdi
                mult = 0.0
                # Previous WC + release jitter (of the higher priority flow)
                mult = math.ceil((wlcopy+flowj.get_releaseJitter())/flowj.get_period())
                # Finds the number of times the higher priority flow "hits" this flow
                interf +=  (mult * (1000000000.0 * flowj.getBasicLatency()))
            
            # The current iteration is the sum of all interferences + the computation time of the current flow
            wl = ((1000000000.0 * self.getBasicLatency()) + interf)/1000000000.0
            
        # Add to the worst-case the release jitter of the task
        # This defines the actual response-time of the task
        wl += self.get_releaseJitter()
                
        # considering deadline = period
#        if(wl > self.get_period()):
#            return sys.float_info.max
        
        return wl
        
        
        
    
    
    # calculates the worst case communication latency due to direct and indirect interference
    def getWorstCaseLatency(self, all_flows, timeout):
        
        #print "getWorstCaseLatency: Enter"
        
        if timeout != None:
            if datetime.utcnow() > timeout: # if too much time has elapsed then timeout and return zero
                #print "getWorstCaseLatency: TIMEOUT!"
                #return sys.float_info.max
                return 0.0
        
        # possible base case ? if this.priority is higher than all the others, then return basic latency
        flag = True
        for each_flw in all_flows:
            if(each_flw.get_priority() < self.get_priority()):  # lower values are higher
                flag = False
                break
            
        
        if(flag == True):
            return self.getBasicLatency() + self.get_releaseJitter()
        else:
        
            wl = self.getBasicLatency()
            sdi = self.getDirectInterferenceSet_withPrCnst(all_flows)
            sii = self.getIndirectInterferenceSet_withPrCnst(all_flows)            
            
            if(len(sdi) == 0):
                return wl + self.get_releaseJitter()
            
            else:
                flows = {}
                
                for each_sdi in sdi:
                    sdj = each_sdi.getDirectInterferenceSet_withPrCnst(sii)
                    
                    if(len(sdj)>0):
                        # If there is indirect interference, calculate it:
                        # worst-case response time for the flow minus its basic latency
                        flows[each_sdi.get_id()] = each_sdi.getWorstCaseLatency(all_flows, timeout) - each_sdi.getBasicLatency()
                    else:
                        flows[each_sdi.get_id()] = 0.0        
                
                #pprint.pprint(flows)
                #print "getWorstCaseLatency: here - 1"
                
                wlcopy = 0.0
                while((wl != wlcopy) and (wl <= self.get_period())):
                    wlcopy = wl
                    interf = 0.0
                    
                    for each_sdi in sdi:
                        flowj = each_sdi
                        
                        #print flowj.get_id()
                        
                        mult = 0.0
                        jitter = flows[flowj.get_id()]
                        
                        #print "jitter = " + str(jitter)
                        #print "flowj.get_releaseJitter()=" + str(flowj.get_releaseJitter())
                        
                        mult = math.ceil((wlcopy+flowj.get_releaseJitter() + jitter)/flowj.get_period())
                        interf +=  (mult * (1000000000.0 * flowj.getBasicLatency()))
                    
                    wl = ((1000000000.0 * self.getBasicLatency()) + interf)/1000000000.0
                
                wl += self.get_releaseJitter()
                
                # considering deadline = period
#                if(wl > self.get_period()):
#                    return sys.float_info.max
                
                return wl
        
      
        
    
    def _intersects(self, flow1, flow2):
        route_links1 = set(flow1.route)
        route_links2 = set(flow2.route)
        
#        print "---"
#        pprint.pprint(route_links1)
#        pprint.pprint(route_links2)
        
        intersecting_links = list(route_links1.intersection(route_links2))  
        
#        
#        print len(intersecting_links)
#        print "---"
#        
        
        return len(intersecting_links)
    
    def _equals(self, f2):
#        if(self.get_id() == f2.get_id()) and \
#        (self.get_respectiveSrcTaskId() == f2.get_respectiveSrcTaskId()) and \
#        (set(self.get_respectiveDstTaskId()) == set(f2.get_respectiveDstTaskId())) and \
#        (self.get_source() == f2.get_source()) and \
#        (self.get_route() == f2.get_route()):
#            return True
#        else:
#            return False

        
        if(self.get_respectiveSrcTaskId() == f2.get_respectiveSrcTaskId()) and \
        (set(self.get_respectiveDstTaskId()) == set(f2.get_respectiveDstTaskId())) and \
        (self.get_source() == f2.get_source()) and \
        (self.get_route() == f2.get_route()):
            return True
        else:
            return False

    @staticmethod
    def _equals_v2(f1, f2):
        if(f1.get_priority() == f2.get_priority()):
            return True
        else:
            return False
    
    
    
    
    
