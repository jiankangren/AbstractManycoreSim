import pprint

import math
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import scipy.stats
from matplotlib.colors import ListedColormap, NoNorm
from matplotlib import mlab
from itertools import cycle # for automatic markers

import matplotlib.cm as cm
from matplotlib.font_manager import FontProperties

## local imports
import Task
import Buffer
from SimParams import SimParams
from TaskSet import TaskSet



class Workflow:
    def __init__(self, env, stream_id, stream_resolution, stream_fr, stream_gop_struct):
        
        self.env = env
        # one-to-one mapping between workflows and inputbuffers
        self.stream_content = None
        self.stream_content_backup = None
        
        self.stream_id = stream_id
        self.stream_resolution = stream_resolution   # tuple
        self.stream_fr = stream_fr   # framerate
        self.stream_gop_struct = stream_gop_struct        
    
    def populateWorkflow(self):
        # e.g. 1 hr movie, 25fps, 12 gop len = running_time * fps / average_GOP_size
        taskset = TaskSet(self.env)
        
        task_start_id = self.stream_id * (SimParams.NUM_GOPS * SimParams.GOP_LENGTH)
        gop_start_id = (SimParams.NUM_GOPS * self.stream_id)
        
        taskset.generateMPEG2FrameTaskSet(SimParams.NUM_GOPS, task_start_id , gop_start_id,
                                          frame_w=self.stream_resolution[0],
                                          frame_h=self.stream_resolution[1])
        
        # set the worst-case exuction time for all tasks in the task_pool
        taskset.set_worstCaseComputationTime_alltasks()
        
        self.stream_content = taskset.taskList
        self.stream_content_backup = taskset.taskList_orig
        
        return len(self.stream_content)
        
    
        
    
    
    @staticmethod
    def dumpWorkflowsToFile(all_workflows, fname="workflows.xml"):
       
        file = open(fname, "w")
        
        file.write("<Workflows>")
        
        for each_workflow in all_workflows:        
            file.write("<TaskSet>")            
            for each_task in each_workflow.stream_content :
                file.write( each_task._debugLongXML() )
                file.write("\n")
        
            file.write("</TaskSet>")
        
        file.write("</Workflows>")            
        file.close()
        
    
        
    ## getters ##
    def get_Task(self):
        return self.stream_content.pop(0)    # return first item
    def get_stream_content(self):
        return self.stream_content
    
    ## setters ##
    def set_stream_content(self, sc):
        self.stream_content = sc
        
    
    def isEmpty(self):
        if(len(self.stream_content)> 0):
            return False
        else:
            return True    
    
    def tasksNotDispatched(self):
        count = 0
        for each_task in  self.stream_content:
            if(each_task.get_dispatchTime() == None) and (self.env.now <= each_task.get_scheduledDispatchTime()) :
                count += 1
        return count
                   
    
    
    @staticmethod    
    def plot_TaskComputationCostHistogram(list_workflows, ftype, fig_id):
        
        
        nrows = int(math.ceil(SimParams.NUM_WORKFLOWS / 2.))
        #fig, axs = plt.subplots(nrows, 2)
        fig = plt.figure(fig_id+100)
        
        for each_wf_id in xrange(SimParams.NUM_WORKFLOWS):
            
            hist_data = []
            for each_task in list_workflows[each_wf_id].stream_content_backup:
                if each_task.get_frameType() == ftype:
                    hist_data.append(each_task.get_computationCost())
        
            #hist_data = [t.get_computationCost() for t in list_workflows[each_wf_id].stream_content_backup]        
            
            plt.subplot(nrows, 2, each_wf_id+1)
            fig.canvas.set_window_title('TaskComputationCostHistogram')
            plt.hist(hist_data, alpha=0.5, color='g', bins=int(len(list_workflows[each_wf_id].stream_content_backup)/100))
            plt.grid(True)
        
        
    
    @staticmethod
    def plot_show():
        plt.show()
       
    