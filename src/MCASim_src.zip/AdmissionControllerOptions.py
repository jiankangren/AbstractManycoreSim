

##########################################################################################################################
# Possible Admission Controller options
##########################################################################################################################
class AdmissionControllerOptions:
    AC_OPTION_HEURISTIC_ONLY    = 1 # perform heuristic based tests only
    AC_OPTION_SCHEDTEST_ONLY    = 2 # perform E2ERTA tests only
    AC_OPTION_HYB_HEU_SCHD_V1   = 3 # perform a hybrid version of the schedulability analysis and heuristic based tests
    AC_OPTION_HYB_HEU_SCHD_V2   = 4 # perform a hybrid version of the heuristic based tests and schedulability analysis (reverse)