import pprint
import sys
import networkx as nx
import simpy
import matplotlib.pyplot as plt

## local imports
from SimParams import SimParams
from NoCFlow import NoCFlow
from NoCFlowTableEntry import NoCFlowTableEntry
from Debug import Debug, DebugCat

class NoCFLWTBL_RMStatus:
    RM_SLEEPING       = 1     # i.e sleeping
    RM_BUSYWAITING    = 2     # i.e waiting for someone else/resource
    RM_BUSY           = 3     # i.e busy computing
    RM_ACTIVE         = 4     # i.e. ready and doing work    
    NODE_JUSTWOKEUP   = 5


class NoCFlowTable:
    
    def __init__(self, env, RMInstance, RMMapper, NNInstance):
        self.flowEntries = {}
        self.nextid = 0
        self.env  = env
        self.mutex = simpy.Container(self.env, capacity=1, init=0)
        self.RMInstance = RMInstance
        self.RMMapper = RMMapper
        self.NodeNetworkInstance = NNInstance
        self.label = "NoCFlowTable"
        self.fire_rqs_outstanding = 0   
        
       
    
    def getIntersectingLinks(self, flow1, flow2):
        route_links1 = set(flow1.route)
        route_links2 = set(flow2.route)
        
        ## debug
        #if(flow1.getFlow().get_id() == 1307):
            
        
        
        intersecting_links = list(route_links1.intersection(route_links2))        
        return intersecting_links
    
    
    # NB: higher the pri number, lower the priority
    def addFlow(self, flow, releaseTime, timeRemaining):        
       
        Debug.PPrint("%.15f"%self.env.now + "," + self.label + "," + 'addFlow::, flow_id=[%d] ' % (flow.get_id()), DebugCat.DEBUG_CAT_NOCFLWTBLINFO)
        
        # create a flow table entry
        newFlowEntry = NoCFlowTableEntry(self.env, flow, releaseTime)        
        newFlow = newFlowEntry.getFlow()
        
        # set remaining time
        newFlowEntry.setRemainingTime(timeRemaining)
        
        # check interfering flows
        for fte_k, fte in self.flowEntries.iteritems():
            existingFlowEntry = fte 
            existingFlow = fte.getFlow()
            intersects = self.getIntersectingLinks(newFlow, existingFlow)
            
            if( len(intersects) > 0): # has interference
                if(existingFlow.get_priority() <= newFlow.get_priority()):   # existing flow 
                    newFlowEntry.addInterferenceSource(existingFlowEntry)
                    newFlowEntry.getFlow().addActualInterferer(existingFlowEntry.getFlow().get_id())
                else:
                    self.flowEntries[fte_k].addInterferenceSource(newFlowEntry)       
                    self.flowEntries[fte_k].getFlow().addActualInterferer(newFlowEntry.getFlow().get_id())                         
            else:
                # no interference
                i=1             
        
        # add to the flow table
        if(flow.get_id() not in self.flowEntries):            
            self.flowEntries[flow.get_id()] = newFlowEntry
            self.nextid += 1
        else:
            sys.exit(self.label + "::addFlow: Error!")            
            
        # update link utilisation
        flw_links =  flow.get_route()
        for each_link in flw_links:
            each_link.addFlow(flow)
        
        
        
    def removeFlow(self, flow_tbl_entry):
        
        Debug.PPrint("%.15f"%self.env.now + "," + self.label + "," + 'removeFlow::, flow_id=[%d] ' % (flow_tbl_entry.getFlow().get_id()), DebugCat.DEBUG_CAT_NOCFLWTBLINFO)
        
        temp_flow_storage = None
        temp_flow_storage = flow_tbl_entry.getFlow()
        
        flw_id = flow_tbl_entry.getFlow().get_id() 
        if(flw_id in self.flowEntries):            
            
            # what is this flows' actual latency ? (should be lower than WCET!)
            actual_latency = self.env.now - self.flowEntries[flw_id].getReleaseTime()
            self.flowEntries[flw_id].getFlow().set_actualLatency(actual_latency)            
            
            ## debug ##
            if(SimParams.LOG_OUTPUT_NOCFLOWINFO == True):
                self._writeToLog('flowinfo.txt', self.flowEntries[flw_id].getFlow().toString())                    
            ###########
            
            
            del self.flowEntries[flw_id] 
            
            # update the interference of the other flows
            for fte_k, fte in self.flowEntries.iteritems():
                self.flowEntries[fte_k].removeInterferenceSource(flow_tbl_entry)
            
            # notify completion of the flow
            new_released_tasks = self.RMMapper.notifyFlowComplete(temp_flow_storage)
            
            # update link utilisation            
            flw_links =  flow_tbl_entry.getFlow().get_route()
            for each_link in flw_links:                
                each_link.removeFlow(flow_tbl_entry.getFlow())
                
            return new_released_tasks
            
        else:
            sys.exit(self.label + "::removeFlow: Error!")
      
    
    def interruptRMAfterDelay(self, when_to_interrupt, finished_flw_ids):
        
        delay = when_to_interrupt - self.env.now
        
        if(delay > 0):
            yield self.env.timeout(delay)   # delay   
        
            if(self.RMInstance.status == NoCFLWTBL_RMStatus.RM_SLEEPING):
                Debug.PPrint("%.15f"%self.env.now + "," + self.label + "," +'interruptRMAfterDelay::, interrupting RM (finished_flw_id=' + str(finished_flw_ids), DebugCat.DEBUG_CAT_INTERRUPT)
                self.RMInstance.processInstance.interrupt("NOCFLOW-"+str(finished_flw_ids))
    
            
    def updateTable(self, fire=False):
        
        Debug.PPrint("%.15f"%self.env.now + "," + self.label + "," + 'updateTable::', DebugCat.DEBUG_CAT_NOCFLWTBLINFO)   

        finished_flw_ids = []
        
        fired = False
        
        # create list of flows in decreasing order of priority
        flows_list =[]
        for fte_key, fte in self.flowEntries.iteritems():
            flows_list.append((fte_key, fte))
        
        flows_list_pri_sorted = sorted(flows_list, key=lambda x: x[1].getFlow().get_priority(), reverse=False)
        
#        print "BEFORE (sorted): "
#        pprint.pprint(flows_list_pri_sorted)
#        print "----------"
                
        # check if the flow table entry has completed
        for each_fte in flows_list_pri_sorted:
            
            each_fte_flow = each_fte[1]
            each_fte_flow_key = each_fte[0]
                        
            # active flows
            if(each_fte_flow.isActive() == True):
                # checks whether current flow completed transmission
                # if true, remove it from the main flow table
                
#                #### debug ###
#                if(each_fte_flow_key == 2542):
#                    print "2542:: i_flws :"
#                    print each_fte_flow
#                    print "%.15f" % self._trunc(each_fte_flow.getRemainingTime(), 10)
#                    print "%.15f" % self._trunc(self.env.now-each_fte_flow.getLastActivationTime(), 10)
#

#                if(each_fte_flow_key == 2987):
#                    print "2987:: i_flws :"
#                    print each_fte_flow
#                    print "%.15f" % self._trunc(each_fte_flow.getRemainingTime(), 10)
#                    print "%.15f" % self._trunc(self.env.now-each_fte_flow.getLastActivationTime(), 10)
#                ############# 
                
                
                #if(round(each_fte_flow.getRemainingTime(),11) <= round(self.env.now-each_fte_flow.getLastActivationTime(), 11)):
                if( self._trunc(each_fte_flow.getRemainingTime(), 10) <= self._trunc(self.env.now-each_fte_flow.getLastActivationTime(), 10)):
                    new_released_tasks = self.removeFlow(each_fte_flow)    
                    if(len(new_released_tasks) > 0):
                        finished_flw_ids.append(each_fte_flow.getFlow().get_id())                
                    # add task to the dep buffer of the dst node
                    self._flowComplete_putToNodeDepBuff(each_fte_flow.getFlow())
                    
                    
                else:   ## TODO: ASK JH
                            
                    # check if any of the intersecting flows have become active
                    # if true, update current flow as inactive and update its remaining time
                    each_fte_interferrence_flows = each_fte_flow.getInterferenceFlows()
                    for fte in each_fte_interferrence_flows:
                        if((fte.isActive() == True) or 
                        (fte.isActive() == False and ( self._trunc(fte.getReleaseTime(), 10) == self._trunc(self.env.now, 10) ))):    # incase the interfering flow was release just now
                            #each_fte_flow.setInactive()
                            self.flowEntries[each_fte_flow_key].setInactive()
                            #rt = float(each_fte_flow.getRemainingTime() - (self.env.now - each_fte_flow.getLastActivationTime()))                            
                            rt = self._trunc(each_fte_flow.getRemainingTime() - (self.env.now-each_fte_flow.getLastActivationTime()), 11)  
                            #each_fte_flow.setRemainingTime(rt)
                            self.flowEntries[each_fte_flow_key].setRemainingTime(rt)
                            
                            break;
                
            # inactive flows
            else:
                
                # checks whether all interfering flows became inactive (or terminated)
                # if true, set current flow as active
                
                each_fte_interferrence_flows = each_fte_flow.getInterferenceFlows()
                
#                ### debug ###
#                if(each_fte_flow_key == 13):
#                    print "13:: i_flws :"
#                    pprint.pprint(each_fte_interferrence_flows)
#                    print str(finished_flw_ids)
#                #############                
                
                allInactive = True
                
                for fte in each_fte_interferrence_flows:
                    if(fte.isActive() == True):
                        allInactive = False
                        #break   # TODO: ASK JHR
                
                if(allInactive == True):
                    #each_fte_flow.setActive()
                    self.flowEntries[each_fte_flow_key].setActive()                    
                    if(fire==True):   
                
                        #### debug ###
#                        if(each_fte_flow_key == 2542):
#                            print "firing---"
#                            print "2542:: i_flws :"
#                            print each_fte_flow
#                            print "%.15f" % each_fte_flow.getRemainingTime()
#                            print "%.15f" % self.env.now
                
                
                        self.env.process(self.addFiringRequest(each_fte_flow.getRemainingTime()+0.0000000001, each_fte_flow.getFlow().get_id()))
                        fired = True
                        self.fire_rqs_outstanding += 1
                    
#        print "FLWTBL_AFTER_UPDATE: "
#        print "-----------------------"
#        pprint.pprint(self.flowEntries)
#        print "-----------------------"
        
        if(len(finished_flw_ids) > 0):                    
            #self.interruptRMAfterDelay(float(self.env.now+SimParams.SYNCH_TIME_OFFSET), -1)
            when_to_interrupt = self.env.now + SimParams.SYNCH_TIME_OFFSET
            self.env.process(self.interruptRMAfterDelay(when_to_interrupt, finished_flw_ids))
        
        if(fired == False):
            if(self.fire_rqs_outstanding == 0):
                #sys.exit("nothing fired")
                #print "=========================>>>>>> nothing fired"
                return False
            else:
                return True
        else:
            return True
                    
    #Truncates/pads a float f to n decimal places without rounding
    def _trunc(self, f, n):
        
        if n > 15:
            sys.exit("_trunc: error")
        
        s = "%.15f" % f
        ss = s[:-(15-n)]
        
        return float(ss)
        
        
        
    
    def addFiringRequest(self, time, by_which_flow):
        
        Debug.PPrint("%.15f"%self.env.now + "," + self.label + "," + 'addFiringRequest:: time_willfire=%.15f, by_which_flow=%d' % (time+self.env.now, by_which_flow), DebugCat.DEBUG_CAT_NOCFLWTBLINFO)
        
        yield self.env.timeout(time)   # delay
        
        self.fire_rqs_outstanding -= 1
        
        while(self.RMInstance.flow_table.mutex.level == 1):
            i=1 # busy wait                                       
        self.RMInstance.flow_table.mutex.put(1)   # obtain lock
        while(self.RMInstance.mutex_tmtbl.level == 1):
            i=1 # busy wait                                                            
        self.RMInstance.mutex_tmtbl.put(1)      # obtain lock
        
        # call update again, if no firing requests were made
        result = self.updateTable(fire=True)
        if(result == False):            
#            print "FLWTBL_AFTER_UPDATE: "
#            print "-----------------------"
#            pprint.pprint(self.flowEntries)
#            print "-----------------------"        
            
            result = self.updateTable(fire=True)
            
#            print "FLWTBL_AFTER_UPDATE: "
#            print "-----------------------"
#            pprint.pprint(self.flowEntries)
#            print "-----------------------"
        
        self.RMInstance.mutex_tmtbl.get(1)      # obtain lock
        self.RMInstance.flow_table.mutex.get(1)   # obtain lock
        
        
    def _flowComplete_putToNodeDepBuff(self, completed_flow):
        dst_node_id = completed_flow.get_destination()        
        dst_node = self.NodeNetworkInstance.get_Nodes()[dst_node_id]
        
        task = completed_flow.get_respectiveSrcTask()
        
        result = dst_node.dependencyBuff_put(task)        
        if(result == False):
            print("%f"%self.env.now + "," + self.label + "," +'_flowComplete_putToNodeDepBuff::, : node-'+ str(dst_node.get_id()) + ", --- dep_buff is FULL ! ")
            pprint.pprint(dst_node.dependency_buff.get_BuffContents())
            pprint.pprint(self.RMInstance.task_mapping_table)
            sys.exit()
        
        
    
    
    # setters/getters
    
    def get_flow(self, src_task_id=None, dst_task_id=None, src_node_id=None, dst_node_id=None):
        if (src_task_id != None) and (dst_task_id != None) and (src_node_id != None) and (dst_node_id != None):
            for each_flow_k,each_flow_v  in self.flowEntries.iteritems():
                
                #pprint.pprint(each_flow_v)
                
                if(each_flow_v['flow'].respectiveSrcTaskId == src_task_id) and \
                    (dst_task_id in each_flow_v['flow'].respectiveDstTaskId) and \
                    (each_flow_v['flow'].source == src_node_id) and \
                    (each_flow_v['flow'].destination == dst_node_id):
                        return (each_flow_k,each_flow_v)
            
            return (None, None)
        else:
            return (None, None)
        
        
               
    ## helpers
    def numEntries(self):
        return len(self.flowEntries)
    

    def _writeToLog(self, fname, data):
        f = open(fname, 'a')
        f.write(data + "\n")
        f.close()
        
    
        
