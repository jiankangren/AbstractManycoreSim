import pprint.pprint

## local imports



class SharedMemory:
    def __init__(self): 