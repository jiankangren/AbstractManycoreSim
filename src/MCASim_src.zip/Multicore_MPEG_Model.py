# system imports
import simpy
import os, sys
import pprint
from time import gmtime, strftime
import time, random



# local imports
from CPUNode import CPUNode
from SimParams import SimParams
from NodeNetwork import NodeNetwork
from TaskSet import TaskSet
from Workflow import Workflow
from WorkflowGenerator import WorkflowGenerator
from Buffer import Buffer, BufferType
from Random_MappingPolicy import Random_MappingPolicy, Random_Basic_MappingPolicy
from FirstFree_MappingPolicy import FirstFree_MappingPolicy
from LeastDataIO_MappingPolicy import LeastDataIO_MappingPolicy
from RunTimeTaskManager import RunTimeTaskManager
from RunTimeTaskManager_TT import RunTimeTaskManager_TT # time triggered tasks
from RunTimeTaskManager_ET import RunTimeTaskManager_ET # event triggered tasks
from TaskDispatcher import TaskDispatcher
from SimDataMonitor import SimDataMonitor
from OnChipInterconnect_CrossbarMesh import CrossbarMesh
from OnChipInterconnect_NoC import NoC      
from NoCSchedulabilityAnalysis import NoCSchedulabilityAnalysis  

SimMon = None

def runMainSimulation():
    
    global SimMon
    
    ############################################################
    ############################################################
    #########    MAIN SIMULATION ENTRY POINT        ############
    ############################################################
    ############################################################
    
    ################################
    # INITIALISE SIMULATION
    ################################
    # start phase
    print os.path.basename(__file__) + ":: Simulation Start " + "(" + strftime("%H:%M:%S", gmtime()) + ")"    
    
    # create environment
    env = simpy.Environment()
    
    ################################
    # Log, report, debug cleanup
    ################################
    NoCSchedulabilityAnalysis.cleanOutputReports("schedulability_tests")
    
    
    ################################
    # MODEL ALL NODES ON SYSTEM
    # (Modelled as simpy-processes)
    ################################
    Node_Network_test = NodeNetwork() 
    for n in xrange(SimParams.NUM_NODES):
        node = CPUNode(env, n, tq_size = SimParams.CPUNODE_TASKQ_SIZE)
        Node_Network_test.addNode(node)
        
    ################################
    # MODEL ON-CHIP-INTERCONNECT
    ################################   
    Mesh2DNOC =  NoC(Node_Network_test.get_Nodes(), SimParams.NOC_W, SimParams.NOC_H)
    Mesh2DNOC.construct()
    #print Mesh2DNOC
    #Mesh2DNOC.testNetwork()
    
    ################################
    # Give various access to the nodes
    ################################ 
    Node_Network_test.set_nodeNetworkAccess(Mesh2DNOC)
    
    ################################
    # GENERATE WORKFLOWS
    ################################
    
    Workflows = WorkflowGenerator(env, SimParams.NUM_WORKFLOWS, 
                      SimParams.WFGEN_MIN_VIDS_PER_WF,
                      SimParams.WFGEN_MAX_VIDS_PER_WF,
                      SimParams.WFGEN_MIN_GOPS_PER_VID,
                      SimParams.WFGEN_MAX_GOPS_PER_VID,
                      SimParams.WFGEN_MAX_INTER_VIDEO_GAP,
                      SimParams.WFGEN_MIN_INTER_VIDEO_GAP,
                      None,
                      None )
        
    Workflows.generate_workflows()
    #Workflows.setTaskPriorities_AllUnique()
    MultipleWorkflows = []
    total_num_tasks = 0
    for each_wf_key, each_wf_val in Workflows.workflows.iteritems():
        wf = Workflow(env, each_wf_key, None, None, None)
        wf.set_stream_content(each_wf_val)
        total_num_tasks += len(Workflows.workflows[each_wf_key])
        MultipleWorkflows.append(wf)
    
    Workflows.dumpWorkflowsToFile()    
    #Workflows.showTaskTimeLine(len(MultipleWorkflows))
    #WorkflowGenerator.plot_show()
    
    #print total_num_tasks
    #sys.exit()
    
#    MultipleWorkflows = []
#    total_num_tasks = 0
#    stream_id = 0
#    for i in xrange(SimParams.NUM_WORKFLOWS):
#        wf = Workflow(env, stream_id, (SimParams.FRAME_DEFAULT_W, SimParams.FRAME_DEFAULT_H), SimParams.FRAME_RATE, SimParams.GOP_STRUCTURE)
#        size = wf.populateWorkflow()
#        total_num_tasks = total_num_tasks + size
#        
#        MultipleWorkflows.append(wf)
#        
#        # set new stream-id (100 offset)
#        stream_id = stream_id + 1
#    
#    #Workflow.dumpWorkflowsToFile(MultipleWorkflows)
#    #Workflow.plot_TaskComputationCostHistogram(MultipleWorkflows, "P", 1)
#    #Workflow.plot_TaskComputationCostHistogram(MultipleWorkflows, "B", 2)
#    #Workflow.plot_show()
    
    #sys.exit()
    
    ################################
    # Create I/O Buffers
    # (Modelled as simpy-containers)
    ################################
    # one input buffer mapped onto one workflow
    InputBuffers = []
    for i in xrange(SimParams.NUM_INPUTBUFFERS):
        IPBuff = Buffer(env, BufferType.BUFFER_TYPE_INPUT, size=SimParams.INPUT_BUFF_SIZE) # 50 slot input buff
        InputBuffers.append(IPBuff)
    
    OutputBuffer = Buffer(env, BufferType.BUFFER_TYPE_OUTPUT, size=SimParams.OUTPUT_BUFF_SIZE)  # large num slot output buff
    
    # give all nodes access to outputbuff
    Node_Network_test.set_outputBuffInstance(OutputBuffer)
    
    ################################
    # Create Resource Manager
    # with a bunch of policies to test
    # (Modelled as simpy-process)
    ################################
    # pick a policy
    RM_Policy = Random_MappingPolicy(Node_Network_test, InputBuffers)
    RMB_Policy = Random_Basic_MappingPolicy(Node_Network_test, InputBuffers)
    FF_Policy = FirstFree_MappingPolicy(Node_Network_test, InputBuffers)
    LDIO_Policy = LeastDataIO_MappingPolicy(Node_Network_test, InputBuffers)
    
    # create resource manager with that policy
    ResourceManager = RunTimeTaskManager_ET(env, 
                                         polling_delay=SimParams.RESOURCEMANAGER_POLL_RATE, 
                                         mapping_policy = FF_Policy,
                                         node_network = Node_Network_test, 
                                         input_buffers = InputBuffers, 
                                         output_buffer = OutputBuffer,
                                         interconnect = Mesh2DNOC,
                                         task_dispatcher = None)
    
    ResourceManager.set_maxTasks(total_num_tasks)
    ResourceManager.set_lastscheduledtask_time(Workflows.getLastScheduledTask().get_scheduledDispatchTime())
    ResourceManager.set_flowpriorityoffset(max(Workflows.get_used_pri_values()))    
    
    # give node network access to RM
    Node_Network_test.set_resourceManagerInstance(ResourceManager)
    
    
    ################################
    # Create Task Dispatcher
    # He takes a task from task pool and
    # transfers to input buff
    # (Modelled as simpy-process)
    ################################
    Task_Dispatcher = TaskDispatcher(env,InputBuffers,None, MultipleWorkflows, SimParams.TASKDISPATCH_RATE, ResourceManager)
    ResourceManager.set_taskdispatcher_instance(Task_Dispatcher)
    
    ################################
    # Create Simulation monitoring instance
    # (Modelled as simpy-process)
    ################################
    SimMon = SimDataMonitor(env,Node_Network_test, InputBuffers, OutputBuffer, Task_Dispatcher, Workflows, ResourceManager)    
    
    ################################
    # START SIMULATION
    ################################
    #env.run(until=SimParams.SIM_RUNTIME)
    return (env, ResourceManager.get_lastscheduledtask_time())
    
    
    #print " "
    #print os.path.basename(__file__) + ":: Simulation End " + "(" + strftime("%H:%M:%S", gmtime()) + ")"





#############################
# Run Simulation
#############################
#runMainSimulation()
    
#############################
# GET SIM_END STATS
#############################

# show some sim analysis
#print "###########################################################"
#print "STATS"
#print "###########################################################"
#print ""
#SimMon.plot_InputBuffer()
#SimMon.plot_OutputBuffer()
#SimMon.plot_NodeTaskQs()

#SimMon.show_CompletedTaskAnalysis()
#SimMon.plot_TasksMissedDeadline_perCore()
#SimMon.plot_TasksMissedDeadline_perTask()

#fname = 'experiment_data/lateness/wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES)
#SimMon.show_OutputBuffer_Contents_ByGOP(dump_to_file=fname)
#SimMon.show_CPU_utilisation()

#pprint.pprint(ResourceManager.slack_reclaim_table)

#SimMon.plot_InstUtilisation()
#SimMon.plot_showall()



