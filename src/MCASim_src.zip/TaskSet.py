import pprint

import math, random
import os, sys

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import scipy.stats
from matplotlib.colors import ListedColormap, NoNorm
from matplotlib import mlab
from itertools import cycle # for automatic markers

import matplotlib.cm as cm
from matplotlib.font_manager import FontProperties

## local imports
from MPEG2GOPTask import MPEG2GOPTask
from MPEG2FrameTask import MPEG2FrameTask
from SimParams import SimParams

class TaskSet:
    def __init__(self, env):
        self.taskList = []
        self.taskList_orig = []
        self.env = env
        
        # for debug #
        self.fig_counter = 100
    
    ## generates a MPEG GOP task set
    def generateMPEG2GOPTaskSet(self, num_gops):
        
        for tid in xrange(num_gops):
            gop_task = MPEG2GOPTask(env= self.env, id = tid)
            self.taskList.append(gop_task)
        
        print '%f'%self.env.now + "," + 'TaskSet::' + "," + 'generateMPEG2GOPTaskSet::,' + " - " + str(len(self.taskList)) + " tasks generated"
        
        # archive to refer to later
        self.taskList_orig = list(self.taskList)
        
    
    ## generates a MPEG-Frame task set
    ## we also provide the taskset dispatch times
    def generateMPEG2FrameTaskSet(self, num_gops, task_start_id, gop_start_id, unique_gop_start_id, \
                                  gop_structure = SimParams.GOP_STRUCTURE,                                  
                                  taskset_dispatch_start_time = 0.0,
                                  video_stream_id = None,
                                  wf_id = None,                                  
                                  frame_h=SimParams.FRAME_DEFAULT_H,
                                  frame_w=SimParams.FRAME_DEFAULT_W,
                                  priority_range = None):        
        
        
        # check pri range
        if (priority_range == None):
            sys.exit('generateMPEG2FrameTaskSet:: error in pri range')
        
        taskset_dispatch_rates = []
        
        gop_dispatch_time = taskset_dispatch_start_time
        for each_gop_id in xrange(0,num_gops):            
            gop_instance = []   # reset
            frame_id = 0     # reset
            for each_frame in gop_structure:
                frame_task = MPEG2FrameTask(env = self.env, \
                                            id = (((each_gop_id) * SimParams.GOP_LENGTH) + frame_id) + task_start_id, \
                                            frame_type = str(each_frame), \
                                            frame_ix_in_gop = frame_id, \
                                            unique_gop_id = (each_gop_id + unique_gop_start_id), \
                                            gop_id = (each_gop_id+gop_start_id), \
                                            video_stream_id = video_stream_id, \
                                            wf_id = wf_id, \
                                            frame_h=frame_h, \
                                            frame_w=frame_w, \
                                            priority = priority_range[frame_id])
                
                frame_task.set_scheduledDispatchTime(gop_dispatch_time)
                
                # is this the first or last gop in the video stream ?
                if(each_gop_id == 0): # first
                    frame_task.set_isHeadVideoGop(True)
                elif(each_gop_id == (num_gops-1)): # last
                    frame_task.set_isTailVideoGop(True)
                
                gop_instance.append(frame_task)
            
                self.taskList.append(frame_task)
                frame_id = frame_id + 1
            
            for frame in gop_instance:
                frame.adjust_deadline(gop_instance)
                
            # adjust scheduled dispatch time for next gop
            dr = random.uniform(SimParams.TASKDISPATCH_RATE_MIN, SimParams.TASKDISPATCH_RATE_MAX)            
            gop_dispatch_time += dr
            taskset_dispatch_rates.append(dr)
                
        #print '%f'%self.env.now + "," + "TaskSet::,generateMPEG2FrameTaskSet, - " + str(len(self.taskList)) + " tasks generated, num_gops=" + str(num_gops)
        
        # archive to refer to later
        self.taskList_orig = list(self.taskList)
        
        avg_dispatch_rate =  float(sum(taskset_dispatch_rates))/float(len(taskset_dispatch_rates))
        min_dispatch_rate = min(taskset_dispatch_rates)
        
        return (gop_dispatch_time, avg_dispatch_rate, min_dispatch_rate)
        
    
    
    
    
    ## get max_min of Frame_specific tasks : i.e (max,min) of I/P/B frames
    def get_maxmin_MPEG2Frame(self, all_tasks):
        i_frames_cc = []
        p_frames_cc = []
        b_frames_cc = []        
        
        for each_task in all_tasks:
            if(each_task.get_frameType() == "I"):
                i_frames_cc.append(each_task.get_computationCost())
            if(each_task.get_frameType() == "P"):
                p_frames_cc.append(each_task.get_computationCost())
            if(each_task.get_frameType() == "B"):
                b_frames_cc.append(each_task.get_computationCost())
                
        iframe_wcc = all_tasks[0].gen_Iframe_wcc()
        pframe_wcc = all_tasks[0].gen_Pframe_wcc()
        bframe_wcc = all_tasks[0].gen_Bframe_wcc()
        
        ## sanity check !!!
        if(max(i_frames_cc) > iframe_wcc):
            sys.exit("TaskSet:: get_maxmin_MPEG2Frame - bad  iframe_wcc")
        if(max(p_frames_cc) > pframe_wcc):
            sys.exit("TaskSet:: get_maxmin_MPEG2Frame - bad  pframe_wcc")
        if(max(b_frames_cc) > bframe_wcc):
            sys.exit("TaskSet:: get_maxmin_MPEG2Frame - bad  bframe_wcc")
                
        result = {
                  "I" : ( max(i_frames_cc), float(sum(i_frames_cc)/float(len(i_frames_cc))), min(i_frames_cc) ),
                  "P" : ( max(p_frames_cc), float(sum(p_frames_cc)/float(len(p_frames_cc))), min(p_frames_cc) ),
                  "B" : ( max(b_frames_cc), float(sum(b_frames_cc)/float(len(b_frames_cc))), min(b_frames_cc) )
                  }

#        result = {
#                  "I" : ( iframe_wcc, float(sum(i_frames_cc)/float(len(i_frames_cc))), min(i_frames_cc) ),
#                  "P" : ( pframe_wcc, float(sum(p_frames_cc)/float(len(p_frames_cc))), min(p_frames_cc) ),
#                  "B" : ( bframe_wcc, float(sum(b_frames_cc)/float(len(b_frames_cc))), min(b_frames_cc) )
#                  }
        
        return result
    
    def set_worstCaseComputationTime_alltasks(self):
        
        max_avg_min = self.get_maxmin_MPEG2Frame(self.taskList) 
        
        max_i = max_avg_min["I"][0]
        max_p = max_avg_min["P"][0]
        max_b = max_avg_min["B"][0]
        
        for each_task in self.taskList:
            if(each_task.get_frameType() == "I"):
                each_task.set_worstCaseComputationCost(max_i)
            if(each_task.get_frameType() == "P"):
                each_task.set_worstCaseComputationCost(max_p) 
            if(each_task.get_frameType() == "B"):
                each_task.set_worstCaseComputationCost(max_b)
                
            # worst case-execution times for different frame types
            each_task.set_wccIFrame(max_i)
            each_task.set_wccPFrame(max_p)
            each_task.set_wccBFrame(max_b)
        
        
    
    ## getters ##
    def get_taskList(self):
        return self.taskList
    
    def get_Task(self):
        return self.taskList.pop(0)    # return first item
        
    
    def isEmpty(self):
        if(len(self.taskList)> 0):
            return False
        else:
            return True
    
    
    
    
    ######################
    ## debug specific ####
    ######################
    def printTaskSet(self):
        for each_task in self.taskList :
            print each_task
            print ""
    
    def dumpTaskSetToFile(self, fname='taskset.xml'):
        file = open(fname, "w")
        
        file.write("<TaskSet>")
        
        for each_task in self.taskList :
            file.write( each_task._debugLongXML() )
            file.write("\n")
        
        file.write("</TaskSet>")
        file.close()

          
        
    def plot_TaskComputationCostHistogram(self):
        hist_data = [t.get_computationCost() for t in self.taskList_orig]        
        
        self.fig_counter += 1
        fig = plt.figure(self.fig_counter)
        fig.canvas.set_window_title('TaskComputationCostHistogram')
        plt.hist(hist_data, alpha=0.5, color='g', bins=int(len(self.taskList_orig)))
        plt.grid(True)
        

        
        
        
        
        