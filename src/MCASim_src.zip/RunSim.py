import sys, os, csv, pprint, math

import numpy as np
import random
import shutil
import time
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import scipy.stats
from matplotlib.colors import ListedColormap, NoNorm
from matplotlib import mlab
from itertools import cycle # for automatic markers

import matplotlib.cm as cm
from matplotlib.font_manager import FontProperties

from AdmissionControllerOptions import AdmissionControllerOptions
from SimParams import SimParams


import Multicore_MPEG_Model as MMMSim


NUM_WORKFLOWS = range(8, 17, 2)
#NUM_WORKFLOWS = [12]
NUM_NODES = [2,4,8,16,32]
NOC_XY = [(2,1), (2,2), (2,4), (2,8), (2,16)]


# lateness vs. number of cores
def runSim_Simple():
    
    sim_start_time = time.clock()
    print "runSim_Simple :: start_time = " + str(sim_start_time)
    
    # init seed
    seed = random.randint(0, sys.maxint)
    print "SEED === " + str(seed)    
    random.seed(1087744070)
    #random.seed(1909964230)
    #random.seed(seed)
    
    # fixed params
    SimParams.SLACK_FEEDBACK_ENABLED = False   
    SimParams.LOG_OUTPUT_SCHED_TEST_REPORT    = False 
    
    SimParams.NUM_WORKFLOWS = 10
    SimParams.NUM_INPUTBUFFERS = 10
    SimParams.AC_TEST_OPTION = AdmissionControllerOptions.AC_OPTION_HEURISTIC_ONLY
        
    env, last_scheduled_task_time = MMMSim.runMainSimulation()
    env.run(until=last_scheduled_task_time+SimParams.SIM_RUNTIME)
    print env.now
    
    sim_end_time = time.clock()
    print "runSim_Simple :: end_time = " + str(sim_end_time)
    print "runSim_Simple :: time taken = " + str(sim_end_time-sim_start_time)
    
    
    MMMSim.SimMon.report_DecodedWorkflows_Summary()
    #MMMSim.SimMon.report_RM_FlowTable()
    #MMMSim.SimMon.report_OutputBuffer_Contents_ByGOP()
    MMMSim.SimMon.report_InstUtilisation(dump_to_file="test")
    
    

# for the same workload - we check different percentages of the schedulability test
def runACTest_PercentageSchedulable_vs_DeadlineMiss():
    
    NUM_RUNS = 30
    percentage_list = range(0, 80, 5)
    
    # fixed params
    SimParams.SLACK_FEEDBACK_ENABLED = False
    SimParams.NUM_WORKFLOWS = 11
    SimParams.NUM_INPUTBUFFERS = 11 
    SimParams.AC_TEST_OPTION = AdmissionControllerOptions.AC_OPTION_SCHEDTEST_ONLY
    
    for each_run in xrange(NUM_RUNS):    
        
        # init seed
        seed = random.randint(0, sys.maxint)
        print "SEED === " + str(seed)    
        #random.seed(1087744070)
        #random.seed(1909964230)
        random.seed(seed)    
        
        sim_start_time = time.clock()
        print "runSim_Simple :: start_time = " + str(sim_start_time)
        
        for each_sched_percentage in percentage_list:
            
            #############################################################
            # run simulation for the given schedulability test percentage
            #############################################################
            
            SimParams.WCRT_SCHEDULABILITY_TEST_PERCENTAGE = float(each_sched_percentage)
            
            random.seed(seed)
            print "----------------------------"
            print "Running Test : percentage=" + str(each_sched_percentage) + "%, actest = hybrid_v1"
            print "----------------------------"
            FNAME_PREFIX = "ACTest_sched_p" + str(each_sched_percentage) + "_"
            EXP_OUTPUT_FOLDER = "experiment_data/sched_percentage_compare/" + "seed_" + str(seed) + "/"
            
            if not os.path.exists(EXP_OUTPUT_FOLDER):
                os.makedirs(EXP_OUTPUT_FOLDER)        
                  
            env, last_scheduled_task_time = MMMSim.runMainSimulation()
            env.run(until=last_scheduled_task_time+SimParams.SIM_RUNTIME)
            print env.now
            
            sim_end_time = time.clock()
            print "runSim_Simple :: end_time = " + str(sim_end_time)
            print "runSim_Simple :: time taken = " + str(sim_end_time-sim_start_time)
            
            tm_fname = EXP_OUTPUT_FOLDER +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_timeline.png"
            vs_bs_fname = EXP_OUTPUT_FOLDER +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + ".js"
            util_fname = EXP_OUTPUT_FOLDER +  FNAME_PREFIX +'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES)
            wf_res_fname = EXP_OUTPUT_FOLDER +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_wfressumm.js"
            gops_opbuff_fname = EXP_OUTPUT_FOLDER +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_gopsopbuffsumm.js"
            rmtbl_dt_fname = EXP_OUTPUT_FOLDER +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_rmtbldt.js"
            
            (wf_results_summary, gops_in_outputbuff_summary) = MMMSim.SimMon.report_DecodedWorkflows_Summary(timeline_fname=tm_fname, 
                                                                                                             wf_res_summary_fname = wf_res_fname, 
                                                                                                            gops_opbuff_summary_fname = gops_opbuff_fname,
                                                                                                            rmtbl_dt_summary_fname = rmtbl_dt_fname,
                                                                                                            output_format = "json")
            
            MMMSim.SimMon.report_VideoStream_BasicStats(wf_results_summary, vs_bs_fname)
            #MMMSim.SimMon.report_InstUtilisation(dump_to_file=util_fname)
        
        



# multiple runs with varying number of workflows
# basic video stats output at the end - to check efficiency of admission controller
def runACTest_multiWorkflows():
        
        
    # init seed
    #seed = random.randint(0, sys.maxint)
    seed = 1087744070
    print "SEED === " + str(seed)    
    #random.seed(1963493565)
    #random.seed(1234)
        
    for each_wf_num in NUM_WORKFLOWS:
             
        # fixed params
        SimParams.SLACK_FEEDBACK_ENABLED = False
        SimParams.NUM_WORKFLOWS = each_wf_num
        SimParams.NUM_INPUTBUFFERS = each_wf_num
        
        ##########################################
        # ac_test : heuristics only
        ##########################################
        random.seed(seed)
        print "----------------------------"
        print "Running Test : num_wf=" + str(each_wf_num) + ", actest = heuristics_only"
        print "----------------------------"
        
        FNAME_PREFIX = "ACTest_heu_"
          
        SimParams.AC_TEST_OPTION = AdmissionControllerOptions.AC_OPTION_HEURISTIC_ONLY        
        env, last_scheduled_task_time = MMMSim.runMainSimulation()
        env.run(until=last_scheduled_task_time+SimParams.SIM_RUNTIME)
        print env.now
        
        tm_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_timeline.png"
        vs_bs_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + ".js"
        util_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX +'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES)
        wf_res_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_wfressumm.js"
        gops_opbuff_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_gopsopbuffsumm.js"
        rmtbl_dt_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_rmtbldt.js"
        
        (wf_results_summary, gops_in_outputbuff_summary) = MMMSim.SimMon.report_DecodedWorkflows_Summary(timeline_fname=tm_fname, 
                                                                                                         wf_res_summary_fname = wf_res_fname, 
                                                                                                        gops_opbuff_summary_fname = gops_opbuff_fname,
                                                                                                        rmtbl_dt_summary_fname = rmtbl_dt_fname,
                                                                                                        output_format = "json")
        
        MMMSim.SimMon.report_VideoStream_BasicStats(wf_results_summary, vs_bs_fname)
        MMMSim.SimMon.report_InstUtilisation(dump_to_file=util_fname)
        
        
        ##########################################
        # ac_test : schedulability test only
        ##########################################
        random.seed(seed)
        print "----------------------------"
        print "Running Test : num_wf=" + str(each_wf_num) + ", actest = schedulability_only"
        print "----------------------------"
        FNAME_PREFIX = "ACTest_sched_"
          
        SimParams.AC_TEST_OPTION = AdmissionControllerOptions.AC_OPTION_SCHEDTEST_ONLY        
        env, last_scheduled_task_time = MMMSim.runMainSimulation()
        env.run(until=last_scheduled_task_time+SimParams.SIM_RUNTIME)
        print env.now
        
        tm_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_timeline.png"
        vs_bs_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + ".js"
        util_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX +'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES)
        wf_res_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_wfressumm.js"
        gops_opbuff_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_gopsopbuffsumm.js"
        rmtbl_dt_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_rmtbldt.js"
        
        (wf_results_summary, gops_in_outputbuff_summary) = MMMSim.SimMon.report_DecodedWorkflows_Summary(timeline_fname=tm_fname, 
                                                                                                         wf_res_summary_fname = wf_res_fname, 
                                                                                                        gops_opbuff_summary_fname = gops_opbuff_fname,
                                                                                                        rmtbl_dt_summary_fname = rmtbl_dt_fname,
                                                                                                        output_format = "json")
        MMMSim.SimMon.report_VideoStream_BasicStats(wf_results_summary, vs_bs_fname)
        MMMSim.SimMon.report_InstUtilisation(dump_to_file=util_fname)
        
        
        ############################################
        # ac_test : combined heuristics + sched test (hybrid-v1)
        ############################################
        random.seed(seed)
        print "----------------------------"
        print "Running Test : num_wf=" + str(each_wf_num) + ", actest = hybrid_v1"
        print "----------------------------"
        FNAME_PREFIX = "ACTest_hybv1_"
          
        SimParams.AC_TEST_OPTION = AdmissionControllerOptions.AC_OPTION_HYB_HEU_SCHD_V1        
        env, last_scheduled_task_time = MMMSim.runMainSimulation()
        env.run(until=last_scheduled_task_time+SimParams.SIM_RUNTIME)
        print env.now
        
        tm_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_timeline.png"
        vs_bs_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + ".js"
        util_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX +'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES)
        wf_res_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_wfressumm.js"
        gops_opbuff_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_gopsopbuffsumm.js"
        rmtbl_dt_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_rmtbldt.js"
        
        (wf_results_summary, gops_in_outputbuff_summary) = MMMSim.SimMon.report_DecodedWorkflows_Summary(timeline_fname=tm_fname, 
                                                                                                         wf_res_summary_fname = wf_res_fname, 
                                                                                                        gops_opbuff_summary_fname = gops_opbuff_fname,
                                                                                                        rmtbl_dt_summary_fname = rmtbl_dt_fname,
                                                                                                        output_format = "json")
        
        MMMSim.SimMon.report_VideoStream_BasicStats(wf_results_summary, vs_bs_fname)
        MMMSim.SimMon.report_InstUtilisation(dump_to_file=util_fname)
        
        
        
        ############################################
        # ac_test : combined heuristics + sched test (hybrid-v2)
        ############################################
#        random.seed(seed)
#        print "----------------------------"
#        print "Running Test : num_wf=" + str(each_wf_num) + ", actest = hybrid_v2"
#        print "----------------------------"
#        FNAME_PREFIX = "ACTest_hybv2_"
#          
#        SimParams.AC_TEST_OPTION = AdmissionControllerOptions.AC_OPTION_HYB_HEU_SCHD_V2        
#        env, last_scheduled_task_time = MMMSim.runMainSimulation()
#        env.run(until=last_scheduled_task_time+SimParams.SIM_RUNTIME)
#        print env.now
#        
#        tm_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_timeline.png"
#        vs_bs_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + ".js"
#        util_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX +'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES)
#        wf_res_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_wfressumm.js"
#        gops_opbuff_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_gopsopbuffsumm.js"
#        rmtbl_dt_fname = 'experiment_data/vs_ac_test/' +  FNAME_PREFIX + 'wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES) + "_rmtbldt.js"
#        
#        (wf_results_summary, gops_in_outputbuff_summary) = MMMSim.SimMon.report_DecodedWorkflows_Summary(timeline_fname=tm_fname, 
#                                                                                                         wf_res_summary_fname = wf_res_fname, 
#                                                                                                        gops_opbuff_summary_fname = gops_opbuff_fname,
#                                                                                                        rmtbl_dt_summary_fname = rmtbl_dt_fname,
#                                                                                                        output_format = "json")
#        
#        MMMSim.SimMon.report_VideoStream_BasicStats(wf_results_summary, vs_bs_fname)
#        MMMSim.SimMon.report_InstUtilisation(dump_to_file=util_fname)
        
        


# lateness vs. number of cores
def runLatenessExp_multiCores():
    
    # fixed params
    SimParams.NUM_WORKFLOWS = 16
    SimParams.NUM_INPUTBUFFERS = 16
    SimParams.SLACK_FEEDBACK_ENABLED = False
    
    # feedback = true
    for i in xrange(5):
    #for i in [4]:
        
        print "i = " + str(NUM_NODES[i])
        
        SimParams.NUM_NODES = NUM_NODES[i]
        SimParams.NOC_H = NOC_XY[i][0]
        SimParams.NOC_W = NOC_XY[i][1]        
        
        env = MMMSim.runMainSimulation()
        env.run(until=SimParams.SIM_RUNTIME)
        
        fname = 'experiment_data/lateness/FbTrue_wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES)
        MMMSim.SimMon.report_OutputBuffer_Contents_ByGOP(dump_to_file=fname)
        #MMMSim.SimMon.report_InstUtilisation(dump_to_file=fname)
        
        
   


def runLatenessExp_multiWorkflows():
    
    # feedback = true
    for each_wf_num in NUM_WORKFLOWS:

        # set params
        SimParams.SLACK_FEEDBACK_ENABLED = True
        SimParams.NUM_WORKFLOWS = each_wf_num
        SimParams.NUM_INPUTBUFFERS = each_wf_num
        
        env = MMMSim.runMainSimulation()
        env.run(until=SimParams.SIM_RUNTIME)
        
        fname = 'experiment_data/lateness/FbTrue_wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES)
        #MMMSim.SimMon.report_OutputBuffer_Contents_ByGOP(dump_to_file=fname)
        MMMSim.SimMon.report_InstUtilisation(dump_to_file=fname)
        
        
    # feedback = false
    for each_wf_num in NUM_WORKFLOWS:

        # set params
        SimParams.SLACK_FEEDBACK_ENABLED = False
        SimParams.NUM_WORKFLOWS = each_wf_num
        SimParams.NUM_INPUTBUFFERS = each_wf_num
        
        env = MMMSim.runMainSimulation()
        env.run(until=SimParams.SIM_RUNTIME)
        
        fname = 'experiment_data/lateness/FbFalse_wf'+str(SimParams.NUM_WORKFLOWS)+'_cores'+str(SimParams.NUM_NODES)
        #MMMSim.SimMon.report_OutputBuffer_Contents_ByGOP(dump_to_file=fname)
        MMMSim.SimMon.report_InstUtilisation(dump_to_file=fname)






sys.setrecursionlimit(1500)

#runSim_Simple()
#runACTest_multiWorkflows()
runACTest_PercentageSchedulable_vs_DeadlineMiss()

#runLatenessExp_multiWorkflows()
#(FbFalse_all_data, FbTrue_all_data) = plot_LatenessComparisons_boxplot()
#plot_LatenessComparisons_summary()
#plot_InstUtilisation(None)
#plot_InstUtilisation_3D(None)

#runLatenessExp_multiCores()
#plot_LatenessComparisons_varyingCores()

#FB_stat_significance_tests(FbTrue_all_data, FbFalse_all_data)

#plt.show()